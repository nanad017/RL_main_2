"""funcval — a novel functionality-equivalence validator (foundation).

This package replaces an overloaded ``confidence: float`` with a typed evidence
model where every verdict exposes exactly ONE comparable quantity: an upper
bound on the false-admit probability, paired with the :class:`Scope` it was
measured over.  Composition refuses to overclaim; a single admission gate
compares the one quantity against a risk budget.

Public surface:
    Evidence kinds : Evidence, Refuted, Proof, Sampled, Behavioral, Unknown,
                     ComposedBound
    Supporting     : Scope, Cert
    Math (pure)    : clopper_pearson_upper, union_bound
    Ledger         : compose, admit
    Facade         : FunctionValidator (sync gate + async behavioral path)
    Async          : ProgressRewardRunner (behavioral progress-reward stream)
"""
from __future__ import annotations

from .async_runner import ProgressRewardRunner
from .bounds import clopper_pearson_upper, union_bound
from .evidence import (
    Behavioral,
    Cert,
    ComposedBound,
    Evidence,
    Proof,
    Refuted,
    Sampled,
    Scope,
    Unknown,
)
from .ledger import admit, compose
from .validator import FunctionValidator

__all__ = [
    "Evidence",
    "Refuted",
    "Proof",
    "Sampled",
    "Behavioral",
    "Unknown",
    "ComposedBound",
    "Scope",
    "Cert",
    "clopper_pearson_upper",
    "union_bound",
    "compose",
    "admit",
    "FunctionValidator",
    "ProgressRewardRunner",
]
