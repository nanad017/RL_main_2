"""Verify functionality preservation via CAPEv2 behavioral comparison.

Compares: original sample behavior vs mutated sample behavior.
Match criteria: same API calls, same file operations, same network activity.

CAPEv2 (successor to Cuckoo) provides dynamic analysis — it executes the PE
inside a sandboxed Windows VM and records:
  - Win32 API call sequences (ntdll, kernel32, ws2_32, ...)
  - File system operations (create, write, delete)
  - Registry modifications
  - Network connections (DNS, HTTP, raw TCP/UDP)
  - Dropped files and process trees

We submit both the original and mutated sample, wait for reports, then diff
the behavioral signatures. If the mutated sample exhibits the same malicious
behaviors, the mutation preserved functionality.

Usage:
    from funcval.cape.sandbox_verify import SandboxVerifier

    v = SandboxVerifier("http://10.105.197.27:8000/api")
    result = v.verify_preservation(original_bytes, mutated_bytes)
    print(result["preserved"], result["similarity"])
"""

import hashlib
import json
import time
from collections import Counter
from typing import Dict, List, Optional, Tuple

try:
    import requests
except ImportError:
    requests = None  # type: ignore[assignment]


class CAPEConnectionError(Exception):
    """Raised when CAPEv2 is unreachable or unhealthy."""


class CAPETimeoutError(Exception):
    """Raised when analysis does not complete within the deadline."""


class SandboxVerifier:
    """Verify functionality preservation via CAPEv2 behavioral comparison.

    Compares: original sample behavior vs mutated sample behavior.
    Match criteria: same API calls, same file operations, same network activity.
    """

    # CAPEv2 task statuses
    STATUS_PENDING = "pending"
    STATUS_RUNNING = "running"
    STATUS_COMPLETED = "completed"
    STATUS_REPORTED = "reported"

    # Behavioral categories we compare
    CATEGORIES = ("api_calls", "file_ops", "registry_ops", "network_ops",
                  "dropped_files", "mutexes")

    # Weights for the composite similarity score (sum = 1.0)
    CATEGORY_WEIGHTS = {
        "api_calls":     0.35,
        "file_ops":      0.15,
        "registry_ops":  0.15,
        "network_ops":   0.15,
        "dropped_files": 0.10,
        "mutexes":       0.10,
    }

    # Default threshold: below this composite score we consider behavior broken
    DEFAULT_THRESHOLD = 0.70

    def __init__(self, cape_api_url: str = "http://localhost:8000/api",
                 api_token: str = "",
                 timeout: int = 300,
                 poll_interval: int = 10,
                 similarity_threshold: float = DEFAULT_THRESHOLD):
        """
        Args:
            cape_api_url: Base URL of the CAPEv2 REST API (no trailing slash).
            api_token: Optional API token for authenticated endpoints.
            timeout: Max seconds to wait for each analysis to complete.
            poll_interval: Seconds between status polls.
            similarity_threshold: Minimum composite similarity to declare
                                  "preserved". Range [0.0, 1.0].
        """
        if requests is None:
            raise ImportError(
                "sandbox_verify requires the 'requests' library. "
                "Install it with: pip install requests"
            )

        self.api_url = cape_api_url.rstrip("/")
        self.timeout = timeout
        self.poll_interval = poll_interval
        self.threshold = similarity_threshold

        self.session = requests.Session()
        if api_token:
            self.session.headers["Authorization"] = f"Token {api_token}"

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def health_check(self) -> Dict:
        """Check if CAPEv2 is reachable and accepting submissions.

        Returns:
            {"healthy": bool, "version": str|None, "error": str|None,
             "machines": int|None}

        Does NOT raise; always returns a dict so callers can branch.
        """
        result: Dict = {"healthy": False, "version": None,
                        "error": None, "machines": None}

        # Try the cuckoo status endpoint (CAPEv2 keeps this)
        try:
            resp = self.session.get(
                f"{self.api_url}/cuckoo/status/",
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                result["healthy"] = True
                result["version"] = data.get("version")
                machines = data.get("machines", {})
                result["machines"] = machines.get("available", 0)
            else:
                result["error"] = (
                    f"CAPEv2 returned HTTP {resp.status_code}: "
                    f"{resp.text[:200]}"
                )
        except requests.ConnectionError:
            result["error"] = (
                f"Cannot connect to CAPEv2 at {self.api_url}. "
                "Is the 'cape' service running?\n\n"
                "To start CAPEv2 on the VM:\n"
                "  sudo systemctl start cape\n"
                "  sudo systemctl start cape-processor\n"
                "  sudo systemctl start cape-web\n\n"
                "Or check status:\n"
                "  sudo systemctl status cape cape-processor cape-web\n"
                "  journalctl -u cape --no-pager -n 50"
            )
        except requests.Timeout:
            result["error"] = (
                f"CAPEv2 at {self.api_url} timed out. "
                "The service may be starting up (auto-restart loop). "
                "Wait 30s and retry."
            )
        except Exception as exc:
            result["error"] = f"Unexpected error: {exc}"

        return result

    # ------------------------------------------------------------------
    # Submit
    # ------------------------------------------------------------------

    def submit(self, bytez: bytes, filename: str = "sample.exe",
               machine: str = "", package: str = "",
               enforce_timeout: bool = False,
               custom_options: str = "") -> str:
        """Submit a sample for analysis. Returns task ID as a string.

        Args:
            bytez: Raw PE bytes.
            filename: Filename hint for the sandbox.
            machine: Specific analysis machine name (empty = auto).
            package: Analysis package (empty = auto-detect).
            enforce_timeout: If True, sample runs for the full timeout.
            custom_options: Comma-separated key=value CAPE options.

        Raises:
            CAPEConnectionError: If the API is unreachable.
            RuntimeError: If submission is rejected.
        """
        url = f"{self.api_url}/tasks/create/file/"

        files = {"file": (filename, bytez)}
        data = {}
        if machine:
            data["machine"] = machine
        if package:
            data["package"] = package
        if enforce_timeout:
            data["enforce_timeout"] = "1"
        if custom_options:
            data["options"] = custom_options

        try:
            resp = self.session.post(url, files=files, data=data, timeout=30)
        except requests.ConnectionError as exc:
            raise CAPEConnectionError(
                f"Cannot reach CAPEv2 at {url}: {exc}"
            ) from exc

        if resp.status_code != 200:
            raise RuntimeError(
                f"CAPEv2 submission failed (HTTP {resp.status_code}): "
                f"{resp.text[:500]}"
            )

        body = resp.json()
        # CAPEv2 returns {"task_id": 123} or {"task_ids": [123]}
        task_id = body.get("task_id") or (body.get("task_ids") or [None])[0]
        if task_id is None:
            raise RuntimeError(
                f"CAPEv2 submission returned no task ID: {body}"
            )
        return str(task_id)

    # ------------------------------------------------------------------
    # Poll / wait
    # ------------------------------------------------------------------

    def get_status(self, task_id: str) -> str:
        """Get the current status of a task.

        Returns one of: pending, running, completed, reported, failed.
        """
        url = f"{self.api_url}/tasks/view/{task_id}/"
        try:
            resp = self.session.get(url, timeout=15)
        except requests.ConnectionError as exc:
            raise CAPEConnectionError(str(exc)) from exc

        if resp.status_code != 200:
            raise RuntimeError(
                f"Failed to query task {task_id}: HTTP {resp.status_code}"
            )
        task = resp.json().get("task", resp.json())
        return task.get("status", "unknown")

    def wait_for_completion(self, task_id: str,
                            timeout: Optional[int] = None) -> str:
        """Block until the task reaches 'reported' status or timeout.

        Returns the final status string.

        Raises:
            CAPETimeoutError: If the task is not done within timeout seconds.
        """
        deadline = time.time() + (timeout or self.timeout)
        while time.time() < deadline:
            status = self.get_status(task_id)
            if status in (self.STATUS_REPORTED, "failed"):
                return status
            # 'completed' means processing; wait for 'reported'
            time.sleep(self.poll_interval)

        raise CAPETimeoutError(
            f"Task {task_id} did not complete within "
            f"{timeout or self.timeout}s (last status: {self.get_status(task_id)})"
        )

    # ------------------------------------------------------------------
    # Report retrieval & normalization
    # ------------------------------------------------------------------

    def get_report(self, task_id: str) -> Dict:
        """Get the full behavioral report for a completed analysis.

        Returns the raw CAPEv2 JSON report dict.
        """
        url = f"{self.api_url}/tasks/report/{task_id}/"
        try:
            resp = self.session.get(url, timeout=60)
        except requests.ConnectionError as exc:
            raise CAPEConnectionError(str(exc)) from exc

        if resp.status_code != 200:
            raise RuntimeError(
                f"Failed to get report for task {task_id}: "
                f"HTTP {resp.status_code}"
            )
        return resp.json()

    @staticmethod
    def extract_behavior(report: Dict) -> Dict[str, List[str]]:
        """Extract normalized behavioral signatures from a CAPEv2 report.

        Returns a dict with keys matching CATEGORIES, each containing a
        sorted list of normalized behavior strings for comparison.
        """
        behavior = report.get("behavior", {})
        result: Dict[str, List[str]] = {
            "api_calls": [],
            "file_ops": [],
            "registry_ops": [],
            "network_ops": [],
            "dropped_files": [],
            "mutexes": [],
        }

        # --- API calls ---
        # CAPEv2 stores per-process call lists under behavior.processes[].calls
        for proc in behavior.get("processes", []):
            for call in proc.get("calls", []):
                api_name = call.get("api", "")
                category = call.get("category", "")
                # Normalize: "category::api_name"
                if api_name:
                    result["api_calls"].append(f"{category}::{api_name}")

        # --- File operations ---
        summary = behavior.get("summary", {})
        for fpath in summary.get("files", []):
            result["file_ops"].append(f"touch::{_normalize_path(fpath)}")
        for fpath in summary.get("write_files", []):
            result["file_ops"].append(f"write::{_normalize_path(fpath)}")
        for fpath in summary.get("delete_files", []):
            result["file_ops"].append(f"delete::{_normalize_path(fpath)}")
        for fpath in summary.get("read_files", []):
            result["file_ops"].append(f"read::{_normalize_path(fpath)}")

        # --- Registry operations ---
        for key in summary.get("keys", []):
            result["registry_ops"].append(f"open::{key}")
        for key in summary.get("write_keys", []):
            result["registry_ops"].append(f"write::{key}")
        for key in summary.get("delete_keys", []):
            result["registry_ops"].append(f"delete::{key}")
        for key in summary.get("read_keys", []):
            result["registry_ops"].append(f"read::{key}")

        # --- Network operations ---
        network = report.get("network", {})
        for dns in network.get("dns", []):
            hostname = dns.get("request", dns.get("hostname", ""))
            if hostname:
                result["network_ops"].append(f"dns::{hostname}")
        for http_req in network.get("http", []):
            host = http_req.get("host", "")
            uri = http_req.get("uri", http_req.get("path", ""))
            method = http_req.get("method", "GET")
            result["network_ops"].append(f"{method}::{host}{uri}")
        for conn in network.get("tcp", []):
            dst = conn.get("dst", "")
            dport = conn.get("dport", "")
            result["network_ops"].append(f"tcp::{dst}:{dport}")
        for conn in network.get("udp", []):
            dst = conn.get("dst", "")
            dport = conn.get("dport", "")
            result["network_ops"].append(f"udp::{dst}:{dport}")

        # --- Dropped files ---
        for dropped in report.get("dropped", []):
            sha256 = dropped.get("sha256", "")
            name = dropped.get("name", "unknown")
            if sha256:
                result["dropped_files"].append(f"{name}::{sha256[:16]}")

        # --- Mutexes ---
        for mx in summary.get("mutexes", []):
            result["mutexes"].append(str(mx))

        # Sort each category for stable comparison
        for key in result:
            result[key].sort()

        return result

    # ------------------------------------------------------------------
    # Comparison
    # ------------------------------------------------------------------

    def compare_behavior(self, original_report: Dict,
                         mutated_report: Dict) -> Dict:
        """Compare two behavioral reports. Returns similarity metrics.

        Returns:
            {
                "composite_similarity": float,  # weighted overall [0.0, 1.0]
                "per_category": {
                    "api_calls": {"similarity": float, "original_count": int,
                                  "mutated_count": int, "common_count": int},
                    ...
                },
                "original_signatures": int,
                "mutated_signatures": int,
            }
        """
        orig_beh = self.extract_behavior(original_report)
        mut_beh = self.extract_behavior(mutated_report)

        per_category = {}
        composite = 0.0

        for cat in self.CATEGORIES:
            orig_set = Counter(orig_beh.get(cat, []))
            mut_set = Counter(mut_beh.get(cat, []))

            sim = _counter_similarity(orig_set, mut_set)
            weight = self.CATEGORY_WEIGHTS.get(cat, 0.0)
            composite += sim * weight

            # Intersection count (min of each element)
            common = sum((orig_set & mut_set).values())

            per_category[cat] = {
                "similarity": round(sim, 4),
                "original_count": sum(orig_set.values()),
                "mutated_count": sum(mut_set.values()),
                "common_count": common,
            }

        return {
            "composite_similarity": round(composite, 4),
            "per_category": per_category,
            "original_signatures": sum(
                sum(Counter(orig_beh[c]).values()) for c in self.CATEGORIES
            ),
            "mutated_signatures": sum(
                sum(Counter(mut_beh[c]).values()) for c in self.CATEGORIES
            ),
        }

    # ------------------------------------------------------------------
    # End-to-end verification
    # ------------------------------------------------------------------

    def verify_preservation(self, original_bytez: bytes,
                            mutated_bytez: bytes,
                            original_filename: str = "original.exe",
                            mutated_filename: str = "mutated.exe",
                            timeout: Optional[int] = None) -> Dict:
        """End-to-end: submit both, wait for results, compare.

        Returns:
            {
                "preserved": bool,
                "similarity": float,
                "threshold": float,
                "original_task_id": str,
                "mutated_task_id": str,
                "details": { ... per-category breakdown ... },
                "error": str|None,
            }
        """
        result = {
            "preserved": False,
            "similarity": 0.0,
            "threshold": self.threshold,
            "original_task_id": None,
            "mutated_task_id": None,
            "details": {},
            "error": None,
        }

        # 0) Health check
        health = self.health_check()
        if not health["healthy"]:
            result["error"] = (
                f"CAPEv2 is not healthy: {health['error']}"
            )
            return result

        effective_timeout = timeout or self.timeout

        try:
            # 1) Submit both samples
            orig_id = self.submit(original_bytez, filename=original_filename)
            mut_id = self.submit(mutated_bytez, filename=mutated_filename)
            result["original_task_id"] = orig_id
            result["mutated_task_id"] = mut_id

            # 2) Wait for both to complete
            orig_status = self.wait_for_completion(orig_id,
                                                   timeout=effective_timeout)
            mut_status = self.wait_for_completion(mut_id,
                                                  timeout=effective_timeout)

            if orig_status == "failed":
                result["error"] = (
                    f"Original sample analysis failed (task {orig_id})"
                )
                return result
            if mut_status == "failed":
                result["error"] = (
                    f"Mutated sample analysis failed (task {mut_id})"
                )
                return result

            # 3) Get reports
            orig_report = self.get_report(orig_id)
            mut_report = self.get_report(mut_id)

            # 4) Compare
            comparison = self.compare_behavior(orig_report, mut_report)
            similarity = comparison["composite_similarity"]

            result["similarity"] = similarity
            result["preserved"] = similarity >= self.threshold
            result["details"] = comparison

        except CAPETimeoutError as exc:
            result["error"] = f"Analysis timed out: {exc}"
        except CAPEConnectionError as exc:
            result["error"] = f"CAPEv2 connection lost: {exc}"
        except Exception as exc:
            result["error"] = f"Unexpected error: {exc}"

        return result


# ======================================================================
# Helpers (module-private)
# ======================================================================

def _normalize_path(path: str) -> str:
    """Normalize a Windows file path for stable comparison.

    Strips drive letter variations and lowercases. We keep the relative
    path structure so that 'C:\\Users\\admin\\test.txt' and
    'C:\\Users\\sandbox\\test.txt' both become 'users\\*\\test.txt'-ish.
    """
    path = path.lower().replace("/", "\\")
    # Strip drive letter
    if len(path) > 2 and path[1] == ":":
        path = path[2:]
    # Replace sandbox user directory variations
    # CAPEv2 often uses different user dirs per run
    parts = path.split("\\")
    normalized = []
    skip_next = False
    for i, part in enumerate(parts):
        if skip_next:
            normalized.append("*")
            skip_next = False
            continue
        if part in ("users", "documents and settings"):
            normalized.append(part)
            skip_next = True  # next part is username, normalize it
            continue
        normalized.append(part)
    return "\\".join(normalized)


def _counter_similarity(a: Counter, b: Counter) -> float:
    """Compute similarity between two Counters using the Jaccard-like metric.

    Uses min-intersection / max-union on multisets.
    Returns 1.0 if both are empty (vacuously similar).
    """
    if not a and not b:
        return 1.0

    all_keys = set(a.keys()) | set(b.keys())
    if not all_keys:
        return 1.0

    intersection = sum(min(a[k], b[k]) for k in all_keys)
    union = sum(max(a[k], b[k]) for k in all_keys)

    if union == 0:
        return 1.0
    return intersection / union
