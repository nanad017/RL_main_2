"""CAPE CLI / filesystem-poll client — the concrete behavioral-oracle TRANSPORT.

This module implements the design in ``docs/research/cape_client_design.md``
(section 9, ``CapeCliClient``) as the CLI-submit + filesystem-poll backend for
the FunctionValidator's L6 SANDBOX layer.

Why this exists (design §0): the CAPE box on this lab has its HTTP REST control
plane *disabled*, so ``SandboxVerifier``'s ``submit/get_status/get_report`` (which
talk to ``/tasks/create/file/`` etc.) cannot drive it. This client replaces those
three methods with a CLI-submit + filesystem-poll transport, while **REUSING**
``SandboxVerifier.extract_behavior`` and ``SandboxVerifier.compare_behavior``
unchanged for behavior extraction + similarity scoring (it does not re-implement
scoring). The result-dict shape it returns matches
``SandboxVerifier.verify_preservation`` so the L6 adapter is transport-agnostic.

Topology (design §1):

    workstation / primary VM
          |  scripts/vmctl ssh   (netns + VPN + socat + SSH mux)
          v
    PRIMARY VM   rl@10.105.197.27        <- runs /home/rl/sbx.py
          |  sbx.py  (paramiko, rl/123, 8s connect / 45s exec)
          v
    CAPE BOX     rl@10.105.198.0  (NOT host-routable)
          |  sudo -S -u cape  (poetry env)
          v
    /opt/CAPEv2  (utils/submit.py, storage/analyses/<id>/reports/report.json)

Transports (where the client itself runs — see ``CapeCliClient.transport``):
  * ``"vmctl"`` — the client runs on a WORKSTATION and must two-hop into the
    PRIMARY VM first: the ``<vm_python> sbx.py <b64>`` command is wrapped as
    ``scripts/vmctl ssh '<that command>'`` (the full topology above).
  * ``"local"`` — the client runs DIRECTLY on the PRIMARY VM (e.g. a
    collaborator inside the ``sorel-malware-detector`` conda env). There is no
    ``scripts/vmctl`` there and the vmctl hop is nonsensical: ``sbx.py`` and the
    VM python are LOCAL, so ``<vm_python> sbx.py <b64>`` is run directly via
    subprocess with NO ``vmctl ssh`` wrapper.
  * ``"auto"`` (default) — pick ``"vmctl"`` if the resolved ``vmctl`` path is an
    existing executable file (we're on a workstation), else ``"local"`` (vmctl
    absent ⇒ we're on the VM). Only the COMMAND DISPATCH differs between the two
    modes; the underlying ``<vm_python> sbx.py <b64>`` invocation, timeouts,
    retry, empty-trace gate, and all soundness logic are identical.

CORRECTED LIVE FACTS baked in (these override the design doc where they differ):
  * The control-plane log is ``/opt/CAPEv2/log/cuckoo.log`` (CAPEv2 keeps the
    legacy name; there is NO ``cape.log``). ``poll()`` greps cuckoo.log and falls
    back to ``journalctl -u cape``.
  * ``sudo -u cape`` is NOT passwordless on this box. We use ``sudo -S`` reading
    the rl password ("123") from stdin. The password is NEVER written to any
    logged artifact (see ``_REDACTED`` and ``_redact``).
  * The verified submit incantation auto-detects the package (NO ``--package``):
    ``cd /opt/CAPEv2 && /etc/poetry/bin/poetry run python utils/submit.py
    --machine <GUEST> --timeout 60 <PE_PATH>``.
  * sbx.py lives on the PRIMARY VM, not the box. The base64 box command runs ON
    the box; we parse sbx.py's ``---EXIT <N>---`` trailer for the box rc.

Soundness contract (design §6/§8 — enforced here):
  * Empty-vs-empty must NOT score a spurious admissible PASS. ``verify_pair``
    gates on ``_is_empty_trace`` (< ``MIN_API_CALLS`` total API calls AND 0
    file/registry/network ops) -> status INCONCLUSIVE, preserved=None.
  * Every terminal non-PASS condition (CAPE down, timeout, FAILED analysis,
    fetch corruption, empty trace) -> INCONCLUSIVE, NEVER a silent PASS.
  * ``fetch_report`` NEVER returns ``{}`` silently (an empty dict would score 1.0).
  * No HTTP fallback (the control API is disabled on this box).
"""

from __future__ import annotations

import base64
import enum
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import time
from pathlib import Path
from typing import Dict, List, NamedTuple, Optional, Sequence

from funcval.cape.sandbox_verify import SandboxVerifier  # REUSE scoring; do not modify

# ======================================================================
# Named constants (every timeout / magic value lives here — design §6)
# ======================================================================

# --- Transport endpoints -------------------------------------------------
# NOTE (host-config hygiene): the lab values below are FALLBACK DEFAULTS baked
# into the distributed wheel for zero-config use inside the lab.  Each is
# ENV-OVERRIDABLE via ``os.environ.get(NAME, <lab default>)`` so a different
# host (different VM python, sbx.py path, CAPE root, or rl password) does NOT
# require editing the wheel.  Behavior is IDENTICAL when the env vars are unset.
#: Python interpreter on the PRIMARY VM that has paramiko (drives sbx.py).
VM_PY = os.environ.get(
    "FUNCVAL_CAPE_VM_PYTHON",
    "/home/rl/miniconda3/envs/sorel-malware-detector/bin/python",
)
#: The paramiko driver on the PRIMARY VM (takes ONE base64 box command).
SBX_PATH = os.environ.get("FUNCVAL_CAPE_SBX_PATH", "/home/rl/sbx.py")
#: The local control-plane wrapper that owns netns+VPN+socat+SSH mux.
VMCTL = "scripts/vmctl"

# --- CAPE box paths ------------------------------------------------------
CAPE_ROOT = os.environ.get("FUNCVAL_CAPE_ROOT", "/opt/CAPEv2")
POETRY_BIN = os.environ.get("FUNCVAL_CAPE_POETRY_BIN", "/etc/poetry/bin/poetry")
#: CAPEv2 keeps the legacy name "cuckoo.log" (NOT cape.log) — verified live.
CUCKOO_LOG = f"{CAPE_ROOT}/log/cuckoo.log"
#: Per-client scratch dir on the box for staged PEs (cleaned in a finally).
BOX_STAGING_DIR = "/tmp/capecli"
#: A report.json larger than this is treated as a malformed run (not fetched).
MAX_REPORT_BYTES = 64 * 2 ** 20  # 64 MB

# --- Guests / parallelism (design §4) -----------------------------------
DEFAULT_GUESTS = ("win11", "win11_2", "win11_3")
DEFAULT_MACHINE = DEFAULT_GUESTS[0]
#: Client-side semaphore: never more than this many tasks in flight.
MAX_IN_FLIGHT = 3

# --- Timeouts / cadences (all seconds; design §6 table) -----------------
#: Local `vmctl ssh` wrapper bound. Always > sbx.py's 45 s exec so the remote
#: side always wins the race. rc=124 -> transport error -> retry once.
LOCAL_TIMEOUT = 60
#: Per-box-command exec budget (sbx.py hard-caps at 45 s regardless).
EXEC_TIMEOUT = 45
#: Submit's box exec budget (submit returns in ~1-3 s; 20 s is generous).
SUBMIT_EXEC_TIMEOUT = 20
#: Guest analysis timeout passed to submit.py --timeout (distinct from transport).
ANALYSIS_TIMEOUT = 60
#: Poll cadence — each poll is one sub-second box call.
POLL_INTERVAL = 5
#: Per-task wall deadline (3x the ~59 s smoke run). On expiry -> MISSING.
ANALYSIS_DEADLINE = 180
#: How long we wait for a submitted task id to first appear on the FS/log.
SUBMIT_GRACE = 90
#: Backoff between the single retry of a transport error.
RETRY_BACKOFF = 3
#: Number of transport retries (design: "retried exactly once").
TRANSPORT_RETRIES = 1
#: Max base64 payload per fetch slice (keeps any single hop well under 45 s).
FETCH_CHUNK_BYTES = 2 * 2 ** 20  # 2 MB of *raw* file -> base64 ~2.7 MB

# --- Disk policy (design §7) --------------------------------------------
#: Enter constrained (prune) mode only if free space drops below this.
MIN_FREE_BYTES = 5 * 2 ** 30  # 5 GB

# --- Soundness (design §8) ----------------------------------------------
#: A report with fewer than this many total API calls AND no file/reg/net ops
#: is an "empty trace" (sample never detonated) -> INCONCLUSIVE, never 1.0 PASS.
#: 161 was the healthy benign reference (task 7991); a do-nothing stub is far
#: lower, so 20 sits well inside the gap.
MIN_API_CALLS = 20

#: Default behavioral similarity threshold (mirrors SandboxVerifier).
DEFAULT_THRESHOLD = SandboxVerifier.DEFAULT_THRESHOLD

#: Where raw reports + per-pair verdicts are persisted on the workstation
#: (design §5 — the box is ephemeral, results must survive teardown).
DEFAULT_REPORT_DIR = "assets/logs/cape_reports"

#: Placeholder substituted for the rl password in any logged command string.
_REDACTED = "<RLPASS>"
#: The rl password used for `sudo -S` on the box. Kept only in-memory; never
#: written to a log (see `_redact`). sbx.py keeps its own copy internal too.
#: ENV-OVERRIDABLE (host-config hygiene): the wheel embeds the lab default
#: "123" so in-lab use stays zero-config; a different box can set
#: ``FUNCVAL_CAPE_PASSWORD`` instead of shipping a credential in source.
_RL_PASSWORD = os.environ.get("FUNCVAL_CAPE_PASSWORD", "123")


# ======================================================================
# Exceptions
# ======================================================================

class CapeTransportError(Exception):
    """Local/remote transport failure (vmctl/sbx.py connect/exec/timeout)."""


class CapeSubmitError(Exception):
    """submit.py failed or no task id could be parsed (-> INCONCLUSIVE)."""


class CapeReportError(Exception):
    """report.json missing / oversized / corrupt (-> INCONCLUSIVE)."""


# ======================================================================
# Value types
# ======================================================================

class PollState(enum.Enum):
    """Terminal/intermediate states of a CAPE task (design §3.2)."""

    PENDING = "PENDING"   # queued; no analysis dir, no log line yet
    RUNNING = "RUNNING"   # analysis dir exists, no report.json yet
    DONE = "DONE"         # report.json present & non-empty (authoritative)
    FAILED = "FAILED"     # cuckoo.log marked the task failed
    MISSING = "MISSING"   # never appeared after the grace/deadline window


class BoxResult(NamedTuple):
    """Result of one `_box` call.

    Attributes:
        rc:        the LOCAL `vmctl ssh` wrapper return code (124 == local timeout).
        stdout:    the box command's stdout (trailer + ---STDERR--- stripped).
        stderr:    the box command's stderr (parsed from sbx.py's ---STDERR--- block).
        timed_out: True iff the LOCAL wrapper hit `local_timeout`.
        box_rc:    the REMOTE box command rc parsed from sbx.py's ---EXIT N--- trailer
                   (None if the trailer was absent — usually a sbx.py-level failure).
    """

    rc: int
    stdout: str
    stderr: str
    timed_out: bool
    box_rc: Optional[int]


# sbx.py trailer / separator markers (see /home/rl/sbx.py).
_EXIT_RE = re.compile(r"---EXIT (-?\d+)---\s*$")
_STDERR_SEP = "\n---STDERR---\n"
#: submit.py success line (design §3.1): 'added as task with ID <N>'.
_TASK_ID_RE = re.compile(r"added as task with ID (\d+)")
#: poll() ladder marker emitted by our combined box command (design §3.2).
_POLL_STATE_RE = re.compile(r"^STATE=(\w+)(?:\s+size=(\d+))?\s*$", re.MULTILINE)


def _redact(cmd: str) -> str:
    """Replace the rl password with a placeholder for safe logging (§8)."""
    return cmd.replace(_RL_PASSWORD, _REDACTED) if _RL_PASSWORD else cmd


def _is_empty_trace(report: Dict, *, min_api_calls: int = MIN_API_CALLS) -> bool:
    """Empty-trace gate (design §8).

    A report is "empty" — i.e. the sample never meaningfully detonated — when it
    has fewer than ``min_api_calls`` total API calls AND zero file/registry/
    network operations. ``compare_behavior`` would score empty-vs-empty as 1.0
    (vacuous multiset similarity), so an empty trace MUST force INCONCLUSIVE
    rather than feed an admissible PASS.

    Uses the reused ``SandboxVerifier.extract_behavior`` so the notion of
    "behavioral signature" is identical to the scorer's.
    """
    beh = SandboxVerifier.extract_behavior(report)
    n_api = len(beh.get("api_calls", []))
    n_other = (
        len(beh.get("file_ops", []))
        + len(beh.get("registry_ops", []))
        + len(beh.get("network_ops", []))
    )
    return n_api < min_api_calls and n_other == 0


# ======================================================================
# Client
# ======================================================================

class CapeCliClient:
    """CLI-submit + filesystem-poll transport for the CAPE box (design §9).

    The public surface mirrors ``SandboxVerifier`` (submit / poll / fetch /
    verify) but over the two-hop CLI transport. Scoring is delegated to the
    reused ``SandboxVerifier`` instance held in ``self._scorer``.
    """

    def __init__(
        self,
        *,
        vm_python: str = VM_PY,
        sbx_path: str = SBX_PATH,
        vmctl: str = VMCTL,
        transport: str = "auto",
        repo_root: Optional[str] = None,
        guests: Sequence[str] = DEFAULT_GUESTS,
        analysis_timeout: int = ANALYSIS_TIMEOUT,
        poll_interval: int = POLL_INTERVAL,
        analysis_deadline: int = ANALYSIS_DEADLINE,
        submit_grace: int = SUBMIT_GRACE,
        threshold: float = DEFAULT_THRESHOLD,
        report_dir: str = DEFAULT_REPORT_DIR,
        min_free_bytes: int = MIN_FREE_BYTES,
        min_api_calls: int = MIN_API_CALLS,
        local_timeout: int = LOCAL_TIMEOUT,
        require_isolation_for_malicious: bool = True,
        build_log: Optional[str] = None,
    ) -> None:
        """
        Args:
            vm_python:  python with paramiko on the PRIMARY VM (drives sbx.py).
            sbx_path:   path to the sbx.py driver on the PRIMARY VM.
            vmctl:      the local control-plane wrapper (`scripts/vmctl`).
            transport:  how the `<vm_python> sbx.py <b64>` command is dispatched:
                        "vmctl"  -> wrap as `vmctl ssh '<cmd>'` (running on a
                                    WORKSTATION; two-hop into the PRIMARY VM).
                        "local"  -> run `<cmd>` DIRECTLY via subprocess, no vmctl
                                    wrapper (already ON the PRIMARY VM, where
                                    sbx.py + vm_python are local).
                        "auto"   -> (default) "vmctl" if the resolved vmctl path
                                    is an existing executable file, else "local".
            repo_root:  repo root for resolving vmctl + report_dir; defaults to
                        the repo this module lives in (two dirs up from lib/pe_shim).
            guests:     the fixed roster of CAPE guests for round-robin fan-out.
            analysis_timeout: guest detonation budget (submit.py --timeout).
            poll_interval:    seconds between filesystem polls.
            analysis_deadline: per-task wall deadline; on expiry -> MISSING.
            submit_grace:     seconds to wait for a task id to first appear.
            threshold:  composite-similarity PASS threshold.
            report_dir: workstation dir where raw reports are persisted.
            min_free_bytes: constrained-mode trigger for disk pruning.
            min_api_calls:  empty-trace gate threshold.
            local_timeout:  local `vmctl ssh` wrapper bound (rc=124 on expiry).
            require_isolation_for_malicious: refuse malicious samples until a
                        network-isolation sentinel confirms containment.
            build_log:  optional path; box output is tee'd here (password redacted).
        """
        self.vm_python = vm_python
        self.sbx_path = sbx_path
        self.vmctl = vmctl
        self.repo_root = Path(repo_root) if repo_root else _default_repo_root()
        # Resolve the transport (construction stays INERT — no network/SSH here).
        self.transport = _resolve_transport(transport, vmctl, self.repo_root)
        self.guests: List[str] = list(guests)
        if not self.guests:
            raise ValueError("at least one guest is required")
        self.analysis_timeout = analysis_timeout
        self.poll_interval = poll_interval
        self.analysis_deadline = analysis_deadline
        self.submit_grace = submit_grace
        self.threshold = threshold
        self.report_dir = (self.repo_root / report_dir
                           if not os.path.isabs(report_dir) else Path(report_dir))
        self.min_free_bytes = min_free_bytes
        self.min_api_calls = min_api_calls
        self.local_timeout = local_timeout
        self.require_isolation_for_malicious = require_isolation_for_malicious
        self.build_log = build_log

        # Reused scorer — never re-implement extract_behavior/compare_behavior.
        # Constructed via __new__ to avoid SandboxVerifier.__init__'s `requests`
        # import requirement (this transport uses no HTTP at all).
        self._scorer = SandboxVerifier.__new__(SandboxVerifier)
        self._scorer.threshold = threshold

        self._guest_rr = 0  # round-robin cursor for _next_guest

    # ------------------------------------------------------------------
    # Transport primitive (design §2) — the ONLY place that knows vmctl+sbx.py
    # ------------------------------------------------------------------

    def _wrap_ctl(self, b64: str) -> List[str]:
        """Return the argv for ``subprocess.run`` that dispatches the base64 box
        command, branching ONLY on ``self.transport`` (the single dispatch fork).

        The underlying invocation is always ``<vm_python> sbx.py <b64>``:
          * ``transport="vmctl"`` (workstation): wrap it as
            ``[vmctl, "ssh", "<vm_python> sbx.py <b64>"]`` so vmctl hops into the
            PRIMARY VM and runs it there.
          * ``transport="local"`` (already ON the PRIMARY VM): run it directly as
            ``[vm_python, sbx.py, b64]`` with NO vmctl wrapper — sbx.py and the
            vm python are local here, so the hop would be nonsensical.

        Both branches share the SAME timeout/retry/error handling in ``_box``;
        only the command shape differs.
        """
        if self.transport == "local":
            return [self.vm_python, self.sbx_path, b64]
        # "vmctl": preserve the historical two-hop wrapper byte-for-byte.
        outer = f"{self.vm_python} {self.sbx_path} {b64}"
        return [self.vmctl, "ssh", outer]

    def _box(self, remote_cmd: str, *, exec_timeout: int = EXEC_TIMEOUT,
             local_timeout: Optional[int] = None, retries: int = TRANSPORT_RETRIES,
             redact: bool = False) -> BoxResult:
        """Run ``remote_cmd`` on the CAPE box via the primary-VM hop.

        Pipeline (design §2):
            b64  = base64(remote_cmd)
            argv = self._wrap_ctl(b64)   # transport-dependent dispatch:
                                         #   "vmctl": [VMCTL, "ssh", "<VM_PY> sbx.py <b64>"]
                                         #   "local": [VM_PY, sbx.py, b64]  (on the VM)
            proc = subprocess.run(argv, timeout=local_timeout)

        Only the argv SHAPE differs by transport; everything below (timeout,
        retry, trailer parse, error mapping) is identical for both modes.

        ``exec_timeout`` is advisory here — sbx.py hard-caps remote exec at 45 s.
        ``local_timeout`` bounds the LOCAL shell so we NEVER hang; on expiry the
        wrapper returns rc=124 and we surface a transport error after one retry.

        Transport errors (local timeout, sbx.py connect/exec failure) are retried
        exactly once with a backoff. A non-zero *box* rc is NOT a transport error
        (the box command itself ran) — it is returned for the caller to interpret.
        """
        if local_timeout is None:
            local_timeout = self.local_timeout
        b64 = base64.b64encode(remote_cmd.encode("utf-8")).decode("ascii")
        argv = self._wrap_ctl(b64)

        last_exc: Optional[Exception] = None
        for attempt in range(retries + 1):
            try:
                proc = subprocess.run(
                    argv,
                    cwd=str(self.repo_root),
                    timeout=local_timeout,
                    capture_output=True,
                    text=True,
                )
            except subprocess.TimeoutExpired as exc:
                # LOCAL timeout — the control plane flaked. rc=124, retry once.
                last_exc = CapeTransportError(
                    f"local vmctl ssh timed out after {local_timeout}s "
                    f"(box cmd: {_redact(remote_cmd)[:120]!r})"
                )
                self._tee(f"[BOX_LOCAL_TIMEOUT attempt={attempt}] "
                          f"{_redact(remote_cmd)[:200]}")
                if attempt < retries:
                    time.sleep(RETRY_BACKOFF)
                    continue
                raise last_exc from exc

            combined = proc.stdout or ""
            box_rc, box_out, box_err = self._parse_trailer(combined)

            # sbx.py-level failure (no EXIT trailer): connect/exec fail or bad b64.
            if box_rc is None:
                detail = (proc.stderr or "").strip() or combined.strip()
                last_exc = CapeTransportError(
                    f"sbx.py produced no ---EXIT--- trailer (local_rc={proc.returncode}): "
                    f"{detail[:300]}"
                )
                self._tee(f"[BOX_NO_TRAILER attempt={attempt}] rc={proc.returncode} "
                          f"{_redact(remote_cmd)[:120]} :: {detail[:200]}")
                # A connect/exec fail (sbx.py rc 3/4) is a transport error -> retry.
                if attempt < retries:
                    time.sleep(RETRY_BACKOFF)
                    continue
                raise last_exc

            self._tee(
                f"[BOX] local_rc={proc.returncode} box_rc={box_rc} "
                f"cmd={_redact(remote_cmd)[:200] if redact else remote_cmd[:200]}"
            )
            return BoxResult(
                rc=proc.returncode,
                stdout=box_out,
                stderr=box_err,
                timed_out=False,
                box_rc=box_rc,
            )

        # Unreachable, but keep the type checker honest.
        raise last_exc or CapeTransportError("unknown transport error")

    @staticmethod
    def _parse_trailer(combined: str) -> "tuple[Optional[int], str, str]":
        """Split sbx.py's combined output into (box_rc, stdout, stderr).

        sbx.py emits:  ``<stdout>[\\n---STDERR---\\n<stderr>]\\n---EXIT <N>---\\n``
        Returns box_rc=None if no ---EXIT--- trailer is present (sbx.py-level fail).
        """
        m = _EXIT_RE.search(combined.rstrip())
        if not m:
            return None, combined, ""
        box_rc = int(m.group(1))
        body = combined[: m.start()].rstrip("\n")
        if _STDERR_SEP in body:
            out, err = body.split(_STDERR_SEP, 1)
        else:
            out, err = body, ""
        return box_rc, out, err

    def _tee(self, line: str) -> None:
        """Append a redacted line to the build log if one is configured (§5/§11)."""
        if not self.build_log:
            return
        try:
            path = (self.repo_root / self.build_log
                    if not os.path.isabs(self.build_log) else Path(self.build_log))
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {_redact(line)}\n")
        except OSError:
            pass  # logging must never break the transport

    # ------------------------------------------------------------------
    # Internal box-command builders
    # ------------------------------------------------------------------

    @staticmethod
    def _sudo_cape(inner: str) -> str:
        """Wrap ``inner`` to run as the `cape` user via ``sudo -S`` (password on
        stdin — `sudo -u cape` is NOT passwordless on this box, design correction).

        The password is supplied via ``printf | sudo -S`` so it never appears as
        an argv element; ``_redact`` masks it in any tee'd log.
        """
        # `printf '%s\n' '<pw>' | sudo -S -u cape bash -lc '<inner>'`
        return (
            f"printf '%s\\n' {shlex.quote(_RL_PASSWORD)} | "
            f"sudo -S -u cape bash -lc {shlex.quote(inner)}"
        )

    def _next_guest(self) -> str:
        """Round-robin the next healthy guest (design §4)."""
        guest = self.guests[self._guest_rr % len(self.guests)]
        self._guest_rr += 1
        return guest

    # ------------------------------------------------------------------
    # Disk policy (design §7) — prune ONLY when constrained, via cleaners.py
    # ------------------------------------------------------------------

    def _free_bytes(self) -> Optional[int]:
        """Return free bytes on the box's `/`, or None if the probe failed."""
        r = self._box("df --output=avail -B1 / | tail -1", exec_timeout=10)
        if r.box_rc != 0:
            return None
        try:
            return int(r.stdout.strip().splitlines()[-1])
        except (ValueError, IndexError):
            return None

    def _ensure_space(self) -> None:
        """Enter constrained mode and prune (least-destructive first) only if
        free space is below ``min_free_bytes`` (design §7). Never proactive,
        never raw ``rm`` — always CAPE's own ``utils/cleaners.py`` via poetry.
        """
        free = self._free_bytes()
        if free is None or free >= self.min_free_bytes:
            return
        self._tee(f"[ENSURE_SPACE] constrained: free={free} < {self.min_free_bytes}")
        steps = (
            "cd /opt/CAPEv2 && /etc/poetry/bin/poetry run python "
            "utils/cleaners.py --delete-tmp-items-older-than 1",
            "cd /opt/CAPEv2 && /etc/poetry/bin/poetry run python "
            'utils/cleaners.py --delete-older-than "7 days"',
            "cd /opt/CAPEv2 && /etc/poetry/bin/poetry run python "
            'utils/cleaners.py --delete-binaries-items-older-than "14 days"',
        )
        for inner in steps:
            self._box(self._sudo_cape(inner), exec_timeout=EXEC_TIMEOUT, redact=True)
            free = self._free_bytes()
            if free is not None and free >= self.min_free_bytes:
                return

    # ------------------------------------------------------------------
    # Submit (design §3.1)
    # ------------------------------------------------------------------

    def _stage_pe(self, pe_bytes: bytes) -> str:
        """Write ``pe_bytes`` to ``/tmp/capecli/<sha16>.exe`` on the box, verifying
        the echoed sha256 matches before returning the path (catches truncation).

        For typical 15 KB benign PEs this is a single base64 here-doc chunk; the
        ``sha256sum`` gate makes a half-upload a hard error, never a silent pass.
        """
        sha = hashlib.sha256(pe_bytes).hexdigest()
        path = f"{BOX_STAGING_DIR}/{sha[:16]}.exe"
        b64 = base64.b64encode(pe_bytes).decode("ascii")
        # Chunk the base64 payload so no single here-doc exceeds the arg/exec budget.
        chunks = [b64[i:i + 700_000] for i in range(0, len(b64), 700_000)] or [""]

        # First chunk truncates (>), subsequent chunks append (>>); final sha gate.
        for idx, chunk in enumerate(chunks):
            redir = ">" if idx == 0 else ">>"
            cmd = (
                f"mkdir -p {BOX_STAGING_DIR} && "
                f"base64 -d {redir} {path} <<'B64'\n{chunk}\nB64\n"
            )
            r = self._box(cmd, exec_timeout=EXEC_TIMEOUT)
            if r.box_rc != 0:
                raise CapeSubmitError(
                    f"staging chunk {idx} failed (box_rc={r.box_rc}): "
                    f"{r.stderr[:200] or r.stdout[:200]}"
                )

        r = self._box(f"chmod 0644 {path} && sha256sum {path}", exec_timeout=10)
        if r.box_rc != 0:
            raise CapeSubmitError(f"chmod/sha256sum failed (box_rc={r.box_rc})")
        echoed = (r.stdout.strip().split() or [""])[0]
        if echoed != sha:
            raise CapeSubmitError(
                f"staged PE sha mismatch: expected {sha[:16]}..., got {echoed[:16]}... "
                "(upload truncated)"
            )
        return path

    def submit(self, pe_bytes: bytes, *, machine: Optional[str] = None,
               timeout: Optional[int] = None, package: Optional[str] = None) -> int:
        """Stage + submit a PE; return the integer task id (does NOT wait).

        The verified-working incantation auto-detects the package (no ``--package``):
            cd /opt/CAPEv2 && poetry run python utils/submit.py
            --machine <GUEST> --timeout <T> <PE_PATH>

        Args:
            pe_bytes: raw PE bytes.
            machine:  guest to pin (defaults to the first guest in the roster).
            timeout:  guest analysis timeout (defaults to ``analysis_timeout``).
            package:  CAPE package; default None = let CAPE auto-detect (the
                      Phase-0-verified path). Pass "exe" only if auto-detect ever
                      misfires.

        Raises:
            CapeSubmitError: box_rc != 0 or no task id parsed (NEVER auto-retried —
                a blind resubmit risks a duplicate task; caller -> INCONCLUSIVE).
        """
        machine = machine or self.guests[0]
        timeout = self.analysis_timeout if timeout is None else timeout
        path = self._stage_pe(pe_bytes)

        pkg = f"--package {shlex.quote(package)} " if package else ""
        inner = (
            f"cd {CAPE_ROOT} && {POETRY_BIN} run python utils/submit.py "
            f"--machine {shlex.quote(machine)} --timeout {int(timeout)} "
            f"{pkg}{shlex.quote(path)}"
        )
        r = self._box(self._sudo_cape(inner), exec_timeout=SUBMIT_EXEC_TIMEOUT,
                      redact=True)
        if r.box_rc != 0:
            raise CapeSubmitError(
                f"submit.py box_rc={r.box_rc} (machine={machine}): "
                f"{(r.stderr or r.stdout)[:400]}"
            )
        m = _TASK_ID_RE.search(r.stdout)
        if not m:
            # The known bypass-poetry failure (NameError: pefile) surfaces here verbatim.
            raise CapeSubmitError(
                f"no task id in submit output (machine={machine}): "
                f"{(r.stdout + ' ' + r.stderr)[:400]}"
            )
        return int(m.group(1))

    # ------------------------------------------------------------------
    # Poll (design §3.2) — filesystem + cuckoo.log, NOT HTTP
    # ------------------------------------------------------------------

    def _poll_box_cmd(self, task_id: int) -> str:
        """Build the combined detection-ladder box command for ``task_id``.

        Emits exactly one ``STATE=<...>`` line plus (for the RUNNING/FAILED
        disambiguation) up to 3 cuckoo.log lines. ``poll()`` parses the result.
        """
        tid = int(task_id)
        adir = f"{CAPE_ROOT}/storage/analyses/{tid}"
        rpt = f"{adir}/reports/report.json"
        # cuckoo.log is the legacy name on this box; journalctl is the fallback.
        return (
            f'ADIR={shlex.quote(adir)}; RPT={shlex.quote(rpt)}; '
            f'if [ -s "$RPT" ]; then echo "STATE=DONE size=$(stat -c%s "$RPT")"; exit 0; fi; '
            f'LOGHIT=$(grep -E "Task #{tid}[: ].*([Ff]ailed|errors?)|task {tid} status failed" '
            f'{CUCKOO_LOG} 2>/dev/null | tail -3); '
            f'if [ -z "$LOGHIT" ]; then '
            f'LOGHIT=$(journalctl -u cape --no-pager 2>/dev/null | '
            f'grep -E "Task #{tid}[: ].*([Ff]ailed|errors?)" | tail -3); fi; '
            f'if [ -n "$LOGHIT" ]; then echo "STATE=FAILED"; echo "$LOGHIT"; '
            f'elif [ -d "$ADIR" ]; then echo "STATE=RUNNING"; '
            f'else echo "STATE=PENDING"; fi'
        )

    def poll(self, task_id: int, *, machine_hint: Optional[str] = None) -> PollState:
        """Return the current ``PollState`` of ``task_id`` (one cheap box call).

        Detection ladder (design §3.2, corrected to cuckoo.log):
          * ``report.json`` present & non-empty -> DONE (authoritative).
          * cuckoo.log (or journalctl) marks the task failed -> FAILED.
          * analysis dir exists, no report, no failure -> RUNNING.
          * neither dir nor log line -> PENDING.

        A transport failure during poll surfaces as ``CapeTransportError`` after
        the single retry inside ``_box`` — the caller's deadline loop treats a
        persistent transport failure as MISSING (-> INCONCLUSIVE).
        """
        r = self._box(self._poll_box_cmd(task_id), exec_timeout=15)
        m = _POLL_STATE_RE.search(r.stdout)
        if not m:
            # Box command ran but emitted no STATE line — treat as PENDING so the
            # deadline loop keeps trying rather than declaring a false terminal.
            return PollState.PENDING
        state = m.group(1)
        try:
            return PollState[state]
        except KeyError:
            return PollState.PENDING

    @staticmethod
    def _parse_poll_state(stdout: str) -> "tuple[PollState, Optional[int]]":
        """Parse a poll box-command stdout into (PollState, report_size|None).

        Split out for offline unit testing of the ladder string parsing.
        """
        m = _POLL_STATE_RE.search(stdout)
        if not m:
            return PollState.PENDING, None
        try:
            state = PollState[m.group(1)]
        except KeyError:
            return PollState.PENDING, None
        size = int(m.group(2)) if m.group(2) else None
        return state, size

    def await_terminal(self, task_ids: Sequence[int], *,
                       deadline: Optional[int] = None) -> Dict[int, PollState]:
        """Poll ``task_ids`` on the fixed cadence until each reaches a terminal
        state (DONE/FAILED) or the wall deadline expires (-> MISSING).

        Returns a ``{task_id: PollState}`` map. Never hangs: bounded by
        ``deadline`` (default ``analysis_deadline``) and a ``submit_grace``
        window during which a still-PENDING/MISSING task that never appears is
        declared MISSING.
        """
        deadline = self.analysis_deadline if deadline is None else deadline
        start = time.monotonic()
        states: Dict[int, PollState] = {int(t): PollState.PENDING for t in task_ids}
        first_seen: Dict[int, float] = {}

        while True:
            now = time.monotonic()
            elapsed = now - start
            pending = [t for t, s in states.items()
                       if s not in (PollState.DONE, PollState.FAILED, PollState.MISSING)]
            if not pending:
                return states

            for tid in pending:
                try:
                    st = self.poll(tid)
                except CapeTransportError:
                    st = states[tid]  # keep prior; deadline will catch persistence
                states[tid] = st
                if st in (PollState.RUNNING, PollState.DONE, PollState.FAILED):
                    first_seen.setdefault(tid, now)
                # Grace: a task that never even appears (PENDING) past submit_grace
                # is MISSING (scheduler never picked it up).
                if (st == PollState.PENDING and tid not in first_seen
                        and elapsed >= self.submit_grace):
                    states[tid] = PollState.MISSING

            # Wall deadline: anything still non-terminal becomes MISSING.
            if time.monotonic() - start >= deadline:
                for tid, s in states.items():
                    if s not in (PollState.DONE, PollState.FAILED, PollState.MISSING):
                        states[tid] = PollState.MISSING
                return states

            time.sleep(self.poll_interval)

    def _await_both(self, t_orig: int, t_mut: int) -> Dict[int, PollState]:
        """Convenience: await a (orig, mut) pair concurrently (design §3.4)."""
        return self.await_terminal((t_orig, t_mut))

    # ------------------------------------------------------------------
    # Fetch report (design §3.3 / §5) — chunked + checksummed, never {}
    # ------------------------------------------------------------------

    def fetch_report(self, task_id: int, *, projection: Optional[str] = None) -> Dict:
        """Pull ``storage/analyses/<id>/reports/report.json`` off the box, verify
        its sha256, persist the raw bytes, and return the parsed dict.

        NEVER returns ``{}`` silently — an empty dict would score 1.0. Any
        missing/oversized/corrupt condition raises ``CapeReportError`` (caller
        maps to INCONCLUSIVE).

        Args:
            projection: reserved for the optional slim ``behavior``-only fast path
                        (design §3.3 note); default None = full report for audit.
        """
        tid = int(task_id)
        rpt = f"{CAPE_ROOT}/storage/analyses/{tid}/reports/report.json"

        # 1) size + sha256 gate.
        r = self._box(
            f'if [ ! -s {shlex.quote(rpt)} ]; then echo "MISSING"; exit 0; fi; '
            f'echo "SIZE=$(stat -c%s {shlex.quote(rpt)})"; sha256sum {shlex.quote(rpt)}',
            exec_timeout=15,
        )
        out = r.stdout.strip()
        if r.box_rc != 0 or out.startswith("MISSING") or not out:
            raise CapeReportError(f"report.json missing for task {tid}")
        size_m = re.search(r"SIZE=(\d+)", out)
        sha_m = re.search(r"\b([0-9a-f]{64})\b", out)
        if not size_m or not sha_m:
            raise CapeReportError(
                f"could not stat/checksum report for task {tid}: {out[:200]}")
        size = int(size_m.group(1))
        box_sha = sha_m.group(1)
        if size == 0:
            raise CapeReportError(f"report.json is empty for task {tid}")
        if size > MAX_REPORT_BYTES:
            raise CapeReportError(
                f"report.json oversized ({size} > {MAX_REPORT_BYTES}) for task {tid} "
                "(malformed run)")

        # 2) chunked base64 egress. Each slice is a fixed byte range of the file;
        #    base64 expands ~4/3, so a 2 MB raw slice -> ~2.7 MB of b64, still
        #    well within a single 45 s hop.
        raw = bytearray()
        offset = 0
        while offset < size:
            length = min(FETCH_CHUNK_BYTES, size - offset)
            # Byte-range slice via tail+head (block-buffered, fast) then base64.
            # `tail -c +N` is 1-indexed, so the first byte is +1.
            slice_cmd = (
                f"tail -c +{offset + 1} {shlex.quote(rpt)} | head -c {length} | base64 -w0"
            )
            cr = self._box(slice_cmd, exec_timeout=EXEC_TIMEOUT)
            if cr.box_rc != 0:
                raise CapeReportError(
                    f"fetch chunk @ {offset} failed for task {tid} (box_rc={cr.box_rc})")
            try:
                raw.extend(base64.b64decode(cr.stdout.strip()))
            except Exception as exc:  # noqa: BLE001 - any decode error == corruption
                raise CapeReportError(
                    f"base64 decode failed for task {tid} chunk @ {offset}: {exc}")
            offset += length

        # 3) checksum the reassembled bytes against the box's.
        local_sha = hashlib.sha256(bytes(raw)).hexdigest()
        if local_sha != box_sha:
            raise CapeReportError(
                f"report sha mismatch for task {tid}: box={box_sha[:16]} "
                f"local={local_sha[:16]} (transport corruption)")

        # 4) parse.
        try:
            report = json.loads(bytes(raw).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise CapeReportError(f"report.json parse error for task {tid}: {exc}")
        if not isinstance(report, dict) or not report:
            raise CapeReportError(f"report.json for task {tid} parsed to empty/non-dict")

        # 5) persist raw report (the box is ephemeral — design §5).
        try:
            self.report_dir.mkdir(parents=True, exist_ok=True)
            (self.report_dir / f"{tid}.report.json").write_bytes(bytes(raw))
        except OSError as exc:
            self._tee(f"[FETCH_PERSIST_WARN] task {tid}: {exc}")

        return report

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _cleanup_staging(self, *sha_or_paths: str) -> None:
        """Delete this client's staged PEs from the box (design §7 — our own
        scratch is our responsibility; never contribute to the 90% disk)."""
        paths = " ".join(shlex.quote(p) for p in sha_or_paths if p)
        if not paths:
            return
        try:
            self._box(f"rm -f {paths}", exec_timeout=10)
        except CapeTransportError:
            pass  # best-effort; box is ephemeral anyway

    # ------------------------------------------------------------------
    # Batch helpers (design §4)
    # ------------------------------------------------------------------

    def submit_many(self, pe_list: Sequence[bytes]) -> List[int]:
        """Submit a batch, pinning task i to ``guests[i % len(guests)]`` and
        keeping at most ``MAX_IN_FLIGHT`` tasks outstanding (client-side
        semaphore — design §4)."""
        task_ids: List[int] = []
        in_flight: List[int] = []
        for i, pe in enumerate(pe_list):
            if len(in_flight) >= MAX_IN_FLIGHT:
                # Wait for at least one to reach terminal before submitting more.
                states = self.await_terminal(in_flight)
                in_flight = [t for t in in_flight
                             if states.get(t) not in
                             (PollState.DONE, PollState.FAILED, PollState.MISSING)]
            tid = self.submit(pe, machine=self.guests[i % len(self.guests)])
            task_ids.append(tid)
            in_flight.append(tid)
        return task_ids

    # ------------------------------------------------------------------
    # End-to-end pair verification (design §3.4) — the L6 entry point
    # ------------------------------------------------------------------

    def verify_pair(self, orig_bytes: bytes, mut_bytes: bytes, *,
                    timeout: Optional[int] = None,
                    threshold: Optional[float] = None,
                    is_malicious: bool = False) -> Dict:
        """Submit both PEs to different guests, await, fetch, score, decide.

        Returns a dict whose shape matches ``SandboxVerifier.verify_preservation``:
            {preserved: bool|None, similarity: float, threshold: float,
             orig_task_id, mut_task_id, details: <compare_behavior dict>,
             status, error}

        Soundness (design §8): every terminal non-PASS condition — CAPE/transport
        down, FAILED/MISSING analysis, fetch corruption, empty trace — yields
        ``preserved=None, status="INCONCLUSIVE"``, NEVER a silent PASS.
        """
        threshold = self.threshold if threshold is None else threshold
        timeout = self.analysis_timeout if timeout is None else timeout

        result: Dict = {
            "preserved": None,
            "similarity": 0.0,
            "threshold": threshold,
            "orig_task_id": None,
            "mut_task_id": None,
            "details": {},
            "status": "INCONCLUSIVE",
            "error": None,
        }

        # Containment guard (design §8): refuse malicious samples unless isolated.
        if is_malicious and self.require_isolation_for_malicious:
            if not self._isolation_active():
                result["error"] = (
                    "refusing malicious sample: network-isolation sentinel absent "
                    "(run scripts/cape_isolate_default_net.sh apply first)")
                return result

        staged: List[str] = []
        try:
            self._ensure_space()
            g_o, g_m = self._next_guest(), self._next_guest()
            t_orig = self.submit(orig_bytes, machine=g_o, timeout=timeout)
            t_mut = self.submit(mut_bytes, machine=g_m, timeout=timeout)
            result["orig_task_id"] = t_orig
            result["mut_task_id"] = t_mut
            staged = [
                f"{BOX_STAGING_DIR}/{hashlib.sha256(orig_bytes).hexdigest()[:16]}.exe",
                f"{BOX_STAGING_DIR}/{hashlib.sha256(mut_bytes).hexdigest()[:16]}.exe",
            ]

            states = self._await_both(t_orig, t_mut)
            for tid in (t_orig, t_mut):
                if states.get(tid) != PollState.DONE:
                    result["error"] = (
                        f"task {tid} did not complete (state="
                        f"{states.get(tid).value if states.get(tid) else '?'})")
                    return result

            rep_o = self.fetch_report(t_orig)
            rep_m = self.fetch_report(t_mut)

            # Empty-trace gate BEFORE deciding preserved (design §8).
            if (_is_empty_trace(rep_o, min_api_calls=self.min_api_calls)
                    or _is_empty_trace(rep_m, min_api_calls=self.min_api_calls)):
                cmp = self._scorer.compare_behavior(rep_o, rep_m)
                result["similarity"] = cmp["composite_similarity"]
                result["details"] = cmp
                result["error"] = "empty trace (sample did not detonate)"
                return result

            # REUSE the existing scorer — do not re-implement.
            cmp = self._scorer.compare_behavior(rep_o, rep_m)
            sim = cmp["composite_similarity"]
            result["similarity"] = sim
            result["details"] = cmp
            result["preserved"] = sim >= threshold
            result["status"] = "PASS" if result["preserved"] else "FAIL"
            result["error"] = None
            return result

        except CapeSubmitError as exc:
            result["error"] = f"submit failed: {exc}"
            return result
        except CapeReportError as exc:
            result["error"] = f"report fetch failed: {exc}"
            return result
        except CapeTransportError as exc:
            result["error"] = f"transport failed: {exc}"
            return result
        finally:
            if staged:
                self._cleanup_staging(*staged)

    # ------------------------------------------------------------------
    # Isolation sentinel (design §8)
    # ------------------------------------------------------------------

    def _isolation_active(self) -> bool:
        """True iff the network-isolation sentinel file exists on the box (written
        by ``scripts/cape_isolate_default_net.sh``'s verification stanza)."""
        try:
            r = self._box(
                "test -f /opt/CAPEv2/.network_isolated && echo ISOLATED || echo OPEN",
                exec_timeout=10,
            )
        except CapeTransportError:
            return False
        return "ISOLATED" in r.stdout


def _default_repo_root() -> Path:
    """Resolve the repo root (two parents up from lib/pe_shim/<this file>)."""
    return Path(__file__).resolve().parents[2]


def _vmctl_is_runnable(vmctl: str, repo_root: Path) -> bool:
    """True iff ``vmctl`` resolves to an existing executable file.

    Detection is robust to a relative ``vmctl`` (the default ``scripts/vmctl``):
    we probe the path as-is, relative to ``repo_root``, relative to the cwd, and
    via ``PATH`` (``shutil.which``). Purely a filesystem/stat check — INERT, no
    process is spawned, so construction never touches the network/SSH.
    """
    candidates = [Path(vmctl)]
    if not os.path.isabs(vmctl):
        candidates.append(repo_root / vmctl)
        candidates.append(Path.cwd() / vmctl)
    for cand in candidates:
        try:
            if cand.is_file() and os.access(str(cand), os.X_OK):
                return True
        except OSError:
            continue
    return shutil.which(vmctl) is not None


def _resolve_transport(transport: str, vmctl: str, repo_root: Path) -> str:
    """Resolve the requested ``transport`` to a concrete ``"vmctl"``/``"local"``.

    "auto" picks "vmctl" when the resolved vmctl path is a runnable executable
    (we're on a workstation), else "local" (vmctl absent ⇒ we're on the PRIMARY
    VM, where sbx.py + vm_python are local). "vmctl"/"local" pass through.
    """
    if transport == "auto":
        return "vmctl" if _vmctl_is_runnable(vmctl, repo_root) else "local"
    if transport in ("vmctl", "local"):
        return transport
    raise ValueError(
        f"transport must be 'auto', 'vmctl', or 'local'; got {transport!r}"
    )
