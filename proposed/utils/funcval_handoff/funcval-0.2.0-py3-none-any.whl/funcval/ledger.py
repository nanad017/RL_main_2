"""Composition of step evidence and the single admissibility gate.

Two public functions:

* :func:`compose` — combine a chain of per-step evidences into one verdict,
  REFUSING TO OVERCLAIM.  Refutation dominates, Unknown poisons, and an
  unverified scope precondition yields Unknown rather than a falsely confident
  PASS.
* :func:`admit` — THE single gate.  It is the only place a number is compared,
  and the number is always the same quantity: a false-admit upper bound.

The composition soundness hole this module is built to close (the "R8-clobber"
problem): a chain ``s0 ; s1 ; ...`` is equivalent only if each step compared
(its ``live_out``) covers every state that a LATER step reads (its live-in).
If step 0 was only checked on ``rax`` but step 1 reads ``r8``, then step 0 may
silently clobber ``r8`` in a way the per-step check never saw, and the chain is
NOT proven equivalent even though every individual step "passed".  When the
caller cannot supply the later steps' live-in sets, we cannot verify this
precondition, so we return Unknown — never a ``min()``-capped PASS.
"""
from __future__ import annotations

from typing import List, Optional

from .bounds import union_bound
from .evidence import (
    ComposedBound,
    Evidence,
    Proof,
    Scope,
    Unknown,
)

# --- Full architectural-state vocabulary -----------------------------------
# The identical-scope compose shortcut (no explicit live_in needed) is only
# SOUND when the shared proof scope is the FULL architectural state: then any
# later step reads only state an earlier step already proved equivalent.  A
# proof over a PARTIAL scope (e.g. {rax}) says nothing about the rest, so two
# {rax}-only proofs must NOT bypass the scope precondition.  We define the full
# vocabulary to match the producing oracles' scope naming (ProvenOracle's
# _FULL_STATE_LIVE_OUT and LocalEquivOracle's live_out_names) so set-equality is
# the airtight test.

_GPR_NAMES_64 = (
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
)
_XMM_NAMES = tuple(f"xmm{i}" for i in range(16))

#: The full architectural-state live-out: all 16 GPRs + all 16 XMM + eflags.
#: A proof whose scope equals THIS is a full-state proof and may take the
#: no-live_in compose shortcut; any smaller scope may not.
FULL_STATE_LIVE_OUT = frozenset(_GPR_NAMES_64 + _XMM_NAMES + ("eflags",))


def _intersect_live_outs(steps: List[Evidence]) -> frozenset:
    """Intersection of every step's compared ``live_out``.

    This is the state guaranteed compared by ALL steps; it is the only honest
    scope for the composed verdict (a composite can only claim state that every
    step actually checked).
    """
    result: Optional[frozenset] = None
    for s in steps:
        sc = s.scope
        lo = sc.live_out if sc is not None else frozenset()
        result = lo if result is None else (result & lo)
    return result if result is not None else frozenset()


def _all_proofs_identical_full_scope(steps: List[Evidence]) -> bool:
    """True iff every step is a Proof and they all share one identical scope that
    is the FULL architectural state.

    When that holds, composition is safe without explicit live-in data: each step
    is proven equivalent over the SAME full architectural state, so any later step
    reads only state an earlier step already proved equivalent.

    The earlier version tested merely ``len(scopes) == 1`` — but that fires for a
    PARTIAL shared scope too (e.g. two ``{rax}``-only proofs), which is UNSOUND:
    a later step may read ``rbx``, which neither proof compared.  So the shortcut
    now requires the shared scope to EQUAL :data:`FULL_STATE_LIVE_OUT`; any
    smaller scope falls through to the explicit-live_in precondition (and is
    Unknown when no live_in is supplied).
    """
    if not steps:
        return False
    if not all(isinstance(s, Proof) for s in steps):
        return False
    scopes = {s.scope.live_out for s in steps if s.scope is not None}
    if len(scopes) != 1:
        return False
    (shared,) = tuple(scopes)
    return shared == FULL_STATE_LIVE_OUT


def compose(
    step_evidences: List[Evidence],
    *,
    live_in_of_later_steps: Optional[List[frozenset]] = None,
) -> Evidence:
    """Combine per-step evidence into a single chain verdict, conservatively.

    Decision order (each rule is applied before the next):

    1. Empty chain -> :class:`Unknown` (nothing was verified).
    2. ANY step is :class:`Refuted` -> return that exact Refuted.  A sound NO
       on any step refutes the whole chain (refutation dominates).
    3. ANY step is :class:`Unknown` -> return ``Unknown`` (an unverified step
       poisons the chain; we cannot claim the whole is equivalent).
    4. SCOPE PRECONDITION (the R8-clobber hole):
       * If ``live_in_of_later_steps`` is provided, verify for each step ``i``
         that ``step_i.scope.live_out`` is a SUPERSET of the union of every
         later step's live-in (``j > i``).  If any step violates this, the
         steps interact through state that was never compared ->
         ``Unknown("steps interact through uncompared state: ...")``.
       * If ``live_in_of_later_steps`` is ``None``, the precondition is
         UNVERIFIED.  We return ``Unknown("composition scope precondition
         unverified")`` UNLESS every step is a Proof sharing one identical
         scope (then the chain is provably safe and we proceed).
    5. Combine the surviving (confirming) evidence:
       * Every step a Proof -> a composed :class:`Proof` with bound ``0.0``.
         The composed cert is an ``SDM_ARGUMENT`` derived cert tagged with the
         weakest input cert kind; ``recheckable`` is the AND of the inputs.
       * Otherwise -> a :class:`ComposedBound` whose false-admit bound is
         :func:`union_bound` (Boole) over the per-step bounds, scoped to the
         intersection of step live_outs.

    Returns an :class:`Evidence`; never raises for a well-formed list.
    """
    steps = list(step_evidences)

    # 1. empty chain.
    if not steps:
        return Unknown(reason="composition of an empty step chain")

    # 2. refutation dominates.
    for s in steps:
        if s.is_refutation:
            return s

    # 3. unknown poisons.
    for s in steps:
        if s.kind == "unknown":
            return Unknown(reason="composition includes an Unknown step")

    # 4. scope precondition.
    if live_in_of_later_steps is not None:
        if len(live_in_of_later_steps) != len(steps):
            return Unknown(
                reason=(
                    "composition scope precondition unverified: "
                    f"live_in list length {len(live_in_of_later_steps)} != "
                    f"step count {len(steps)}"
                )
            )
        n = len(steps)
        for i in range(n):
            sc = steps[i].scope
            covered = sc.live_out if sc is not None else frozenset()
            # union of live-ins of all LATER steps.
            later_needs: frozenset = frozenset()
            for j in range(i + 1, n):
                later_needs = later_needs | live_in_of_later_steps[j]
            missing = later_needs - covered
            if missing:
                return Unknown(
                    reason=(
                        "steps interact through uncompared state: "
                        f"step {i} compared {sorted(covered)} but later steps "
                        f"read {sorted(missing)} which it did not compare"
                    )
                )
    else:
        # Precondition unverified unless all steps are identical-scope proofs.
        if not _all_proofs_identical_full_scope(steps):
            return Unknown(reason="composition scope precondition unverified")

    # 5. combine the surviving confirming evidence.
    if all(isinstance(s, Proof) for s in steps):
        # Composed proof.  recheckable only if EVERY input cert is recheckable.
        recheckable = all(s.cert.recheckable for s in steps)  # type: ignore[attr-defined]
        # The composed argument is a derived (not directly machine-checked)
        # chaining of the inputs -> SDM_ARGUMENT cert kind, carrying the input
        # kinds for audit.  Bound is 0.0 within the (intersected) scope.
        from .evidence import Cert  # local import to avoid cycle at module load

        input_kinds = ",".join(s.cert.cert_kind for s in steps)  # type: ignore[attr-defined]
        composed_cert = Cert(
            cert_kind="SDM_ARGUMENT",
            payload=f"composition-of[{input_kinds}]",
            recheckable=recheckable and False,  # a *derived* chain is not itself machine-checked
        )
        composed_scope = Scope(
            live_out=_intersect_live_outs(steps),
            input_dist=None,
            notes="composed proof over intersection of step scopes",
        )
        return Proof(cert=composed_cert, scope=composed_scope)

    # Mixed / sampled chain -> Boole union bound.
    per_step = [s.false_admit_bound() for s in steps]
    # All bounds are non-None here: Refuted/Unknown were filtered above, and a
    # Behavioral with no calibration would have returned None.  Guard anyway.
    if any(b is None for b in per_step):
        return Unknown(
            reason="composition includes a step with no comparable false-admit bound"
        )
    combined = union_bound([b for b in per_step if b is not None])
    intersected = _intersect_live_outs(steps)
    if not intersected:
        # The steps share NO compared location, so the composite would guarantee
        # nothing — refuse to overclaim a bound over an empty scope.
        return Unknown(
            reason=(
                "composition steps share no compared state (intersection of "
                "step live_outs is empty); no honest composite scope"
            )
        )
    # The union bound holds only at confidence ~Pi(1 - delta_i); carry the Boole
    # residual sum(delta_i) (capped at 1) so the composite is never reported as
    # exact.  Steps with no per-step delta (a ComposedBound built directly, or a
    # calibrated Behavioral) contribute their own ``delta`` if present, else 0.
    composed_delta = union_bound(
        [float(getattr(s, "delta", 0.0) or 0.0) for s in steps]
    )
    composed_scope = Scope(
        live_out=intersected,
        input_dist=None,
        notes="composed bound (Boole union) over intersection of step scopes",
    )
    return ComposedBound(
        false_admit=combined,
        scope=composed_scope,
        parts=tuple(steps),
        delta=composed_delta,
    )


def admit(
    evidence: Evidence,
    alpha: float,
    *,
    require_recheckable: bool = True,
) -> bool:
    """THE single admissibility gate.

    Returns ``True`` iff the evidence is admissible at risk budget ``alpha``:

    * a :class:`Proof` (bound ``0.0`` <= any non-negative ``alpha``) WHOSE cert is
      re-checkable (see ``require_recheckable`` below), OR
    * any evidence whose ``false_admit_bound()`` is not ``None`` AND ``<= alpha``.

    :class:`Refuted` and :class:`Unknown` (and an uncalibrated
    :class:`Behavioral`) carry no comparable number and ALWAYS return ``False``.

    Proof + ``require_recheckable`` (finding 4).  A :class:`Proof` carries a
    :class:`Cert`, and an ``SDM_ARGUMENT`` cert is a human argument that was never
    machine-checked.  By DEFAULT (``require_recheckable=True``) the gate now
    admits a Proof only when ``cert.recheckable`` is True, so a
    non-recheckable/SDM proof does NOT clear the gate by accident.  A caller that
    knowingly trusts SDM arguments can pass ``require_recheckable=False`` to
    recover the old behavior.  (The gate trusts the producing oracle's
    ``recheckable`` flag rather than re-executing the verifier here — that keeps
    the gate free of a hard z3/capstone dependency and of payload-validity
    coupling; a caller that wants a fresh re-check should call
    :func:`funcval.oracles.proven.recheck_cert` explicitly before admitting.)

    This is the ONLY place a number is compared, and every number compared is
    the SAME quantity: an upper bound on the false-admit probability.  ``alpha``
    is the risk budget — callers should use a SMALLER ``alpha`` offline (when
    admitting a mutation into a trusted corpus) than online (a transient
    decision), because offline mistakes compound.
    """
    if evidence.kind == "proof":
        if alpha < 0.0:
            return False
        if not require_recheckable:
            # Caller knowingly trusts non-recheckable (e.g. SDM) proofs.
            return True
        cert = getattr(evidence, "cert", None)
        return cert is not None and bool(getattr(cert, "recheckable", False))
    if evidence.is_refutation:
        return False
    bound = evidence.false_admit_bound()
    if bound is None:
        return False
    return bound <= alpha
