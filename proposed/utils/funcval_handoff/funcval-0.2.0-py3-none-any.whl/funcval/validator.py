"""FunctionValidator — the public facade over the funcval evidence ledger.

What this is (and what it deliberately is NOT)
==============================================
``FunctionValidator`` is a thin orchestration layer.  It does not invent any
new notion of "equivalence" or any new number; every verdict it returns is one
of the typed :class:`funcval.Evidence` objects produced by the underlying
oracles, combined only through :func:`funcval.ledger.compose`, and judged only
through the single gate :func:`funcval.ledger.admit`.  The facade's whole value
is *sequencing* those pieces correctly and cheaply for two distinct consumers:
a synchronous gate and an asynchronous progress-reward stream.

The evidence-ledger model (why a single number)
-----------------------------------------------
A functionality verdict is EVIDENCE about the proposition ``mutated ==
original`` (observationally equivalent over a stated architectural scope).  The
package's founding decision is to refuse one overloaded ``confidence: float``
that silently conflates three epistemically different things — a machine-checked
proof, a statistical sample, and a noisy behavioral observation.  Instead each
kind is its own type, and they share exactly ONE comparable quantity:

    Evidence.false_admit_bound() -> Optional[float]

an UPPER BOUND on the probability that admitting this evidence as "equivalent"
is a mistake, paired inseparably with the :class:`funcval.Scope` it was measured
over.  ``None`` means "this kind carries no comparable number" and is NEVER
coerced to ``0.5`` or any other stand-in.  Because every verdict is reduced to
this one bound-plus-scope, the admission gate (:func:`funcval.admit`) is the
only place a number is ever compared, and the number compared is always the same
quantity against a risk budget ``alpha``.  This is what makes a proof, a sample,
and a composed chain directly comparable without overclaiming: they are forced
through one honest measurement.

The sync gate: ProvenOracle -> LocalEquivOracle
-----------------------------------------------
:meth:`verify_sync` is the CHEAP online path used by the RL action gate.  For
each mutation step it tries the oracles cheapest-first:

  1. :class:`ProvenOracle` (O(1) library lookup + a re-checkable cert).  If the
     pair is a known proven rewrite it returns a :class:`funcval.Proof`
     (false-admit bound ``0.0``) and we are done for that step.
  2. Only when the proven oracle returns :class:`funcval.Unknown` (pair not in
     the library, or no re-checkable cert) do we ESCALATE to
     :class:`LocalEquivOracle`, the full-architectural-state Unicorn
     differential oracle.  It returns either a :class:`funcval.Refuted`
     (a witnessed counterexample — sound NO) or a :class:`funcval.Sampled`
     ``k=0`` Clopper-Pearson bound.

A :class:`funcval.Refuted` at ANY step short-circuits the chain immediately (a
sound NO dominates everything).  Multi-step chains are combined with
:func:`funcval.compose`, which refuses to overclaim: an :class:`funcval.Unknown`
step poisons the chain, and a chain whose steps interact through state no step
actually compared (the "R8-clobber" hole) composes to :class:`funcval.Unknown`
unless the caller supplies the later steps' live-in sets to prove the scope
precondition.  ``verify_sync`` NEVER runs the behavioral oracle — a CAPE
detonation is far too slow for a per-action online gate.

LIMIT OF CLAIM — per-instruction equivalence is NOT whole-binary preservation
-----------------------------------------------------------------------------
The sync gate establishes PER-INSTRUCTION / LOCAL ARCHITECTURAL equivalence
(``Proof`` from ProvenOracle, ``Sampled`` from LocalEquivOracle).  That does NOT
imply WHOLE-BINARY behavioral preservation for self-modifying, self-checking,
packed, or relocation-sensitive code, and the local oracle compares
registers+flags+XMM but NOT memory writes (a rewrite diverging only on a stored
value samples k=0 and admits).  Only the behavioral oracle speaks to whole-binary
behavior, and while it is uncalibrated (no labelled known-different pairs yet) it
can neither admit nor deny.  Empirical evidence this gap is real: sample
``01ee8378…`` in ``artifacts/validator/ground_truth_behavioral.jsonl`` broke
(11706 -> 199 API calls) from a SINGLE per-instruction-equivalent rewrite.  So a
PASS from ``verify_sync`` means "locally architecturally equivalent over the
compared register/flag/XMM scope", NOT "the binary still does the same thing".

The async path: BehavioralOracle as a progress-reward stream
------------------------------------------------------------
Behavioral (CAPE detonation) evidence is NOISY, slow, and — in this project's
current state — UNCALIBRATED (there are no labelled known-different pairs yet),
so its honest ``false_admit`` is ``None`` and it never clears the gate on its
own.  It is therefore an OPTIONAL oracle (``None`` by default; the facade is
fully usable without a live box) and lives entirely on the asynchronous path:
:meth:`verify_async` submits a detonation and returns a handle without blocking,
and :meth:`collect_async` resolves it later.  :class:`funcval.async_runner.ProgressRewardRunner`
wraps this into an event stream so a slow detonation never blocks an RL step.

The RL trainer wiring is intentionally external
-----------------------------------------------
This facade produces Evidence; it does NOT decide a reward or touch any training
environment.  Mapping an Evidence object to a shaped reward (e.g. a large
penalty on :class:`funcval.Refuted`, a bonus scaled by admit-status or behavioral
similarity, zero on :class:`funcval.Unknown`) is a policy choice that belongs to
the consumer, so it is kept out of this module on purpose.  Keeping the facade
free of trainer coupling is what lets the same validator serve the online gate,
the offline corpus-admission gate, and the progress-reward stream without any of
them leaking assumptions into the others.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .evidence import Evidence, Scope, Unknown
from .ledger import admit as _admit
from .ledger import compose as _compose


class FunctionValidator:
    """Public facade: cheap sync gate (proven -> local_equiv -> compose) plus an
    optional async behavioral progress-reward path.

    Construction is lazy: the proven and local_equiv oracles are built on first
    use so simply constructing a ``FunctionValidator`` is free and import-safe.
    The behavioral oracle is OPTIONAL (``None`` by default) because it needs a
    live CAPE box; the synchronous gate works fully without it.
    """

    def __init__(
        self,
        *,
        proven=None,
        local_equiv=None,
        behavioral=None,
        alpha_online: float = 0.05,
        alpha_offline: float = 0.01,
    ) -> None:
        """
        Args:
            proven: a :class:`ProvenOracle`-shaped object, or ``None`` to build a
                default lazily on first :meth:`verify_sync`.
            local_equiv: a :class:`LocalEquivOracle`-shaped object, or ``None``
                to build a default lazily on first escalation.
            behavioral: a :class:`BehavioralOracle`-shaped object, or ``None``.
                The behavioral oracle is the slow/offline progress-reward oracle
                and is OPTIONAL — the sync gate never uses it.  ``verify_async``
                raises a clear error if it is needed but absent.
            alpha_online: default risk budget for the online sync gate.  This is
                a transient per-action decision, so a looser budget is
                appropriate.
            alpha_offline: a TIGHTER budget intended for offline admission into a
                trusted corpus (offline mistakes compound).  Exposed for callers
                that admit at the stricter level; not used implicitly by
                ``verify_sync``.
        """
        # Explicit overrides (a caller-supplied oracle is used for EVERY width;
        # the caller takes ownership of its width).  When None, the facade builds
        # and caches a per-width default oracle lazily (a 32-bit and a 64-bit
        # oracle are distinct objects backed by distinct libraries / Unicorn
        # modes, so they cannot be shared).
        self._proven_override = proven
        self._local_equiv_override = local_equiv
        self._proven_by_bits: Dict[int, Any] = {}
        self._local_equiv_by_bits: Dict[int, Any] = {}
        self._behavioral = behavioral
        self.alpha_online = float(alpha_online)
        self.alpha_offline = float(alpha_offline)

    # ------------------------------------------------------------------
    # Lazy, width-aware oracle construction
    # ------------------------------------------------------------------

    def _proven_for(self, bits: int):
        """The :class:`ProvenOracle` for ``bits``, built+cached lazily.

        A caller-supplied ``proven`` override is returned for any width (the
        caller owns its configuration).
        """
        if self._proven_override is not None:
            return self._proven_override
        if bits not in self._proven_by_bits:
            from .oracles.proven import ProvenOracle

            self._proven_by_bits[bits] = ProvenOracle(bits=bits)
        return self._proven_by_bits[bits]

    def _local_equiv_for(self, bits: int):
        """The :class:`LocalEquivOracle` for ``bits``, built+cached lazily."""
        if self._local_equiv_override is not None:
            return self._local_equiv_override
        if bits not in self._local_equiv_by_bits:
            from .oracles.local_equiv import LocalEquivOracle

            self._local_equiv_by_bits[bits] = LocalEquivOracle(bits=bits)
        return self._local_equiv_by_bits[bits]

    @property
    def proven(self):
        """The default 64-bit :class:`ProvenOracle` (back-compat accessor).

        Tests and callers that reach for ``v.proven`` get the 64-bit oracle; the
        width-aware path (:meth:`verify_sync` with ``bits=``) uses
        :meth:`_proven_for`.  An explicit override, if given, wins.
        """
        return self._proven_for(64)

    @property
    def local_equiv(self):
        """The default 64-bit :class:`LocalEquivOracle` (back-compat accessor)."""
        return self._local_equiv_for(64)

    @property
    def behavioral(self):
        """The :class:`BehavioralOracle`, or ``None`` if not configured.

        Unlike the other two this is NOT auto-constructed — the behavioral
        oracle needs a live box, so the facade is honest about its absence
        rather than silently building one.
        """
        return self._behavioral

    # ------------------------------------------------------------------
    # Step derivation
    # ------------------------------------------------------------------

    @staticmethod
    def _steps_from_diff(orig_bytes: bytes, mut_bytes: bytes) -> List[Dict[str, Any]]:
        """Derive mutation steps from (orig_bytes, mut_bytes) by diffing.

        Produces the same chunk-diff shape the rest of the repo uses (see
        ``lib/pe_shim/functionality_integrity/``):
        ``{chunk_offset, chunk_a_bytes_hex, chunk_b_bytes_hex}``.

        IMPORTANT — instruction-alignment caveat: the proven library is keyed on
        WHOLE-INSTRUCTION encodings, and the local_equiv oracle decodes the chunk
        bytes as x86; both are unsound on a sub-instruction byte slice (e.g.
        trimming a shared ``48`` REX prefix off ``4889ec`` / ``488be5`` leaves
        ``89ec`` / ``8be5``, which decode to a DIFFERENT, narrower instruction).
        So when the two equal-length buffers differ in a SINGLE contiguous run we
        emit ONE whole-buffer step — the buffer is the instruction unit the
        oracles can soundly reason about — rather than the trimmed sub-span.

        Multiple disjoint differing runs (a genuine multi-instruction chain)
        CANNOT be recovered by byte-diffing: the per-run boundaries fall on
        whatever bytes happen to differ, NOT on instruction boundaries, so a
        per-run split drops shared prefix/suffix bytes (e.g. the shared ``48`` REX
        of ``4831c0`` / ``4829c0``) and feeds malformed sub-instructions like
        ``31`` / ``29`` to the oracles — which then emulate raw bytes and return a
        spuriously-admissible Sampled(k=0) from garbage (finding 3).  So a
        multi-run diff with NO caller-supplied instruction-aligned ``steps=``
        emits a SINGLE whole-buffer step (the only span the decode-based oracles
        can soundly reason about); the caller SHOULD pass explicit
        instruction-aligned ``steps=`` to get a real multi-step chain.  A length
        change likewise yields a single whole-buffer step.
        """
        a = bytes(orig_bytes)
        b = bytes(mut_bytes)

        def _whole() -> List[Dict[str, Any]]:
            return [
                {
                    "chunk_offset": 0,
                    "chunk_a_bytes_hex": a.hex(),
                    "chunk_b_bytes_hex": b.hex(),
                }
            ]

        if len(a) != len(b):
            return _whole()

        # Find the maximal differing runs.
        runs: List["tuple[int, int]"] = []
        i = 0
        n = len(a)
        while i < n:
            if a[i] == b[i]:
                i += 1
                continue
            start = i
            while i < n and a[i] != b[i]:
                i += 1
            runs.append((start, i))

        if not runs:
            return []  # identity / no-op
        # One OR MORE diff runs without caller-supplied instruction boundaries ->
        # a single whole-buffer step.  A per-run split on >1 run drops shared
        # prefix/suffix bytes (e.g. a REX 48) and yields malformed sub-instruction
        # spans that the oracles wrongly admit; the whole buffer is the only span
        # they can decode soundly.  The caller passes explicit ``steps=`` for a
        # genuine instruction-aligned multi-step chain.
        return _whole()

    @staticmethod
    def _step_hex(step: Dict[str, Any]) -> "tuple[str, str]":
        """Extract ``(orig_hex, var_hex)`` from a chunk-diff step."""
        return (
            str(step["chunk_a_bytes_hex"]).strip().lower(),
            str(step["chunk_b_bytes_hex"]).strip().lower(),
        )

    # ------------------------------------------------------------------
    # Sync gate: proven -> local_equiv -> compose
    # ------------------------------------------------------------------

    def verify_sync(
        self,
        orig_bytes: bytes,
        mut_bytes: bytes,
        *,
        bits: int = 64,
        steps: Optional[List[Dict[str, Any]]] = None,
        alpha: Optional[float] = None,
    ) -> Evidence:
        """The CHEAP online gate.  Returns the composed :class:`Evidence`.

        For each mutation step (single or chain):
          1. run :meth:`ProvenOracle.produce` FIRST (O(1) library lookup); a
             :class:`funcval.Proof` is used directly;
          2. on :class:`funcval.Unknown` (not in the proven library / no
             re-checkable cert) escalate to :meth:`LocalEquivOracle.produce`,
             yielding :class:`funcval.Sampled`, :class:`funcval.Refuted`, or
             :class:`funcval.Unknown` (the input-validity guard).

        A :class:`funcval.Refuted` at ANY step short-circuits the whole chain
        (it is returned immediately).  The behavioral oracle is NEVER invoked
        here — too slow for the sync path.

        WIDTH (the footgun, and how it is closed).  ``bits`` selects the target
        architecture (32 = i386 / UC_MODE_32 / CS_MODE_32 / 32-bit library;
        64 = x86-64).  The DEFAULT is 64 so the existing 64-bit quickstart is
        unchanged.  A 32-bit caller who forgets ``bits=32`` does NOT silently get
        an unsound 64-bit verdict: the LocalEquivOracle runs the input-validity
        guard FIRST, decoding the bytes in 64-bit mode, and 32-bit-only encodings
        (e.g. ``40`` = ``inc eax``, which is a bare REX prefix in 64-bit) fail to
        decode cleanly and return :class:`funcval.Unknown` rather than a spurious
        admissible k=0.  Genuinely-32-bit-equivalent pairs (``and eax,eax`` vs
        ``test eax,eax``) only ADMIT when the caller passes ``bits=32`` — at the
        default 64-bit width they are correctly Refuted (the upper-32 hazard).

        Multi-step results are combined with :func:`funcval.compose`.  When
        ``steps`` carry per-step ``live_in`` sets we pass them through as
        ``live_in_of_later_steps`` so compose can verify the scope precondition;
        otherwise compose applies its conservative Unknown behavior.

        Args:
            orig_bytes: the original ``.text`` bytes.
            mut_bytes: the mutated ``.text`` bytes.
            bits: target architecture width, ``32`` or ``64`` (default ``64``).
                Threaded into BOTH oracles (library selection, capstone/Unicorn
                mode, Z3 bit width, compared register set).
            steps: an explicit list of chunk-diff steps
                (``{chunk_offset, chunk_a_bytes_hex, chunk_b_bytes_hex,
                [live_in]}``).  If ``None``, steps are derived by diffing
                ``(orig_bytes, mut_bytes)``.
            alpha: RESERVED and unused for the verdict itself.  ``verify_sync``
                returns typed Evidence; turning that into an admit/deny decision
                is a SEPARATE call (:meth:`admissible` / :func:`funcval.admit`)
                that takes its own budget.  The parameter is kept in the
                signature only so a caller can pass the budget it intends to
                judge at alongside the verdict request; it does NOT change the
                Evidence produced, so it is deliberately not consumed here.

        Returns:
            The single composed :class:`Evidence` for the whole mutation.
        """
        # NB: ``alpha`` is intentionally NOT used — the verdict is budget-free
        # (admission is the separate :meth:`admissible` call).  No dead local
        # binding (it previously shadowed the param to no effect).
        if bits not in (32, 64):
            raise ValueError(f"bits must be 32 or 64, got {bits!r}")

        proven = self._proven_for(bits)
        local_equiv = self._local_equiv_for(bits)

        if steps is None:
            steps = self._steps_from_diff(orig_bytes, mut_bytes)

        if not steps:
            # No differing bytes at all: the mutation is the identity.  Compose
            # of an empty chain is Unknown by design, so report that honestly.
            return Unknown("verify_sync: mutation is a no-op (no differing bytes)")

        step_evidences: List[Evidence] = []
        live_ins: List[frozenset] = []
        have_live_in = True

        for step in steps:
            orig_hex, var_hex = self._step_hex(step)

            # 1. proven first (O(1)).
            ev = proven.produce(orig_hex, var_hex)

            # 2. escalate only on Unknown.
            if ev.kind == "unknown":
                ev = local_equiv.produce(orig_hex, var_hex)

            # short-circuit on a sound refutation.
            if ev.is_refutation:
                return ev

            step_evidences.append(ev)

            li = step.get("live_in")
            if li is None:
                have_live_in = False
            else:
                live_ins.append(frozenset(li))

        # Single step: nothing to compose, return it directly.
        if len(step_evidences) == 1:
            return step_evidences[0]

        if have_live_in and len(live_ins) == len(step_evidences):
            return _compose(step_evidences, live_in_of_later_steps=live_ins)
        return _compose(step_evidences)

    def admissible(self, evidence: Evidence, *, alpha: Optional[float] = None) -> bool:
        """Thin wrapper over :func:`funcval.admit` (default :attr:`alpha_online`)."""
        if alpha is None:
            alpha = self.alpha_online
        return _admit(evidence, alpha)

    # ------------------------------------------------------------------
    # Async / progress-reward path (behavioral)
    # ------------------------------------------------------------------

    def verify_async(self, orig_bytes: bytes, mut_bytes: bytes) -> Dict[str, Any]:
        """Submit a behavioral detonation WITHOUT blocking; return its handle.

        Requires a configured behavioral oracle (raises ``RuntimeError`` if
        ``behavioral`` is ``None``).  The returned handle is later resolved with
        :meth:`collect_async`.  This is the split the progress-reward runner uses
        so a slow CAPE detonation never blocks an RL step.
        """
        if self._behavioral is None:
            raise RuntimeError(
                "verify_async requires a behavioral oracle; FunctionValidator was "
                "constructed without one (behavioral=None). The async/behavioral "
                "path needs a live CAPE box — pass behavioral=BehavioralOracle(...)."
            )
        return self._behavioral.submit(orig_bytes, mut_bytes)

    def collect_async(self, handle: Dict[str, Any]) -> Evidence:
        """Resolve a handle from :meth:`verify_async` into :class:`Evidence`."""
        if self._behavioral is None:
            raise RuntimeError(
                "collect_async requires a behavioral oracle (behavioral=None)."
            )
        return self._behavioral.collect(handle)


__all__ = ["FunctionValidator"]
