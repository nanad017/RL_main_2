"""Typed evidence model for the functionality-equivalence validator.

A functionality verdict is EVIDENCE about the proposition ``mutated == original``
(``==`` meaning "observationally equivalent over the stated architectural
state").  Evidence comes in epistemically distinct kinds, and the central
design decision of this package is to refuse a single overloaded
``confidence: float`` that conflates a machine-checked proof, a statistical
sample, and a noisy behavioral observation.

Instead each evidence kind is its own frozen dataclass, and they share ONE
comparable quantity:

    Evidence.false_admit_bound() -> Optional[float]

an UPPER BOUND on the probability that admitting this evidence as "equivalent"
is a mistake (a false admit).  ``None`` means "this kind carries no comparable
number" — it must never be coerced to ``0.5`` or any other stand-in.  Every
bound-bearing kind also carries a mandatory :class:`Scope`: a bound without the
scope it was measured over is meaningless, so the two are inseparable.

Epistemic ordering the validator relies on:

    Refuted   (sound NO; dominates everything; no comparable number)
    Proof     (zero error WITHIN scope, modulo cert trust)
    Sampled / Behavioral / ComposedBound  (a numeric false-admit bound)
    Unknown   (absence of evidence; no number)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Tuple

from .bounds import clopper_pearson_upper

# --- Named constants -------------------------------------------------------

#: Allowed kind tags.  Exposed so callers can switch on a closed set.
KIND_REFUTED = "refuted"
KIND_PROOF = "proof"
KIND_SAMPLED = "sampled"
KIND_BEHAVIORAL = "behavioral"
KIND_UNKNOWN = "unknown"

#: Allowed certificate kinds for a Proof.  Z3_UNSAT, ALIVE2, DECODE_IDENTICAL,
#: and ISA_BITWISE_ALIAS are machine-re-checkable (``recheckable=True`` is
#: meaningful for them).  DECODE_IDENTICAL is a re-checkable STRUCTURAL proof: two
#: byte encodings that disassemble to the identical instruction (e.g. an
#: alternate ModRM d-bit encoding) — re-checked by re-disassembling and comparing
#: the normalized instruction text.
#: ISA_BITWISE_ALIAS is a re-checkable STRUCTURAL proof for the SIMD bitwise
#: aliases (e.g. pxor/xorpd, pand/andpd, por/orpd, pandn/andnpd): both encodings
#: decode to a whitelisted aliased-mnemonic pair operating on the SAME two
#: operands.  The equivalence rests on the ISA DEFINING both mnemonics as the
#: identical 128-bit bitwise operation — a structural/definitional fact, NOT a
#: number Z3 can derive non-circularly — re-checked by re-decoding and re-running
#: the whitelist + operand-identity check.
#: SDM_ARGUMENT is a human Intel-SDM argument and is NOT machine-checked — it is
#: included because ~90% of this project's "proven" library rests on exactly one
#: such argument, and pretending it is the same as a Z3 proof is the overclaim
#: this whole package exists to prevent.
_CERT_KINDS = frozenset(
    {"Z3_UNSAT", "ALIVE2", "DECODE_IDENTICAL", "SDM_ARGUMENT", "ISA_BITWISE_ALIAS"}
)

#: Largest residual error probability accepted on a :class:`Sampled` bound.  A
#: larger delta produces a tighter (lower-confidence) Clopper-Pearson bound that
#: admits more easily, so we cap it at 0.5 (the bound must hold at >= 50%
#: confidence to be a sound basis for admission).
_MAX_SAMPLED_DELTA: float = 0.5


def _check_unit_interval(name: str, value: float) -> None:
    """Raise ValueError unless ``value`` is a real number in [0.0, 1.0]."""
    if not (0.0 <= value <= 1.0):
        raise ValueError(f"{name} must be in [0.0, 1.0], got {value!r}")


def _check_nonempty_scope(name: str, scope: "Scope") -> None:
    """Raise ValueError if a bound-bearing evidence carries an EMPTY scope.

    A false-admit bound is only meaningful relative to the architectural state it
    was measured over (the :class:`Scope` ``live_out``).  An empty ``live_out``
    means "nothing was compared", so a numeric bound attached to it is vacuous —
    it would claim a measured failure rate over the empty set of locations and
    then admit.  Reject it at construction rather than letting it clear the gate.
    """
    if scope is None or not scope.live_out:
        raise ValueError(
            f"{name}: a bound-bearing evidence requires a non-empty scope.live_out "
            f"(an empty scope compares nothing, so its bound is meaningless)"
        )


@dataclass(frozen=True)
class Scope:
    """The architectural state a verdict is actually ABOUT.

    A false-admit bound is only meaningful relative to what was compared.  A
    proof/sample that checks only ``rax`` says NOTHING about ``rbx`` or memory;
    silently treating such a verdict as full-state equivalence is unsound.  So
    every bound-bearing evidence must carry a Scope.

    Attributes:
        live_out: the set of architectural locations whose final values were
            compared, e.g. ``{"rax", "rbx", "eflags", "xmm0", "mem:[rbp-8]"}``.
            Naming is by convention a string per location; the validator only
            relies on set containment, never on parsing the strings.
        input_dist: id of the sampling distribution the evidence was gathered
            under, for SAMPLED evidence.  ``None`` for proofs (a proof quantifies
            over all inputs in scope, not a sampled distribution).
        notes: free-form provenance.
    """

    live_out: frozenset
    input_dist: Optional[str] = None
    notes: str = ""


@dataclass(frozen=True)
class Cert:
    """A small certificate backing a :class:`Proof`.

    Attributes:
        cert_kind: one of ``{"Z3_UNSAT", "ALIVE2", "DECODE_IDENTICAL",
            "ISA_BITWISE_ALIAS", "SDM_ARGUMENT"}``.
        payload: the certificate text/handle (e.g. the SMT-LIB script, the
            Alive2 transform, the decoded-instruction JSON, the alias
            whitelist/operand JSON, or a citation to the SDM argument).
        recheckable: True iff the cert can be re-verified mechanically
            (Z3_UNSAT / ALIVE2 / DECODE_IDENTICAL / ISA_BITWISE_ALIAS).  An
            ``SDM_ARGUMENT`` MUST set this False; the consumer decides whether to
            trust a non-recheckable proof.
    """

    cert_kind: str
    payload: str
    recheckable: bool

    def __post_init__(self) -> None:
        if self.cert_kind not in _CERT_KINDS:
            raise ValueError(
                f"cert_kind must be one of {sorted(_CERT_KINDS)}, got {self.cert_kind!r}"
            )


@dataclass(frozen=True)
class Evidence:
    """Common base for all evidence kinds.

    Subclasses are frozen dataclasses.  The base defines the comparable API but
    is not meant to be instantiated directly.
    """

    @property
    def kind(self) -> str:
        raise NotImplementedError

    def false_admit_bound(self) -> Optional[float]:
        """The single comparable quantity: an upper bound on the false-admit
        probability, or ``None`` if this kind carries no comparable number."""
        raise NotImplementedError

    @property
    def is_refutation(self) -> bool:
        """True only for a sound refutation (a real counterexample)."""
        return False

    @property
    def scope(self) -> Optional[Scope]:
        raise NotImplementedError


@dataclass(frozen=True)
class Refuted(Evidence):
    """A SOUND "no": a concrete counterexample was found.

    Refutation is the trustworthy direction — a single witnessed disagreement on
    in-scope state proves the mutation is NOT equivalent.  It DOMINATES every
    confirming evidence in composition (see :func:`funcval.ledger.compose`).

    It carries no comparable number: ``false_admit_bound()`` is ``None`` because
    a refutation is not a candidate for admission at all (admitting it would be
    admitting a known-bad mutation).

    Attributes:
        counterexample: the witnessing input and the diverging output(s).
        scope: the state that was compared when divergence was observed.
        oracle: which oracle produced the counterexample (e.g. "z3", "unicorn").
    """

    counterexample: dict
    _scope: Scope = field()
    oracle: str = ""

    def __init__(self, counterexample: dict, scope: Scope, oracle: str) -> None:
        # Custom __init__ so the public arg name is ``scope`` while the stored
        # field is ``_scope`` (we expose ``scope`` as a property on the base).
        # A refutation MUST name the state the divergence was observed over: a
        # counterexample with no scope cannot be audited or composed.
        if scope is None:
            raise ValueError("Refuted requires a non-None scope (the state the "
                             "divergence was observed over)")
        object.__setattr__(self, "counterexample", counterexample)
        object.__setattr__(self, "_scope", scope)
        object.__setattr__(self, "oracle", oracle)

    @property
    def kind(self) -> str:
        return KIND_REFUTED

    def false_admit_bound(self) -> Optional[float]:
        return None

    @property
    def is_refutation(self) -> bool:
        return True

    @property
    def scope(self) -> Optional[Scope]:
        return self._scope


@dataclass(frozen=True)
class Proof(Evidence):
    """A proof of equivalence WITHIN the stated scope.

    ``false_admit_bound()`` returns ``0.0`` — zero error, but ONLY within
    ``scope`` and ONLY as sound as the certificate.  Two caveats the consumer
    must respect:

      1. The scope bounds the claim: a proof over ``{rax}`` says nothing about
         ``rbx``.  This is why composition checks scope coverage rather than
         trusting the ``0.0`` blindly.
      2. ``cert.recheckable`` matters.  A ``Z3_UNSAT`` / ``ALIVE2`` cert can be
         re-verified mechanically.  An ``SDM_ARGUMENT`` cert is a human Intel-SDM
         argument; it is NOT machine-checked.  This package deliberately does not
         downgrade the bound for SDM_ARGUMENT (a valid SDM argument is a valid
         proof), but it surfaces ``recheckable=False`` so a caller can choose to
         require recheckable certs.  Silently equating SDM_ARGUMENT with Z3_UNSAT
         is exactly the overclaim this design exists to kill.

    Attributes:
        cert: the backing :class:`Cert`.
        scope: the architectural state the proof quantifies over.
    """

    cert: Cert
    _scope: Scope = field()

    def __init__(self, cert: Cert, scope: Scope) -> None:
        object.__setattr__(self, "cert", cert)
        object.__setattr__(self, "_scope", scope)

    @property
    def kind(self) -> str:
        return KIND_PROOF

    def false_admit_bound(self) -> Optional[float]:
        return 0.0

    @property
    def scope(self) -> Optional[Scope]:
        return self._scope


@dataclass(frozen=True)
class Sampled(Evidence):
    """Statistical evidence: ``k`` counterexamples in ``n`` i.i.d. draws.

    ``false_admit_bound()`` returns ``clopper_pearson_upper(k, n, delta)`` — the
    exact one-sided upper confidence bound on the failure probability at
    confidence ``1 - delta``.

    SCOPE OF THE CLAIM (read this): the bound is a statement about the failure
    probability UNDER THE DISTRIBUTION ``dist_id`` the draws came from.  It is
    NOT a statement about all inputs.  A mutation that is equivalent on
    benign-text-like inputs with bound ``0.01`` may still diverge on inputs the
    sampler never produced.  The validator records ``dist_id`` precisely so this
    is never forgotten.

    Attributes:
        n: number of i.i.d. draws (``n >= 0``).
        k: number of observed counterexamples (``0 <= k <= n``).
        dist_id: id of the input distribution.
        live_out: the :class:`Scope` compared on each draw (its ``input_dist``
            should equal ``dist_id``; not enforced here).
        delta: residual error probability of the confidence bound, ``(0, 1)``.
    """

    n: int
    k: int
    dist_id: str
    live_out: Scope
    delta: float

    def __post_init__(self) -> None:
        if self.n < 0:
            raise ValueError(f"n must be >= 0, got {self.n!r}")
        if not (0 <= self.k <= self.n):
            raise ValueError(f"need 0 <= k <= n, got k={self.k!r}, n={self.n!r}")
        if not (0.0 < self.delta < 1.0):
            raise ValueError(f"delta must be in (0, 1), got {self.delta!r}")
        # delta is the residual error probability of the confidence bound, and a
        # LARGER delta yields a TIGHTER (lower) Clopper-Pearson upper bound — i.e.
        # a less-confident interval that admits more easily.  A delta above 0.5
        # means the bound holds at under 50% confidence, which is never a sound
        # basis for admission; reject it so a falsely-tight bound can't slip in.
        if self.delta > _MAX_SAMPLED_DELTA:
            raise ValueError(
                f"delta must be <= {_MAX_SAMPLED_DELTA} (a larger delta gives a "
                f"falsely tight, low-confidence bound), got {self.delta!r}"
            )
        # A bound over an empty scope compares nothing and is meaningless.
        _check_nonempty_scope("Sampled.live_out", self.live_out)
        # Eagerly validate the bound is a legal probability.
        _check_unit_interval("clopper_pearson_upper", self.false_admit_bound())

    @property
    def kind(self) -> str:
        return KIND_SAMPLED

    def false_admit_bound(self) -> Optional[float]:
        return clopper_pearson_upper(self.k, self.n, self.delta)

    @property
    def scope(self) -> Optional[Scope]:
        return self.live_out


@dataclass(frozen=True)
class Behavioral(Evidence):
    """A NOISY behavioral observation (e.g. CAPE detonation similarity).

    This is an OBSERVATION, never a proof.  A high composite-similarity score is
    consistent with equivalence but does not establish it; behavioral oracles
    have a noise floor and finite coverage.

    ``false_admit_bound()`` returns ``false_admit``, which the PRODUCING ORACLE
    must derive from a labelled calibration set (the rate at which a score this
    good corresponds to a genuinely non-equivalent pair).  If no calibration is
    available, ``false_admit`` MUST be ``None``: an honest "no calibration => no
    bound", and the admission gate then treats this evidence like Unknown
    (non-admissible).  We do NOT fabricate a number from the raw score.

    Attributes:
        composite: the composite similarity/behaviour score.  This is an
            ORACLE-DEFINED, UNCONSTRAINED diagnostic — it is deliberately NOT
            range-checked to [0,1] because different behavioral oracles scale it
            differently (e.g. a raw API-call-set Jaccard in [0,1] vs an unbounded
            log-ratio).  Nothing in the admission gate consumes ``composite``;
            only ``false_admit`` (below) is comparable, and that IS range-checked.
        noise_floor: the score level attributable to oracle noise.  Same status
            as ``composite``: an unconstrained diagnostic, not a comparable bound.
        threshold_basis: provenance of the decision threshold / calibration id.
        coverage: what the behavioral run covered (e.g. "detonation").
        false_admit: calibrated false-admit upper bound (range-checked to [0,1]
            and, when present, required to carry a non-empty scope), or ``None``.
        scope: behavioral state compared.
    """

    composite: float
    noise_floor: float
    threshold_basis: str
    coverage: str
    false_admit: Optional[float]
    _scope: Scope = field()

    def __init__(
        self,
        composite: float,
        noise_floor: float,
        threshold_basis: str,
        coverage: str,
        false_admit: Optional[float],
        scope: Scope,
    ) -> None:
        if false_admit is not None:
            _check_unit_interval("false_admit", false_admit)
            # A calibrated bound over an empty scope compares nothing -> reject.
            _check_nonempty_scope("Behavioral.scope", scope)
        object.__setattr__(self, "composite", composite)
        object.__setattr__(self, "noise_floor", noise_floor)
        object.__setattr__(self, "threshold_basis", threshold_basis)
        object.__setattr__(self, "coverage", coverage)
        object.__setattr__(self, "false_admit", false_admit)
        object.__setattr__(self, "_scope", scope)

    @property
    def kind(self) -> str:
        return KIND_BEHAVIORAL

    def false_admit_bound(self) -> Optional[float]:
        return self.false_admit

    @property
    def scope(self) -> Optional[Scope]:
        return self._scope


@dataclass(frozen=True)
class Unknown(Evidence):
    """Absence of evidence.

    ``false_admit_bound()`` returns ``None`` and ``scope`` is ``None``.  Critically,
    Unknown is NOT the number ``0.5`` or any other stand-in — it carries no
    number at all.  An Unknown step poisons composition (the whole chain becomes
    Unknown), and Unknown never admits.

    Attributes:
        reason: human-readable explanation (timeout, no oracle, etc.).
    """

    reason: str

    @property
    def kind(self) -> str:
        return KIND_UNKNOWN

    def false_admit_bound(self) -> Optional[float]:
        return None

    @property
    def scope(self) -> Optional[Scope]:
        return None


@dataclass(frozen=True)
class ComposedBound(Evidence):
    """A composite false-admit bound produced by chaining several steps.

    Unlike :class:`Sampled` this is NOT a single ``(n, k)`` draw — it is the
    Boole/union combination of several steps' per-step bounds (see
    :func:`funcval.ledger.compose`).  We give it its own type rather than
    forcing it into ``Sampled`` so the provenance (``parts``) is preserved and
    nobody mistakes it for a fresh sampling experiment.

    For ADMISSION purposes it behaves like a sampled bound, so ``kind`` reports
    ``"sampled"`` — the admission gate compares exactly one quantity (a
    false-admit upper bound) regardless of how it was produced.

    THE CONFIDENCE RESIDUAL (``delta``).  ``false_admit`` is a Boole/union sum of
    the per-step false-admit bounds, but each contributing :class:`Sampled` bound
    only holds at confidence ``1 - delta_i``.  The composed bound therefore holds
    at confidence ``>= Pi (1 - delta_i)``, and by Boole again the residual error
    is bounded by ``sum delta_i`` (capped at 1).  We carry that summed residual on
    ``delta`` so a consumer is never told the union bound is exact: the honest
    statement is "false-admit ``<= false_admit`` at confidence ``>= 1 - delta``".
    ``delta`` defaults to ``0.0`` (a directly-constructed ComposedBound with no
    declared per-step residual) so the public constructor signature is unchanged;
    :func:`funcval.ledger.compose` always populates it from the step deltas.

    Attributes:
        false_admit: the combined upper bound in ``[0, 1]``.
        scope: the intersection of the step scopes (state guaranteed compared
            by EVERY step).
        parts: the tuple of contributing evidence objects, for audit.
        delta: union (sum, capped at 1) of the per-step confidence residuals.
    """

    false_admit: float
    _scope: Scope = field()
    parts: Tuple = ()
    delta: float = 0.0

    def __init__(
        self,
        false_admit: float,
        scope: Scope,
        parts: Tuple = (),
        delta: float = 0.0,
    ) -> None:
        _check_unit_interval("false_admit", false_admit)
        _check_unit_interval("delta", delta)
        # A composite bound over an empty scope guarantees nothing was compared
        # by EVERY step -> the bound is meaningless.
        _check_nonempty_scope("ComposedBound.scope", scope)
        object.__setattr__(self, "false_admit", false_admit)
        object.__setattr__(self, "_scope", scope)
        object.__setattr__(self, "parts", tuple(parts))
        object.__setattr__(self, "delta", float(delta))

    @property
    def kind(self) -> str:
        # Behaves like a sampled numeric bound for the single admission gate.
        return KIND_SAMPLED

    def false_admit_bound(self) -> Optional[float]:
        return self.false_admit

    @property
    def scope(self) -> Optional[Scope]:
        return self._scope
