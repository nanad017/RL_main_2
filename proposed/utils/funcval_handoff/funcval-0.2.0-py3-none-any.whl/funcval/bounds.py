"""Pure-python confidence/error bounds for the functionality validator.

This module is the ONLY place numerical bounds are computed.  It has NO heavy
dependencies (no numpy / no scipy): everything is built on the standard
``math`` module so the bound math is auditable line-by-line by a hostile
reviewer.

The two public functions:

* :func:`clopper_pearson_upper` — the exact one-sided (upper) Clopper-Pearson
  confidence bound on a failure probability, given ``k`` observed failures in
  ``n`` i.i.d. trials at confidence level ``1 - delta``.
* :func:`union_bound` — Boole's inequality: a SOUND way to combine per-step
  false-admit bounds with NO independence assumption.

Why Clopper-Pearson (and the "rule of three") — read this before touching it
====================================================================================
For the common case ``k == 0`` (no counterexample seen in ``n`` draws) the
exact upper bound is

    cp(0, n, delta) = 1 - delta ** (1 / n)

i.e. the ``(1 - delta)`` quantile of the ``Beta(1, n)`` distribution.  At the
conventional ``delta = 0.05`` and large ``n`` this is numerically very close
to the textbook "rule of three", ``3 / n`` (e.g. ``cp(0, 256, 0.05) ~ 0.0116``
vs ``3/256 ~ 0.0117``).  The approximation ``~= 3/n`` holds ONLY at
``delta ~= 0.05`` for large ``n``; do not generalise it to other ``delta``.

HISTORICAL HAZARD — do not reintroduce ``2 ** -N``.  An earlier framing in this
project quoted the per-pair false-admit probability as ``2 ** -N`` (treating N
random-input agreements as N independent coin flips that the equivalence is
"proven").  That is WRONG by roughly 60 orders of magnitude at N=256: a
single sampling experiment with zero observed failures bounds the failure rate
at ``~1.2e-2`` (one part in ~85), NOT ``2 ** -256 ~ 8.6e-78``.  Random-input
agreement is statistical evidence, not a proof, and its honest error bar is
the Clopper-Pearson interval above.  Anyone tempted to write ``2 ** -N`` should
re-read this paragraph.
"""
from __future__ import annotations

import math
from typing import List

# --- Named constants (no magic numbers) ------------------------------------

#: Bisection tolerance on x (the failure-probability axis) when inverting the
#: regularized incomplete beta function.  1e-12 is far tighter than the 1e-3
#: tolerance the tests demand and than any downstream alpha we compare against,
#: while still converging in ~40 bisection steps (log2(1/1e-12) ~ 40).
_BISECTION_XTOL: float = 1e-12

#: Hard cap on bisection iterations.  log2((1-0)/1e-12) ~ 40, so 200 is an
#: order of magnitude of slack — a guard against a non-converging edge case,
#: never reached in normal operation.
_BISECTION_MAX_ITERS: int = 200

#: Convergence tolerance for the Lentz continued fraction evaluating I_x(a,b).
#: 1e-15 is near double-precision epsilon; the CF for the regularized
#: incomplete beta converges geometrically, so this is reached in well under
#: _CF_MAX_ITERS terms for all (a, b, x) we use.
_CF_EPS: float = 1e-15

#: Floor used by the Lentz algorithm to avoid division by exactly zero
#: (Numerical Recipes "tiny").  Any value far below _CF_EPS works.
_CF_TINY: float = 1e-300

#: Maximum continued-fraction terms before giving up.  The beta CF needs only
#: a few dozen terms for our (a, b) ranges; 1000 is a safety ceiling.
_CF_MAX_ITERS: int = 1000


def _betacf(a: float, b: float, x: float) -> float:
    """Continued fraction for the incomplete beta function (Lentz's method).

    Evaluates the continued fraction that appears in

        I_x(a, b) = prefactor(x, a, b) * betacf(a, b, x) / a

    via the modified Lentz algorithm (Numerical Recipes, ch. 6.4), which is
    numerically stable because it never forms the small partial numerators
    directly.  Valid for ``x < (a + 1) / (a + b + 2)``; the caller
    (:func:`_betai`) applies the symmetry reflection so this precondition
    always holds.
    """
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < _CF_TINY:
        d = _CF_TINY
    d = 1.0 / d
    h = d
    for m in range(1, _CF_MAX_ITERS + 1):
        m2 = 2 * m
        # even step
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < _CF_TINY:
            d = _CF_TINY
        c = 1.0 + aa / c
        if abs(c) < _CF_TINY:
            c = _CF_TINY
        d = 1.0 / d
        h *= d * c
        # odd step
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < _CF_TINY:
            d = _CF_TINY
        c = 1.0 + aa / c
        if abs(c) < _CF_TINY:
            c = _CF_TINY
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < _CF_EPS:
            return h
    # Did not converge within the safety ceiling; return best estimate.
    return h


def _betai(a: float, b: float, x: float) -> float:
    """Regularized incomplete beta function I_x(a, b), pure python.

    I_x(a, b) is the CDF of the Beta(a, b) distribution at x.  Implemented as

        prefactor = exp( lgamma(a+b) - lgamma(a) - lgamma(b)
                         + a*ln(x) + b*ln(1-x) )

    times the Lentz continued fraction, with the standard reflection
    I_x(a,b) = 1 - I_{1-x}(b,a) used so the continued fraction is always
    evaluated in its fast-converging region ``x < (a+1)/(a+b+2)``.
    """
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    # log of the beta prefactor; lgamma keeps this stable for large n.
    ln_pref = (
        math.lgamma(a + b)
        - math.lgamma(a)
        - math.lgamma(b)
        + a * math.log(x)
        + b * math.log(1.0 - x)
    )
    bt = math.exp(ln_pref)
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def clopper_pearson_upper(k: int, n: int, delta: float) -> float:
    """Exact one-sided (upper) Clopper-Pearson bound on the failure probability.

    Given ``k`` observed failures (counterexamples) in ``n`` i.i.d. trials, this
    returns the smallest ``p_hi`` such that, if the true failure probability
    were ``p_hi``, the chance of observing ``k`` or fewer failures would be
    exactly ``delta``.  Equivalently it is the ``(1 - delta)`` quantile of the
    ``Beta(k + 1, n - k)`` distribution:

        p_hi = inf { p : I_p(k + 1, n - k) <= 1 - delta }   (for 0 <= k < n)

    where ``I_p`` is the regularized incomplete beta function.  ``1 - delta`` is
    the confidence level; ``delta`` is the residual error probability that the
    TRUE failure rate exceeds ``p_hi``.

    Scope of the claim: this bounds the failure probability UNDER THE SAMPLING
    DISTRIBUTION the ``n`` draws came from.  It says nothing about inputs outside
    that distribution.  The caller (the Sampled evidence kind) must record which
    distribution, and the validator must never treat this as an all-inputs proof.

    Special cases:
      * ``k == n``  -> ``1.0`` (every trial failed; the upper bound on the
        failure probability is certainty).
      * ``k == 0``  -> closed form ``1 - delta ** (1 / n)`` (the
        ``(1 - delta)`` quantile of ``Beta(1, n)``).  Computed directly rather
        than via inversion for speed and exactness.

    Algorithm (general ``0 < k < n``): the equation
    ``I_x(k + 1, n - k) = 1 - delta`` is solved for ``x in [0, 1]`` by
    bisection.  ``I_x`` is strictly increasing in ``x`` on ``(0, 1)``, so
    bisection converges monotonically to the unique root.  ``I_x`` itself is
    evaluated by :func:`_betai` (Lentz continued fraction + lgamma prefactor) —
    no scipy.

    Args:
        k: number of observed failures, ``0 <= k <= n``.
        n: number of i.i.d. trials, ``n >= 0``.
        delta: residual error probability, ``0 < delta < 1`` (so the confidence
            level ``1 - delta`` is in ``(0, 1)``).

    Returns:
        Upper confidence bound in ``[0.0, 1.0]``.
    """
    if not (0 < delta < 1):
        raise ValueError(f"delta must be in (0, 1), got {delta!r}")
    if n < 0:
        raise ValueError(f"n must be >= 0, got {n!r}")
    if not (0 <= k <= n):
        raise ValueError(f"need 0 <= k <= n, got k={k!r}, n={n!r}")

    # n == 0: no trials, no information -> the failure probability could be
    # anything up to 1.0.  (k must be 0 here by the invariant above.)
    if n == 0:
        return 1.0
    if k == n:
        # Every trial failed; the one-sided upper bound is certainty.
        return 1.0
    if k == 0:
        # Closed form: (1 - delta) quantile of Beta(1, n) = 1 - delta**(1/n).
        return 1.0 - delta ** (1.0 / n)

    # General case: invert I_x(k+1, n-k) = 1 - delta by bisection on x.
    a = float(k + 1)
    b = float(n - k)
    target = 1.0 - delta
    lo, hi = 0.0, 1.0
    # I_x is increasing in x; the root lies in (0, 1).
    for _ in range(_BISECTION_MAX_ITERS):
        mid = 0.5 * (lo + hi)
        if _betai(a, b, mid) < target:
            lo = mid
        else:
            hi = mid
        if hi - lo < _BISECTION_XTOL:
            break
    result = 0.5 * (lo + hi)
    # Clamp against floating-point drift; the value is provably in [0, 1].
    if result < 0.0:
        return 0.0
    if result > 1.0:
        return 1.0
    return result


def union_bound(bounds: List[float]) -> float:
    """Boole's inequality: a SOUND combiner with NO independence assumption.

    For events ``E_1, ..., E_m`` (here: "step i admitted a non-equivalent
    mutation"), Boole's inequality gives

        P(union E_i) <= sum_i P(E_i)

    UNCONDITIONALLY — it does not assume the per-step failures are independent,
    so it is always valid for composing per-step false-admit upper bounds into a
    whole-chain false-admit upper bound.  (Assuming independence and multiplying
    ``(1 - b_i)`` would be tighter but UNSOUND, because correlated failures
    would make the true chain error larger than the product suggests.)

    Returns ``min(1.0, sum(bounds))``; an empty list returns ``0.0`` (the false
    admit probability of an empty chain is zero — there is nothing to admit).
    """
    return min(1.0, sum(bounds))
