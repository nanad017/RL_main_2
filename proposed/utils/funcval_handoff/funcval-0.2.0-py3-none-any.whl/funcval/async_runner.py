"""ProgressRewardRunner — the async behavioral progress-reward event stream.

The behavioral (CAPE detonation) oracle is slow: a detonation pair takes tens of
seconds to minutes.  An RL trainer cannot block a step on it.  This runner owns
a behavioral oracle plus a single background worker thread and turns the
slow oracle into an EVENT STREAM:

    job_id = runner.enqueue(orig_bytes, mut_bytes, meta)   # returns immediately
    ...                                                     # RL step proceeds
    # later, on the worker thread, when the detonation lands:
    cb(job_id, meta, evidence)                              # delivered to callbacks

The contract:
  * :meth:`enqueue` returns a monotonically increasing ``job_id`` WITHOUT
    waiting and WITHOUT touching the behavioral oracle: it only puts the
    ``(orig, mut)`` pair on the internal queue.  BOTH ``behavioral.submit`` AND
    ``behavioral.collect`` run on the worker thread (in :meth:`_verdict_for`), so
    even submit latency never touches the caller's RL step.
  * a single worker thread drains the queue, calls ``behavioral.submit`` then
    ``behavioral.collect`` on each pair, and fans the resulting
    :class:`funcval.Evidence` out to every callback registered via
    :meth:`on_verdict`.  Each callback receives
    ``(job_id, meta, evidence)`` — ``meta`` is the opaque dict the caller passed
    to ``enqueue`` (e.g. the RL episode/step ids), so the consumer can route the
    verdict back to the right transition.

How the consumer maps Evidence -> a shaped reward (NOT done here)
-----------------------------------------------------------------
This runner is deliberately reward-agnostic.  It delivers the typed Evidence and
nothing more; the RL loop decides the shaping.  A typical mapping the consumer
might implement in its callback:

  * :class:`funcval.Refuted`  -> a large negative reward (the mutation broke the
    program: a witnessed behavioral divergence).
  * :class:`funcval.Behavioral` -> a positive progress signal scaled by the
    similarity (``evidence.composite``), and/or a bonus when
    ``validator.admissible(evidence)`` is True (only possible once negatives
    calibrate the oracle's ``false_admit`` bound).
  * :class:`funcval.Unknown` (empty trace, transport failure) -> zero reward
    (no evidence either way).

Keeping that mapping in the consumer is intentional: the same event stream then
serves any reward design without the validator taking a policy position.  This
module is stdlib-only (``threading`` + ``queue``) and does NOT import or wire
into ``custom_det_env`` or any trainer.
"""
from __future__ import annotations

import itertools
import queue
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

from .evidence import Evidence, Unknown

#: A verdict callback receives (job_id, meta, evidence).
VerdictCallback = Callable[[int, Dict[str, Any], Evidence], None]


class ProgressRewardRunner:
    """Owns a behavioral oracle + one worker thread; streams behavioral verdicts.

    Dependency-light by design: stdlib ``threading`` + ``queue`` only.  The
    worker is lazily started on first :meth:`enqueue` (or explicitly via
    :meth:`start`), so constructing a runner is free.
    """

    def __init__(self, behavioral, *, daemon: bool = True) -> None:
        """
        Args:
            behavioral: a :class:`BehavioralOracle`-shaped object exposing
                ``submit(orig, mut) -> handle`` and ``collect(handle) ->
                Evidence``.
            daemon: run the worker as a daemon thread (default True) so it never
                blocks process exit.
        """
        if behavioral is None:
            raise ValueError(
                "ProgressRewardRunner requires a behavioral oracle (got None)."
            )
        self._behavioral = behavioral
        self._daemon = daemon

        self._queue: "queue.Queue[Optional[Tuple[int, Dict[str, Any], Any]]]" = (
            queue.Queue()
        )
        self._callbacks: List[VerdictCallback] = []
        self._cb_lock = threading.Lock()
        self._ids = itertools.count(1)
        self._worker: Optional[threading.Thread] = None
        self._started = False
        self._stop = threading.Event()
        self._lifecycle_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Callback registration
    # ------------------------------------------------------------------

    def on_verdict(self, cb: VerdictCallback) -> VerdictCallback:
        """Register a callback invoked as ``cb(job_id, meta, evidence)`` when a
        behavioral verdict lands.  Returns ``cb`` so it can be used as a
        decorator.  Multiple callbacks may be registered; all are called."""
        with self._cb_lock:
            self._callbacks.append(cb)
        return cb

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the worker thread (idempotent)."""
        with self._lifecycle_lock:
            if self._started:
                return
            self._stop.clear()
            self._worker = threading.Thread(
                target=self._run,
                name="funcval-progress-reward",
                daemon=self._daemon,
            )
            self._worker.start()
            self._started = True

    def enqueue(self, orig_bytes: bytes, mut_bytes: bytes, meta: Dict[str, Any]) -> int:
        """Queue a detonation pair and return its ``job_id`` immediately.

        This does NOT call the behavioral oracle: it only puts the pair on the
        internal queue and returns.  BOTH ``behavioral.submit`` and the slow
        ``behavioral.collect`` happen later on the worker thread (see
        :meth:`_verdict_for`), so even submit latency never touches the caller's
        RL step.  ``meta`` is opaque and echoed back to the callbacks verbatim.
        """
        if not self._started:
            self.start()
        job_id = next(self._ids)
        # submit is the non-blocking stage; do it on the worker so even submit
        # latency never touches the caller's RL step.
        self._queue.put((job_id, dict(meta), (orig_bytes, mut_bytes)))
        return job_id

    def stop(self, *, drain: bool = True, timeout: Optional[float] = None) -> None:
        """Stop the worker.  If ``drain`` is True, let queued jobs finish first
        (a sentinel is enqueued after them); otherwise signal an immediate stop.
        """
        with self._lifecycle_lock:
            if not self._started:
                return
            if not drain:
                self._stop.set()
            self._queue.put(None)  # sentinel
            worker = self._worker
        if worker is not None:
            worker.join(timeout=timeout)
        with self._lifecycle_lock:
            self._started = False

    # ------------------------------------------------------------------
    # Worker
    # ------------------------------------------------------------------

    def _run(self) -> None:
        while True:
            item = self._queue.get()
            try:
                if item is None:  # sentinel -> exit
                    return
                if self._stop.is_set():
                    continue
                job_id, meta, (orig_bytes, mut_bytes) = item
                evidence = self._verdict_for(orig_bytes, mut_bytes)
                self._dispatch(job_id, meta, evidence)
            finally:
                self._queue.task_done()

    def _verdict_for(self, orig_bytes: bytes, mut_bytes: bytes) -> Evidence:
        """Submit + collect on the worker, mapping any transport error to an
        :class:`funcval.Unknown` so one bad job never kills the worker thread."""
        try:
            handle = self._behavioral.submit(orig_bytes, mut_bytes)
            return self._behavioral.collect(handle)
        except Exception as exc:  # pragma: no cover - defensive isolation
            return Unknown(f"behavioral job failed: {exc!r}")

    def _dispatch(self, job_id: int, meta: Dict[str, Any], evidence: Evidence) -> None:
        with self._cb_lock:
            callbacks = list(self._callbacks)
        for cb in callbacks:
            try:
                cb(job_id, meta, evidence)
            except Exception:  # pragma: no cover - a bad callback can't break others
                # A consumer callback raising must not take down the worker or
                # the sibling callbacks.  Swallow; the consumer owns its errors.
                pass


__all__ = ["ProgressRewardRunner", "VerdictCallback"]
