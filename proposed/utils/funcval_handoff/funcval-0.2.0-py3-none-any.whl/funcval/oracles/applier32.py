"""SOUND 32-bit (i386) instruction-aligned equivalence applier.

This is the in-repo, sound applier for 32-bit PE malware. It deliberately does
NOT import or modify the shipped package at artifacts/dist/stoke_actions_pkg/.
It is single-purpose:

  * confirm the PE is 32-bit (COFF Machine == 0x14c / IMAGE_FILE_MACHINE_I386);
  * locate the executable section via the standard-library struct parser;
  * decode that section ONCE with capstone CS_MODE_32 and find sites where a
    decoded instruction's bytes EXACTLY equal an entry's ``original_hex``
    (instruction-aligned -> never corrupts operand/immediate/displacement bytes);
  * apply ONLY entries from ``equiv_library_32bit_verified.json`` (the
    re-verified-in-32-bit subset), size-preserving (orig and var are equal
    length by construction of the verified library);
  * patch bytes in place -> the PE never needs rebuilding (headers/section table
    keep their offsets).

Pass-2-only by design: unlike the shipped engine's three passes, the sound
ground-truth path applies ONLY verified equivalence substitutions so that any
behavioral change is attributable to a PROVEN-equivalent rewrite, not to padding
diversification or important-byte injection.
"""
from __future__ import annotations

import json
import random
import struct
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import capstone

IMAGE_SCN_MEM_EXECUTE = 0x20000000
IMAGE_FILE_MACHINE_I386 = 0x014C
_MAX_REASONABLE_SECTION = 1 << 30


def read_machine(pe_bytes: bytes) -> Optional[int]:
    n = len(pe_bytes)
    if n < 0x40 or pe_bytes[0:2] != b"MZ":
        return None
    (e_lfanew,) = struct.unpack_from("<I", pe_bytes, 0x3C)
    if not (0 < e_lfanew and e_lfanew + 6 <= n):
        return None
    if pe_bytes[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        return None
    (machine,) = struct.unpack_from("<H", pe_bytes, e_lfanew + 4)
    return machine


def find_text_bounds(pe_bytes: bytes) -> Optional[Tuple[int, int]]:
    """Return (file_offset, end_offset) of the executable section, or None."""
    n = len(pe_bytes)
    if n < 0x40 or pe_bytes[0:2] != b"MZ":
        return None
    (e_lfanew,) = struct.unpack_from("<I", pe_bytes, 0x3C)
    if e_lfanew <= 0 or e_lfanew + 24 > n:
        return None
    if pe_bytes[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        return None
    coff = e_lfanew + 4
    (num_sections,) = struct.unpack_from("<H", pe_bytes, coff + 2)
    (size_opt_hdr,) = struct.unpack_from("<H", pe_bytes, coff + 16)
    if num_sections == 0:
        return None
    sect_table = coff + 20 + size_opt_hdr
    entry_size = 40
    exec_fallback: Optional[Tuple[int, int]] = None
    for i in range(num_sections):
        ent = sect_table + i * entry_size
        if ent + entry_size > n:
            break
        name = pe_bytes[ent:ent + 8]
        (size_raw,) = struct.unpack_from("<I", pe_bytes, ent + 16)
        (ptr_raw,) = struct.unpack_from("<I", pe_bytes, ent + 20)
        (characteristics,) = struct.unpack_from("<I", pe_bytes, ent + 36)
        if ptr_raw <= 0 or size_raw <= 0 or size_raw > _MAX_REASONABLE_SECTION:
            continue
        if ptr_raw >= n:
            continue
        end = min(ptr_raw + size_raw, n)
        if end <= ptr_raw:
            continue
        if name.rstrip(b"\x00") == b".text":
            return ptr_raw, end
        if exec_fallback is None and (characteristics & IMAGE_SCN_MEM_EXECUTE):
            exec_fallback = (ptr_raw, end)
    return exec_fallback


def _aligned_sites_cs32(region: bytes, orig: bytes, base: int) -> List[int]:
    """Linear CS_MODE_32 disasm of `region`; ABSOLUTE offsets of insns == orig."""
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    sites: List[int] = []
    for insn in md.disasm(region, base):
        if bytes(insn.bytes) == orig:
            sites.append(insn.address)
    return sites


@dataclass
class Sub:
    offset: int
    original_hex: str
    variant_hex: str
    category: str = ""


@dataclass
class ApplyResult:
    machine: int
    is_i386: bool
    text_start: int
    text_end: int
    n_sites: int
    n_subs: int
    subs: List[Sub] = field(default_factory=list)
    mutated: Optional[bytes] = None
    changed: bool = False
    note: str = ""


def load_verified_library(path: str | Path) -> List[Dict]:
    d = json.loads(Path(path).read_text())
    entries = d["entries"] if isinstance(d, dict) and "entries" in d else d
    out = []
    for e in entries:
        oh, vh = e["original_hex"], e["variant_hex"]
        if len(bytes.fromhex(oh)) != len(bytes.fromhex(vh)):
            continue  # safety: only size-preserving
        out.append(e)
    return out


def apply_sound_32bit(
    pe_bytes: bytes,
    library: List[Dict],
    *,
    seed: Optional[int] = None,
    prob: float = 1.0,
    max_subs: Optional[int] = None,
) -> ApplyResult:
    """Apply ONLY verified-32-bit equivalence substitutions to a 32-bit PE.

    Args:
        pe_bytes: the raw PE bytes.
        library: list of entries from equiv_library_32bit_verified.json.
        seed: RNG seed (deterministic). None -> derive from content hash.
        prob: per-site application probability (1.0 = apply every found site).
        max_subs: hard cap on total substitutions (None = unbounded).

    Sites are recomputed against the CURRENT buffer for each pattern so an
    earlier substitution that changed instruction boundaries cannot create a
    false site for a later pattern.
    """
    machine = read_machine(pe_bytes)
    is_i386 = machine == IMAGE_FILE_MACHINE_I386
    res = ApplyResult(
        machine=machine if machine is not None else -1,
        is_i386=is_i386,
        text_start=-1, text_end=-1, n_sites=0, n_subs=0,
    )
    if not is_i386:
        res.note = f"machine 0x{machine:04x} != 0x014c (i386); refusing to apply"
        res.mutated = pe_bytes
        return res

    bounds = find_text_bounds(pe_bytes)
    if bounds is None:
        res.note = "no executable section found"
        res.mutated = pe_bytes
        return res
    start, end = bounds
    res.text_start, res.text_end = start, end

    if seed is None:
        import hashlib
        seed = int.from_bytes(hashlib.sha256(pe_bytes[:4096]).digest()[:8], "little")
    rng = random.Random(seed)

    buf = bytearray(pe_bytes)
    subs: List[Sub] = []

    # Build a pattern -> (variant, category) map. The library may contain
    # bidirectional pairs (both 31c0->29c0 AND 29c0->31c0). To avoid thrashing
    # a single physical site back and forth, we keep the FIRST mapping seen for
    # each original encoding and disassemble the .text exactly ONCE, visiting
    # each decoded instruction a single time (so every site is rewritten at most
    # once and instruction boundaries are sound by construction). This is
    # O(text + matches) instead of O(library * text).
    pat: Dict[bytes, Tuple[bytes, str]] = {}
    for e in library:
        orig = bytes.fromhex(e["original_hex"])
        var = bytes.fromhex(e["variant_hex"])
        if len(orig) != len(var):
            continue
        if orig not in pat:
            pat[orig] = (var, e.get("category", ""))

    region = bytes(buf[start:end])
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_32)
    total_sites = 0
    for insn in md.disasm(region, start):
        ib = bytes(insn.bytes)
        if ib in pat:
            total_sites += 1
            if max_subs is not None and len(subs) >= max_subs:
                continue
            if rng.random() < prob:
                var, cat = pat[ib]
                off = insn.address  # absolute file offset (base=start)
                buf[off:off + len(ib)] = var
                subs.append(Sub(offset=off, original_hex=ib.hex(),
                                variant_hex=var.hex(), category=cat))

    res.n_sites = total_sites
    res.n_subs = len(subs)
    res.subs = subs
    res.mutated = bytes(buf)
    res.changed = res.mutated != pe_bytes
    res.note = "ok"
    return res


__all__ = [
    "IMAGE_FILE_MACHINE_I386",
    "read_machine",
    "find_text_bounds",
    "load_verified_library",
    "apply_sound_32bit",
    "Sub",
    "ApplyResult",
]
