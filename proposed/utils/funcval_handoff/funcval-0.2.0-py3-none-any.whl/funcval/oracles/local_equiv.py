"""LocalEquivOracle — context-free full-architectural-state equivalence oracle.

This oracle answers ONE question about a byte-pair ``(original, variant)``:
"is the variant a sound drop-in replacement for the original under ANY
downstream live-out?"  It does so by emulating both snippets from the SAME
input machine state under Unicorn and comparing the ENTIRE architectural state
a downstream context could observe:

  * all 16 general-purpose registers at their FULL 64-bit width (the *parent*
    register, never a narrow 32-bit alias slice — comparing only the 32-bit
    slice is exactly the soundness hole that admitted the ``testl <-> andl/orl``
    defect, because ``andl`` zero-extends the upper 32 bits while ``testl``
    leaves them untouched);
  * all 16 XMM registers (128-bit);
  * the arithmetic EFLAGS bits CF,PF,AF,ZF,SF,OF (mask ``0x8D5``).

Full-state comparison is strictly stronger than checking a declared ``live_out``
subset: a pair that matches on the full *compared* state is a safe drop-in
replacement for any downstream consumer that reads only the locations this oracle
actually compares (the 16 GPRs + 16 XMM + arith EFLAGS).

LIMIT OF CLAIM — read before trusting this oracle (the honesty fix)
-------------------------------------------------------------------
This oracle establishes PER-INSTRUCTION / LOCAL ARCHITECTURAL equivalence over
the register+flag state it samples.  That is NOT the same as whole-binary
behavioral preservation, and the earlier docstring's "a safe drop-in replacement
under ANY live-out, which is exactly the contract a context-free .text rewrite
must satisfy" was an OVERCLAIM — it is false at the whole-binary level.  Two ways
a Sampled(k=0) here can still break the program:

  * MEMORY-WRITE GAP.  The compared scope is registers + flags + XMM ONLY; it
    does NOT compare MEMORY writes.  A rewrite that diverges only in a value
    written to memory (same final registers/flags, different bytes stored)
    samples k=0 and ADMITS, yet has changed observable behavior.  Treat the
    register/flag/XMM scope as exactly that — it says nothing about stores.
  * WHOLE-BINARY CONTEXT.  Local equivalence does NOT imply whole-binary
    behavioral preservation for self-modifying, self-checking, packed, or
    relocation-sensitive code.  Empirically: sample ``01ee8378…`` in
    ``artifacts/validator/ground_truth_behavioral.jsonl`` broke (API calls
    11706 -> 199) from a SINGLE per-instruction-equivalent rewrite.  Only the
    behavioral oracle speaks to whole-binary behavior, and while it is
    uncalibrated it can neither admit nor deny.

The harness logic (CODE/STACK mapping, NOP runway, ``count=64`` instruction cap,
``rsp``/``rbp`` pinned to a mapped stack, the ``eflags & 0x8D5`` mask) mirrors the
audited reference ``scripts/verify_substitution_table_functionality.py`` so the
two stay sound-by-construction identical on the emulation side.

WHAT IS NEW HERE (the critic's demand): the INPUT DISTRIBUTION.  Plain uniform
64-bit sampling under-weights the measure-≈0 corners where equivalence bugs
hide — most catastrophically the all-ones / 32-bit-sign-bit inputs that expose
the zero-extension class.  So each :meth:`LocalEquivOracle.produce` call runs a
deterministic BOUNDARY BATTERY first (all-registers-set-to-b for a set of
hazardous constants ``b``, plus a few per-register single-boundary-with-uniform-
rest variants), and only then draws the remaining ``n - battery_size`` states
i.i.d. uniform.  The uniform tail is re-seeded per call from ``os.urandom`` (NOT
a fixed seed: a fixed grid is gameable by an adaptive RL adversary), and the
seed is recorded in ``dist_id`` so any verdict is reproducible after the fact.

The verdict is typed evidence, never a bare bool:
  * the FIRST observed divergence -> :class:`funcval.Refuted` with the witnessing
    input state and the diverging registers;
  * zero divergences over all ``n`` draws -> :class:`funcval.Sampled` with
    ``k=0`` whose ``false_admit_bound()`` is the exact Clopper-Pearson upper
    bound ``clopper_pearson_upper(0, n, delta)``.
"""
from __future__ import annotations

import os
import random
from typing import Dict, List, Optional, Tuple, Union

import unicorn
from unicorn import x86_const as xc

from ..evidence import Refuted, Sampled, Scope, Unknown

# --- Architectural scope (mirrors the audited reference harness) -----------

#: The 16 GPRs compared at full 64-bit parent width.  Order is the canonical
#: Unicorn enumeration order; the oracle only relies on the *set*, never order.
GPR_NAMES_64: Tuple[str, ...] = (
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
)

#: The 8 i386 GPRs compared at 32-bit width in UC_MODE_32.  There are NO r8-r15
#: in 32-bit, and the 64-bit upper halves do NOT exist — comparing them would be
#: the *inverse* soundness hole (false-refusing genuinely-32-bit-equivalent pairs
#: like ``and eax,eax`` vs ``test eax,eax``, which only diverge in a 64-bit upper
#: half that 32-bit code can never observe).
GPR_NAMES_32: Tuple[str, ...] = (
    "eax", "ecx", "edx", "ebx", "esp", "ebp", "esi", "edi",
)

#: Arithmetic-defined EFLAGS: CF(0) PF(2) AF(4) ZF(6) SF(7) OF(11) == 0x8D5.
#: The other flag bits (DF, IF, reserved, ...) are not produced by the
#: arithmetic/logic instructions this library rewrites, so masking to 0x8D5 is
#: the sound comparison set; bit 1 is the always-1 reserved EFLAGS bit we set on
#: input but exclude from the compared mask.
EFLAGS_ARITH_MASK: int = (1 << 0) | (1 << 2) | (1 << 4) | (1 << 6) | (1 << 7) | (1 << 11)

# --- Memory map (identical addresses to the reference harness) -------------

CODE_BASE: int = 0x1000_0000
CODE_SIZE: int = 0x10000
STACK_BASE: int = 0x2000_0000
STACK_SIZE: int = 0x10000
#: rsp pinned here; rbp at STACK_TOP - 0x80.  Both inside the mapped stack so a
#: push/pop/lea-relative snippet does not fault on an unmapped address.
STACK_TOP: int = STACK_BASE + STACK_SIZE - 0x100

#: Instruction cap for a single snippet emulation (same as the reference).  A
#: context-free .text rewrite is a handful of instructions; 64 is generous slack
#: and also bounds runaway emulation on a malformed byte pair.
EMU_INSN_COUNT: int = 64

#: Input-validity cap: the MAX number of decoded instructions a verify-able
#: snippet may contain.  A context-free .text rewrite (or a short
#: instruction-aligned chain) is a HANDFUL of instructions — the proven library
#: entries are 1 instruction (<= 5 bytes) and legitimate multi-run chains are a
#: few.  A whole-PE / arbitrary byte blob decodes to dozens of instructions; an
#: input that decodes to MORE than this many is not a per-instruction rewrite
#: snippet, so the guard declines it (Unknown) rather than emulating a large
#: opaque blob and admitting.  8 is generous for real chains (the longest test
#: chain is 3) while rejecting arbitrary blobs (e.g. bytes(range(64)) -> 35
#: instructions in CS_MODE_32).
MAX_SNIPPET_INSNS: int = 8

# --- Boundary battery constants --------------------------------------------

#: Hazardous 64-bit fill constants.  Every register is set to the same constant
#: ``b`` for each value here.  The 0xFFFFFFFF and 0x80000000 vectors are the
#: ESSENTIAL ones: they place a value in the low 32 bits with a *distinct* upper
#: half, so any instruction that wrongly zero-extends (or wrongly preserves) the
#: upper 32 bits diverges on the full-64-bit comparison — this is the historical
#: ``testl <-> andl/orl`` defect class.
_BOUNDARY_FILLS: Tuple[int, ...] = (
    0x0000000000000000,  # all zero
    0xFFFFFFFFFFFFFFFF,  # 64-bit -1 (all ones)
    0x8000000000000000,  # 64-bit INT_MIN (sign bit only)
    0x8000000000000001,  # INT_MIN + 1
    0x7FFFFFFFFFFFFFFF,  # 64-bit INT_MAX
    0x0000000000000001,  # 1
    0x0000000000000002,  # 2
    0x00000000FFFFFFFF,  # 32-bit -1  -> exposes 32-bit zero-extension class
    0x0000000080000000,  # 32-bit sign bit -> exposes sign-extension class
    0x0000000100000000,  # bit 32 set, low 32 zero (upper-half-only value)
)

#: GPRs that receive an extra "single register at a boundary, the rest uniform"
#: probe.  These are the common implicit/explicit operands for the
#: arithmetic/logic rewrites in this library, so isolating a boundary in exactly
#: one of them (with entropy elsewhere) catches operand-specific upper-half bugs
#: that an all-registers-equal vector would mask via coincidental equality.
#: Named at 64-bit; the 32-bit equivalents are derived by stripping the leading
#: ``r`` -> ``e`` for the i386 subset present in :data:`GPR_NAMES_32`.
_CRITICAL_REGS_64: Tuple[str, ...] = ("rax", "rcx", "rdx", "rsi", "rdi")
_CRITICAL_REGS_32: Tuple[str, ...] = ("eax", "ecx", "edx", "esi", "edi")

#: The single-register boundary values used for the per-register probes (a
#: focused subset of _BOUNDARY_FILLS — the upper-half-distinguishing ones plus
#: zero and all-ones).
_SINGLE_REG_BOUNDARIES: Tuple[int, ...] = (
    0x00000000FFFFFFFF,  # 32-bit -1 (zero-extension hazard)
    0x0000000080000000,  # 32-bit sign bit
    0xFFFFFFFFFFFFFFFF,  # all ones
    0x0000000000000000,  # zero
)

HexOrBytes = Union[str, bytes, bytearray]


def _as_bytes(x: HexOrBytes) -> bytes:
    """Accept either a hex string (``"31c0"``) or raw ``bytes``."""
    if isinstance(x, (bytes, bytearray)):
        return bytes(x)
    if isinstance(x, str):
        return bytes.fromhex(x.strip())
    raise TypeError(f"expected hex str or bytes, got {type(x).__name__}")


def _import_capstone():
    """Return the capstone module, or None if unavailable."""
    try:
        import capstone  # noqa: WPS433  (lazy by design)

        return capstone
    except Exception:
        return None


def _decodes_cleanly(code: bytes, bits: int) -> bool:
    """True iff ``code`` is a valid per-instruction rewrite SNIPPET in the
    requested mode (capstone CS_MODE_32/64): a non-empty, FULLY-CONSUMED sequence
    of at most :data:`MAX_SNIPPET_INSNS` x86 instructions.

    Three rejection cases (the input-validity guard, Fix C):
      * DECODE ERROR / LEFTOVER BYTES — a whole-PE blob or an arbitrary byte
        string (or the footgun: 32-bit-only bytes decoded in 64-bit mode, e.g.
        ``40`` = a bare REX prefix) leaves bytes capstone cannot consume.
      * TOO MANY INSTRUCTIONS — a blob that happens to decode cleanly but to
        DOZENS of instructions (e.g. ``bytes(range(64))`` -> 35 instructions in
        CS_MODE_32) is not a per-instruction rewrite; reject it rather than
        emulate a large opaque blob and admit.
      * EMPTY — no instruction at all.

    Returning False makes the caller emit :class:`funcval.Unknown` instead of a
    spurious admissible k=0.  If capstone is unavailable the guard cannot run and
    returns True so the oracle degrades to its prior (unguarded) behavior — on
    VM1 capstone IS present so the guard is active.
    """
    cs = _import_capstone()
    if cs is None:
        return True  # cannot guard without capstone; degrade gracefully
    if not code:
        return False
    mode = cs.CS_MODE_32 if bits == 32 else cs.CS_MODE_64
    md = cs.Cs(cs.CS_ARCH_X86, mode)
    consumed = 0
    count = 0
    for insn in md.disasm(code, 0x0):
        consumed += insn.size
        count += 1
        if count > MAX_SNIPPET_INSNS:
            return False  # too many instructions for a per-instruction rewrite
    return count >= 1 and consumed == len(code)


def _gpr_consts(gpr_names: Tuple[str, ...]) -> Dict[str, int]:
    return {n: getattr(xc, f"UC_X86_REG_{n.upper()}") for n in gpr_names}


def _xmm_consts(count: int = 16) -> Dict[int, int]:
    out: Dict[int, int] = {}
    for i in range(count):
        cn = f"UC_X86_REG_XMM{i}"
        if hasattr(xc, cn):
            out[i] = getattr(xc, cn)
    return out


def _pin_stack(st: Dict[str, int], sp_name: str, bp_name: str) -> Dict[str, int]:
    """Force the stack pointer / base pointer into the mapped stack so
    stack-touching snippets don't fault.  ``sp_name``/``bp_name`` are the
    width-appropriate register names (rsp/rbp at 64-bit, esp/ebp at 32-bit).

    Returns the same dict (mutated) for convenience.
    """
    st[sp_name] = STACK_TOP
    st[bp_name] = STACK_TOP - 0x80
    return st


class LocalEquivOracle:
    """Full-architectural-state Unicorn differential equivalence oracle.

    One instance owns one Unicorn context (CODE + STACK mapped once and reused).
    The class is cheap to construct; constructing per produce-call is also fine.
    """

    def __init__(self, *, bits: int = 64) -> None:
        if bits not in (32, 64):
            raise ValueError(f"bits must be 32 or 64, got {bits!r}")
        self.bits = bits
        uc_mode = unicorn.UC_MODE_32 if bits == 32 else unicorn.UC_MODE_64
        self.uc = unicorn.Uc(unicorn.UC_ARCH_X86, uc_mode)
        self.uc.mem_map(CODE_BASE, CODE_SIZE)
        self.uc.mem_map(STACK_BASE, STACK_SIZE)
        # Width-appropriate register vocabulary.
        self.gpr_names: Tuple[str, ...] = (
            GPR_NAMES_32 if bits == 32 else GPR_NAMES_64
        )
        self.sp_name = "esp" if bits == 32 else "rsp"
        self.bp_name = "ebp" if bits == 32 else "rbp"
        self.critical_regs: Tuple[str, ...] = (
            _CRITICAL_REGS_32 if bits == 32 else _CRITICAL_REGS_64
        )
        self.gpr = _gpr_consts(self.gpr_names)
        # XMM8-15 do not exist in i386; comparing them in UC_MODE_32 trips a
        # Unicorn deprecated-register warning and is meaningless.  The 32-bit
        # verified library's scope is documented as "XMM0-7", so limit to 8 in
        # 32-bit mode and the full 16 in 64-bit mode.
        self.xmm = _xmm_consts(8 if bits == 32 else 16)
        # --- Fix B: memory-write hook -----------------------------------
        # Captures (addr, size, value) of every store during a run so the two
        # snippets' memory-write SETS can be differenced.  ``_mem_writes`` is
        # reset before each emulation and read after.
        self._mem_writes: List[Tuple[int, int, int]] = []
        self.uc.hook_add(unicorn.UC_HOOK_MEM_WRITE, self._on_mem_write)

    # --- Fix B: memory-write capture ---------------------------------------

    def _on_mem_write(self, uc, access, address, size, value, user_data):  # noqa: ANN001
        """Unicorn UC_HOOK_MEM_WRITE callback: record the store.

        ``value`` from Unicorn is the (signed) integer written; we mask it to the
        written ``size`` so a store of the same bytes compares equal regardless of
        sign representation.
        """
        masked = value & ((1 << (size * 8)) - 1)
        self._mem_writes.append((address, size, masked))

    # --- input-distribution construction -----------------------------------

    def _uniform_state(self, rng: random.Random) -> Dict[str, int]:
        """An i.i.d.-uniform input state (stack pointer/base pinned to the mapped
        stack).  GPRs are sampled at the architecture width (32 or 64 bits)."""
        width = self.bits
        st: Dict[str, int] = {}
        for n in self.gpr_names:
            st[n] = rng.getrandbits(width)
        _pin_stack(st, self.sp_name, self.bp_name)
        for i in self.xmm:
            st[f"xmm{i}"] = rng.getrandbits(128)
        st["eflags"] = 0x2 | (rng.getrandbits(16) & EFLAGS_ARITH_MASK)
        return st

    def _boundary_battery(self, rng: random.Random) -> List[Dict[str, int]]:
        """The deterministic-shape boundary battery (front-loaded before uniform).

        Two families:
          1. all-registers-set-to-``b`` for every ``b`` in :data:`_BOUNDARY_FILLS`,
             once with eflags=0 and once with eflags=ALL-arith-bits-set, so flag
             rewrites are probed at both extremes;
          2. per-critical-register single-boundary-with-uniform-rest probes, which
             isolate an upper-half hazard in one operand while keeping entropy
             elsewhere (an all-equal vector can mask a bug via coincidental
             cross-register equality).

        The "rest" entropy in family 2 comes from ``rng`` (the per-call urandom
        seed), so the battery is not a byte-for-byte fixed grid either.
        """
        battery: List[Dict[str, int]] = []
        width = self.bits
        reg_mask = (1 << width) - 1

        # Family 1: all registers = b, both eflags extremes.  At 32-bit the fill
        # constant is masked to 32 bits (the upper-half hazard vectors collapse to
        # the same 32-bit value, which is correct — there is no upper half).
        for b in _BOUNDARY_FILLS:
            bmasked = b & reg_mask
            for ef in (0x0, EFLAGS_ARITH_MASK):
                st: Dict[str, int] = {n: bmasked for n in self.gpr_names}
                _pin_stack(st, self.sp_name, self.bp_name)
                for i in self.xmm:
                    # XMM filled by replicating the 64-bit constant into 128 bits.
                    st[f"xmm{i}"] = (b << 64) | b
                st["eflags"] = 0x2 | (ef & EFLAGS_ARITH_MASK)
                battery.append(st)

        # Family 2: one critical reg at a boundary, the rest uniform.
        for reg in self.critical_regs:
            for bval in _SINGLE_REG_BOUNDARIES:
                st = self._uniform_state(rng)  # uniform base (already pins stack)
                if reg not in (self.sp_name, self.bp_name):  # keep pinned stack regs
                    st[reg] = bval & reg_mask
                battery.append(st)

        return battery

    def _build_states(self, n: int, rng: random.Random) -> List[Dict[str, int]]:
        """Boundary battery first, then (n - battery_size) uniform draws.

        If ``n`` is smaller than the battery, the battery is truncated to ``n``
        (the hazardous vectors are the highest priority, so they come first).
        """
        battery = self._boundary_battery(rng)
        if n <= len(battery):
            return battery[:n]
        tail = [self._uniform_state(rng) for _ in range(n - len(battery))]
        return battery + tail

    # --- emulation ----------------------------------------------------------

    def _write_state(self, st: Dict[str, int]) -> None:
        for n, c in self.gpr.items():
            self.uc.reg_write(c, st[n])
        for i, c in self.xmm.items():
            try:
                self.uc.reg_write(c, st[f"xmm{i}"])
            except Exception:
                pass
        self.uc.reg_write(xc.UC_X86_REG_EFLAGS, st["eflags"])

    def _read_full_state(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for n, c in self.gpr.items():
            out[n] = self.uc.reg_read(c)
        for i, c in self.xmm.items():
            out[f"xmm{i}"] = self.uc.reg_read(c)
        out["eflags"] = self.uc.reg_read(xc.UC_X86_REG_EFLAGS) & EFLAGS_ARITH_MASK
        return out

    def _run(self, code: bytes) -> bool:
        """Emulate ``code`` once.  Returns False on any emulation fault.

        Resets the memory-write capture buffer first; ``self._mem_writes`` holds
        the stores observed during THIS run when it returns True.  The NOP-runway
        write goes to CODE_BASE before ``code`` is overlaid, and the runway write
        is itself a write to CODE memory (not stack), but it happens BEFORE the
        buffer reset, so it never pollutes the captured set.
        """
        try:
            self.uc.mem_write(CODE_BASE, b"\x90" * EMU_INSN_COUNT)  # NOP runway
            self.uc.mem_write(CODE_BASE, code)
            self._mem_writes = []  # reset AFTER staging code so staging is excluded
            self.uc.emu_start(CODE_BASE, CODE_BASE + len(code), timeout=0, count=EMU_INSN_COUNT)
            return True
        except Exception:
            return False

    def _mem_write_set(self) -> "frozenset[Tuple[int, int, int]]":
        """The set of (addr, size, value) stores captured by the last :meth:`_run`."""
        return frozenset(self._mem_writes)

    def _liveout_for_witness(self, st: Dict[str, int]) -> Dict[str, str]:
        """Render a full-state dict as hex strings for a JSON-able witness."""
        return {k: hex(v) for k, v in st.items()}

    # --- public API ---------------------------------------------------------

    def produce(
        self,
        orig_bytes_or_hex: HexOrBytes,
        var_bytes_or_hex: HexOrBytes,
        *,
        n: int = 256,
        delta: float = 0.05,
    ):
        """Produce typed equivalence evidence for one ``(orig, var)`` byte pair.

        Args:
            orig_bytes_or_hex: original snippet, as hex string or raw bytes.
            var_bytes_or_hex: variant snippet, as hex string or raw bytes.
            n: total number of input states to test (battery + uniform tail).
            delta: residual error probability of the Clopper-Pearson bound.

        Returns:
            :class:`funcval.Unknown` if EITHER input is not a clean,
            fully-consumed instruction sequence in this oracle's mode (the
            input-validity guard — never emulate garbage and admit);
            :class:`funcval.Refuted` at the FIRST register/flag/XMM divergence,
            an execution fault the original does not exhibit, OR a memory-write-set
            difference (Fix B); else :class:`funcval.Sampled` with ``k=0`` over
            ``n`` draws.
        """
        orig = _as_bytes(orig_bytes_or_hex)
        var = _as_bytes(var_bytes_or_hex)

        # --- Fix C: input-validity guard ---------------------------------
        # Decode BOTH inputs in this oracle's mode; if either is not a clean,
        # fully-consumed instruction sequence (undecodable, leftover bytes, or
        # the wrong-width footgun), decline rather than emulate garbage.
        if not _decodes_cleanly(orig, self.bits):
            return Unknown(
                f"input-guard: original bytes {orig.hex()!r} do not decode to a "
                f"clean, fully-consumed x86-{self.bits} instruction sequence"
            )
        if not _decodes_cleanly(var, self.bits):
            return Unknown(
                f"input-guard: variant bytes {var.hex()!r} do not decode to a "
                f"clean, fully-consumed x86-{self.bits} instruction sequence"
            )

        # Re-seed per call from os.urandom; record the seed in dist_id so the
        # exact input sequence is reproducible from the verdict alone.
        seed = int.from_bytes(os.urandom(8), "little")
        rng = random.Random(seed)
        dist_id = (
            f"unicorn{self.bits}-fullstate-boundary+uniform+mem-n{n}-seed0x{seed:016x}"
        )

        gpr_label = "8 GPR@32-bit" if self.bits == 32 else "16 GPR@64-bit"
        live_out_names = frozenset(
            list(self.gpr_names)
            + [f"xmm{i}" for i in self.xmm]
            + ["eflags", "mem:writes"]
        )
        scope = Scope(
            live_out=live_out_names,
            input_dist=dist_id,
            notes=(
                f"full architectural state ({gpr_label} + {len(self.xmm)} XMM@128 "
                "+ eflags&0x8D5) PLUS the set of memory writes (addr,size,value); "
                "boundary battery front-loaded then i.i.d. uniform; stack pointer/"
                "base pinned to mapped stack. Memory WRITES ARE compared (a rewrite "
                "diverging only on a stored value is now Refuted, not admitted). "
                "Still LOCAL/per-instruction: says nothing about whole-binary "
                "behavior of self-modifying/packed/relocation-sensitive code."
            ),
        )

        states = self._build_states(n, rng)

        for st in states:
            # original
            self._write_state(st)
            if not self._run(orig):
                # An original that faults is not a usable baseline for this input;
                # skip — we cannot compare against a non-executing reference.  This
                # matches the reference harness intent (a fault is "orig-exec-fault"
                # and treated as non-equivalence only when the VARIANT faults).
                continue
            out_orig = self._read_full_state()
            mem_orig = self._mem_write_set()

            # variant from the SAME input
            self._write_state(st)
            if not self._run(var):
                return Refuted(
                    counterexample={
                        "input_state": self._liveout_for_witness(st),
                        "orig_liveout": self._liveout_for_witness(out_orig),
                        "var_liveout": None,
                        "diverging_regs": ["<variant-exec-fault>"],
                        "reason": "var-exec-fault",
                    },
                    scope=scope,
                    oracle="local_equiv",
                )
            out_var = self._read_full_state()
            mem_var = self._mem_write_set()

            if out_orig != out_var:
                diverging = sorted(k for k in out_orig if out_orig[k] != out_var[k])
                return Refuted(
                    counterexample={
                        "input_state": self._liveout_for_witness(st),
                        "orig_liveout": {k: hex(out_orig[k]) for k in diverging},
                        "var_liveout": {k: hex(out_var[k]) for k in diverging},
                        "diverging_regs": diverging,
                        "reason": "state-diff",
                    },
                    scope=scope,
                    oracle="local_equiv",
                )

            # --- Fix B: memory-write set comparison ----------------------
            if mem_orig != mem_var:
                only_orig = sorted(mem_orig - mem_var)
                only_var = sorted(mem_var - mem_orig)
                return Refuted(
                    counterexample={
                        "input_state": self._liveout_for_witness(st),
                        "orig_mem_writes": [
                            {"addr": hex(a), "size": s, "value": hex(v)}
                            for (a, s, v) in only_orig
                        ],
                        "var_mem_writes": [
                            {"addr": hex(a), "size": s, "value": hex(v)}
                            for (a, s, v) in only_var
                        ],
                        "diverging_regs": ["mem:writes"],
                        "reason": "mem-write-diff",
                    },
                    scope=scope,
                    oracle="local_equiv",
                )

        # Zero counterexamples over all n draws.
        return Sampled(n=n, k=0, dist_id=dist_id, live_out=scope, delta=delta)
