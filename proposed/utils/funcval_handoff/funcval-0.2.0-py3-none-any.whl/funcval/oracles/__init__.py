"""funcval oracles — concrete evidence-producing checkers.

An *oracle* takes a candidate (original, variant) pair and PRODUCES a typed
:class:`funcval.Evidence` verdict about whether the variant is observationally
equivalent to the original.  Oracles never admit/reject; they only emit
evidence (a :class:`funcval.Refuted` counterexample, a :class:`funcval.Sampled`
statistical bound, etc.).  The single admission decision lives in
:func:`funcval.admit`.

Currently shipped:

* :class:`LocalEquivOracle` — a context-free, full-architectural-state Unicorn
  differential oracle.  It emulates BOTH snippets from the SAME input state and
  compares the entire state a downstream context could observe (16 GPR@64-bit +
  16 XMM@128 + arithmetic EFLAGS).  Its input distribution front-loads a
  boundary battery (the measure-≈0 inputs where bugs such as the 32-bit
  zero-extension defect live) before drawing fresh-entropy i.i.d. uniform
  states, and re-seeds per call from ``os.urandom`` so a fixed grid cannot be
  gamed by an RL adversary.
"""
from __future__ import annotations

# ProvenOracle / recheck_cert are stdlib-only at import (capstone/z3 are lazy
# inside proven.py), so they can be imported eagerly.  LocalEquivOracle pulls in
# ``unicorn`` at module import and BehavioralOracle's transport pulls in the CAPE
# stack, so both are exposed LAZILY via PEP 562 ``__getattr__``: that keeps
# ``import funcval.oracles.proven`` (and therefore ``import funcval``) free of a
# hard unicorn dependency, while ``from funcval.oracles import LocalEquivOracle``
# still works on demand.
from .proven import ProvenOracle, recheck_cert

__all__ = [
    "BehavioralOracle",
    "LocalEquivOracle",
    "ProvenOracle",
    "recheck_cert",
]


def __getattr__(name):  # PEP 562 — lazy attribute import
    if name == "LocalEquivOracle":
        from .local_equiv import LocalEquivOracle

        return LocalEquivOracle
    if name == "BehavioralOracle":
        from .behavioral import BehavioralOracle

        return BehavioralOracle
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(__all__)
