"""BehavioralOracle — the CAPE/sandbox detonation evidence producer.

This oracle turns a pair of dynamic-analysis (CAPE) detonations into a typed
:class:`funcval.Behavioral` verdict.  It NEVER admits a mutation on its own:
behavioral similarity is a NOISY observation, not a proof, and — critically —
this project has *no* labelled NEGATIVE (known-different) calibration data yet,
so the honest false-admit bound is ``None`` and the ledger's :func:`admit`
treats the evidence like Unknown until negatives calibrate it.  The oracle's
job is to PRODUCE a calibrated-or-honestly-uncalibrated similarity signal that
the async progress-reward path can emit; the gate decision stays in
:func:`funcval.admit`.

Why the naive composite is NOT trusted (the measured fact this oracle honors)
=============================================================================
Detonating the SAME benign PE twice (tasks 7992 vs 7993, the noise-floor
experiment in ``artifacts/validator/cape_noise_floor.json``) scored a weighted
composite of **0.9585** — but 4 of the 6 behavioral channels
(``file_ops``, ``network_ops``, ``dropped_files``, ``mutexes``) were EMPTY in
BOTH traces and each scored ``1.0`` VACUOUSLY (``_counter_similarity`` returns
1.0 for empty-vs-empty).  The only channel that actually varied was
``api_calls`` (Jaccard 0.8814); ``registry_ops`` had real events (5 vs 5) and
matched.  So the equal-weighted composite is *misleading* — it is propped up by
channels that carry no evidence.

NON-EMPTY-CHANNEL SCORING is the fix: a channel where BOTH reports have zero
events contributes NOTHING.  We re-normalize the per-channel weights over only
the channels that are non-empty in at least one of the two reports, treat
``api_calls`` as the primary signal, and expose both the ``nonempty_composite``
and the per-channel breakdown.  For 7992-vs-7993 this collapses the {api,
registry} channels to ~0.917 (dominated by the real api_calls 0.8814), NOT the
inflated 0.9585.

Empty-trace gate
================
A broken-vs-broken pair (both samples never meaningfully detonated) must NEVER
score an admissible similarity.  If EITHER report has fewer than
``min_api_calls`` API calls AND ~no file/registry/network ops, the oracle
returns :class:`funcval.Unknown` — the sample did not run, so there is no
behavioral evidence to compare.  This mirrors the transport-layer
``_is_empty_trace`` gate in ``CapeCliClient`` so the two notions of "empty"
agree.

Calibration (honest)
====================
If a ``calibration_path`` is supplied and exists, it is loaded.  Expected
schema (produced by the ground-truth experiment; see ``score_reports`` /
``artifacts/validator/behavioral_calibration.json``):

    {
      "positive": {"mean": <float>, "stdev": <float>, "min": <float>,
                   "n": <int>},     # api-similarity of KNOWN-EQUIVALENT pairs
      "negative": {"mean": <float>, "stdev": <float>, "n": <int>,
                   "samples": [<float>, ...]}   # OPTIONAL known-DIFFERENT pairs
    }

The equivalence threshold is the noise-floor lower band of the POSITIVE
distribution::

    threshold = pos_mean - k_sigma * pos_stdev

and the ``false_admit`` bound is::

    P(api_similarity >= threshold | NOT equivalent)

estimated from the NEGATIVE distribution if present (empirical tail fraction).
**If NO negatives are available, ``false_admit`` is ``None``** — we cannot bound
the false-admit probability without negative examples.  This is the honest
state, and it is the current state of this project: the ground-truth run only
produces POSITIVE (equivalent) pairs.  We do NOT fabricate a number from the
positive distribution alone.

Async split
===========
``submit(orig, mut) -> handle`` stages + submits both PEs and returns
``{orig_task, mut_task, guests}`` WITHOUT waiting.  ``collect(handle) ->
Evidence`` polls, fetches, and scores.  ``produce(orig, mut)`` is exactly
``submit`` then ``collect`` for the synchronous case.  The facade's async runner
calls ``submit`` then later ``collect`` so a slow detonation does not block the
RL step; the resulting Evidence is emitted as a progress-reward event.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Optional

from ..evidence import Behavioral, Evidence, Scope, Unknown

# The 6 behavioral channels, mirroring SandboxVerifier.CATEGORIES, and the
# canonical weights.  We never re-implement the per-channel scoring — we read
# compare_behavior's per_category output and re-normalize weights over the
# non-empty subset.
_CHANNELS = ("api_calls", "file_ops", "registry_ops", "network_ops",
             "dropped_files", "mutexes")
_CHANNEL_WEIGHTS = {
    "api_calls":     0.35,
    "file_ops":      0.15,
    "registry_ops":  0.15,
    "network_ops":   0.15,
    "dropped_files": 0.10,
    "mutexes":       0.10,
}

#: Default empty-trace gate (mirrors CapeCliClient.MIN_API_CALLS / design §8).
_DEFAULT_MIN_API_CALLS = 20
#: Default noise-floor band width: threshold = pos_mean - k_sigma*pos_stdev.
_DEFAULT_K_SIGMA = 3.0

#: The full behavioral live-out vocabulary the detonation could observe.
_BEHAVIOR_LIVE_OUT = frozenset({
    "behavior:api", "behavior:file", "behavior:registry",
    "behavior:network", "behavior:dropped", "behavior:mutex",
})


class BehavioralOracle:
    """Produce :class:`funcval.Behavioral` evidence from CAPE detonations.

    See the module docstring for the design.  The oracle has NO hard CAPE
    dependency at import time: the :class:`CapeCliClient` transport is built
    lazily on first use (or injected for tests).
    """

    def __init__(
        self,
        client=None,
        calibration_path=None,
        min_api_calls: int = _DEFAULT_MIN_API_CALLS,
        k_sigma: float = _DEFAULT_K_SIGMA,
    ) -> None:
        """
        Args:
            client: a ``CapeCliClient``-shaped transport (submit/poll/
                fetch_report/verify_pair).  ``None`` = build one lazily on first
                use, so ``import funcval`` carries no CAPE dependency.
            calibration_path: path to a behavioral-calibration JSON (positive +
                optional negative api-similarity distributions).  ``None`` or a
                missing file => UNCALIBRATED (threshold/false_admit = None).
            min_api_calls: empty-trace gate threshold (see module docstring).
            k_sigma: width of the noise-floor band for the equivalence
                threshold (``pos_mean - k_sigma * pos_stdev``).
        """
        self._client = client
        self.min_api_calls = int(min_api_calls)
        self.k_sigma = float(k_sigma)

        self._calibration_path = (
            Path(calibration_path) if calibration_path else None
        )
        self._calibration = self._load_calibration(self._calibration_path)
        # Derived calibration quantities (None when uncalibrated).
        self._threshold: Optional[float] = None
        self._false_admit: Optional[float] = None
        self._threshold_basis = "UNCALIBRATED"
        if self._calibration is not None:
            self._derive_calibration(self._calibration)

    # ------------------------------------------------------------------
    # Lazy transport
    # ------------------------------------------------------------------

    @property
    def client(self):
        """The CAPE transport, built lazily so import has no CAPE dependency."""
        if self._client is None:
            # Imported HERE (not at module top) so `import funcval` does not pull
            # in the CAPE transport / its deps.
            from funcval.cape.cape_cli_client import CapeCliClient

            self._client = CapeCliClient(min_api_calls=self.min_api_calls)
        return self._client

    # ------------------------------------------------------------------
    # Calibration
    # ------------------------------------------------------------------

    @staticmethod
    def _load_calibration(path: Optional[Path]) -> Optional[Dict]:
        """Load the calibration JSON, or None if path is None / missing /
        unreadable.  A missing file is the honest UNCALIBRATED state, never an
        error."""
        if path is None or not path.exists():
            return None
        try:
            return json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            return None

    def _derive_calibration(self, calib: Dict) -> None:
        """Derive threshold + false_admit from the positive/negative dists.

        threshold = pos_mean - k_sigma * pos_stdev   (noise-floor band)
        false_admit = P(api_sim >= threshold | NOT equivalent), from negatives;
                      None if no negatives are present (honest: cannot bound
                      false admits without negative examples).
        """
        pos = calib.get("positive") or calib.get("pos")
        if not pos or pos.get("mean") is None:
            # Calibration file present but no positive distribution -> still
            # uncalibrated for thresholding purposes.
            return
        pos_mean = float(pos["mean"])
        pos_stdev = float(pos.get("stdev", pos.get("std", 0.0)))
        self._threshold = pos_mean - self.k_sigma * pos_stdev
        self._threshold_basis = (
            f"pos_mean - {self.k_sigma:g}sigma (calibration)"
        )

        neg = calib.get("negative") or calib.get("neg")
        if neg:
            self._false_admit = self._estimate_false_admit(neg, self._threshold)
        else:
            # No negatives -> cannot bound the false-admit probability. Honest.
            self._false_admit = None

    @staticmethod
    def _estimate_false_admit(neg: Dict, threshold: float) -> Optional[float]:
        """P(api_similarity >= threshold | NOT equivalent), from the NEGATIVE
        (known-different) distribution.

        Prefers the empirical tail fraction over explicit ``samples`` (no
        distributional assumption).  Falls back to a normal-tail estimate from
        (mean, stdev) when only summary stats are present.  Returns None if the
        negative block has neither.
        """
        samples = neg.get("samples")
        if samples:
            samples = [float(s) for s in samples]
            n = len(samples)
            if n == 0:
                return None
            k = sum(1 for s in samples if s >= threshold)
            return k / n
        # Summary-stats fallback: normal upper-tail P(X >= threshold).
        mean = neg.get("mean")
        stdev = neg.get("stdev", neg.get("std"))
        if mean is None or stdev is None:
            return None
        mean = float(mean)
        stdev = float(stdev)
        if stdev <= 0.0:
            return 1.0 if mean >= threshold else 0.0
        # 1 - Phi(z) where z = (threshold - mean)/stdev, via erfc.
        z = (threshold - mean) / stdev
        return 0.5 * math.erfc(z / math.sqrt(2.0))

    @property
    def calibrated(self) -> bool:
        """True iff a usable positive distribution gave us a threshold."""
        return self._threshold is not None

    # ------------------------------------------------------------------
    # Non-empty-channel scoring (the core fix)
    # ------------------------------------------------------------------

    def score_reports(self, orig_report: Dict, mut_report: Dict) -> Dict:
        """Score a pair of CAPE reports with NON-EMPTY-channel weighting.

        REUSES ``CapeCliClient``-style ``compare_behavior`` (via the lazily-built
        scorer) — does not re-implement per-channel similarity.  A channel where
        BOTH reports have zero events contributes NOTHING to the composite (it is
        not evidence; the underlying scorer would score it a vacuous 1.0).

        Returns:
            {
              "raw_compare": <full compare_behavior dict>,
              "nonempty_composite": float,   # weight-renormalized over non-empty
              "api_similarity": float,        # the primary signal
              "api_counts": {"original": int, "mutated": int, "common": int},
              "nonempty_channels": [str, ...],  # channels that carried evidence
            }
        """
        cmp = self._scorer().compare_behavior(orig_report, mut_report)
        per_cat = cmp.get("per_category", {})

        nonempty: List[str] = []
        for ch in _CHANNELS:
            d = per_cat.get(ch, {})
            if (d.get("original_count", 0) or 0) > 0 or (d.get("mutated_count", 0) or 0) > 0:
                nonempty.append(ch)

        # Re-normalize the canonical weights over ONLY the non-empty channels.
        total_w = sum(_CHANNEL_WEIGHTS[ch] for ch in nonempty)
        if total_w > 0:
            nonempty_composite = sum(
                per_cat[ch]["similarity"] * _CHANNEL_WEIGHTS[ch] / total_w
                for ch in nonempty
            )
        else:
            # No channel carried any evidence at all (every channel empty in
            # both) -> there is nothing to compare. 0.0 is the honest score;
            # the empty-trace gate upstream turns this into Unknown anyway.
            nonempty_composite = 0.0

        api = per_cat.get("api_calls", {})
        return {
            "raw_compare": cmp,
            "nonempty_composite": round(nonempty_composite, 4),
            "api_similarity": float(api.get("similarity", 0.0)),
            "api_counts": {
                "original": int(api.get("original_count", 0) or 0),
                "mutated": int(api.get("mutated_count", 0) or 0),
                "common": int(api.get("common_count", 0) or 0),
            },
            "nonempty_channels": nonempty,
        }

    def _scorer(self):
        """The reused SandboxVerifier scorer (via the transport client).

        We borrow the client's ``_scorer`` so scoring is byte-for-byte the same
        as ``verify_pair``.  Built lazily; needs no live box call.
        """
        return self.client._scorer

    # ------------------------------------------------------------------
    # Empty-trace gate
    # ------------------------------------------------------------------

    def _api_count(self, report: Dict) -> int:
        beh = self._scorer().extract_behavior(report)
        return len(beh.get("api_calls", []))

    def _other_ops(self, report: Dict) -> int:
        beh = self._scorer().extract_behavior(report)
        return (
            len(beh.get("file_ops", []))
            + len(beh.get("registry_ops", []))
            + len(beh.get("network_ops", []))
        )

    def _empty_trace_reason(self, orig_report: Dict, mut_report: Dict) -> Optional[str]:
        """Return an Unknown reason string iff EITHER report is an empty trace
        (< min_api_calls api calls AND no file/reg/net ops), else None.

        A broken-vs-broken pair must never score an admissible similarity.
        """
        n_o, n_m = self._api_count(orig_report), self._api_count(mut_report)
        o_other, m_other = self._other_ops(orig_report), self._other_ops(mut_report)
        orig_empty = n_o < self.min_api_calls and o_other == 0
        mut_empty = n_m < self.min_api_calls and m_other == 0
        if orig_empty or mut_empty:
            return f"empty trace: orig={n_o} mut={n_m} api calls"
        return None

    # ------------------------------------------------------------------
    # Evidence construction
    # ------------------------------------------------------------------

    def _build_evidence(self, score: Dict, *, timeout: int) -> Behavioral:
        """Wrap a scored pair into a :class:`Behavioral`.

        ``composite`` carries the NON-EMPTY composite (not the misleading naive
        weighted composite). ``false_admit`` is the calibrated bound or None.
        With ``false_admit=None`` the ledger's :func:`funcval.admit` returns
        False — behavioral evidence REPORTS similarity (a usable progress-reward
        signal) but does NOT by itself clear the gate until negatives calibrate
        it.  That is the correct, honest behavior.
        """
        api = score["api_counts"]
        coverage = {
            "api": {"original": api["original"], "mutated": api["mutated"],
                    "common": api["common"]},
            "nonempty_channels": score["nonempty_channels"],
            "api_similarity": score["api_similarity"],
        }
        # Surface the per-channel file/registry counts for audit.
        per_cat = score["raw_compare"].get("per_category", {})
        for ch in ("file_ops", "registry_ops", "network_ops"):
            d = per_cat.get(ch, {})
            coverage[ch] = {
                "original": int(d.get("original_count", 0) or 0),
                "mutated": int(d.get("mutated_count", 0) or 0),
            }

        noise_floor = self._threshold if self._threshold is not None else 0.0
        return Behavioral(
            composite=score["nonempty_composite"],
            noise_floor=noise_floor,
            threshold_basis=self._threshold_basis,
            coverage=str(coverage),
            false_admit=self._false_admit,
            scope=Scope(
                live_out=_BEHAVIOR_LIVE_OUT,
                input_dist=f"cape:win11:t{timeout}",
                notes="behavioral detonation similarity",
            ),
        )

    # ------------------------------------------------------------------
    # Sync path
    # ------------------------------------------------------------------

    def produce(self, orig_bytes: bytes, mut_bytes: bytes, *,
                timeout: int = 120) -> Evidence:
        """BLOCKING: detonate both, score, gate, and return Evidence.

        Equivalent to :meth:`submit` then :meth:`collect`.  Returns:
          * :class:`funcval.Unknown` if a detonation did not complete, a report
            could not be fetched, or either trace is empty (gate);
          * :class:`funcval.Behavioral` otherwise — with ``composite`` =
            non-empty composite, and ``false_admit`` = the calibrated bound or
            ``None``.  NOTE: with ``false_admit=None`` (the current uncalibrated
            state — no negatives exist yet) :func:`funcval.admit` returns False:
            behavioral evidence reports similarity but cannot clear the gate
            alone until negatives calibrate it.
        """
        handle = self.submit(orig_bytes, mut_bytes, timeout=timeout)
        return self.collect(handle, timeout=timeout)

    # ------------------------------------------------------------------
    # Async split (progress-reward path)
    # ------------------------------------------------------------------

    def submit(self, orig_bytes: bytes, mut_bytes: bytes, *,
               timeout: int = 120) -> Dict:
        """Stage + submit BOTH PEs to (different) guests WITHOUT waiting.

        Returns a handle ``{orig_task, mut_task, guests, timeout}`` the
        :meth:`collect` call later resolves.  This is the split the facade's
        async runner uses so a slow detonation never blocks the RL step.
        """
        client = self.client
        # Round-robin two distinct guests (mirrors verify_pair's fan-out).
        g_o = client._next_guest()
        g_m = client._next_guest()
        t_orig = client.submit(orig_bytes, machine=g_o, timeout=timeout)
        t_mut = client.submit(mut_bytes, machine=g_m, timeout=timeout)
        return {
            "orig_task": t_orig,
            "mut_task": t_mut,
            "guests": (g_o, g_m),
            "timeout": timeout,
        }

    def collect(self, handle: Dict, *, timeout: Optional[int] = None) -> Evidence:
        """Poll the submitted pair to terminal, fetch reports, score, gate.

        Returns the same Evidence kinds as :meth:`produce`.  A non-DONE task,
        a fetch failure, or an empty trace all map to :class:`funcval.Unknown`
        — NEVER a silent admissible Behavioral.
        """
        # Imported lazily for the same no-hard-dependency reason as the client.
        from funcval.cape.cape_cli_client import (
            CapeReportError,
            CapeTransportError,
            PollState,
        )

        client = self.client
        t_orig = handle["orig_task"]
        t_mut = handle["mut_task"]
        eff_timeout = handle.get("timeout", 120) if timeout is None else timeout

        try:
            states = client.await_terminal((t_orig, t_mut))
        except CapeTransportError as exc:
            return Unknown(f"transport failed awaiting tasks: {exc}")

        for tid in (t_orig, t_mut):
            if states.get(tid) != PollState.DONE:
                st = states.get(tid)
                return Unknown(
                    f"task {tid} did not complete "
                    f"(state={st.value if st else '?'})"
                )

        try:
            rep_o = client.fetch_report(t_orig)
            rep_m = client.fetch_report(t_mut)
        except (CapeReportError, CapeTransportError) as exc:
            return Unknown(f"report fetch failed: {exc}")

        return self._evidence_from_reports(rep_o, rep_m, timeout=eff_timeout)

    # ------------------------------------------------------------------
    # Offline-testable core: reports -> Evidence (no transport)
    # ------------------------------------------------------------------

    def _evidence_from_reports(self, orig_report: Dict, mut_report: Dict, *,
                               timeout: int) -> Evidence:
        """Gate + score a fetched pair of reports into Evidence.

        Split out so the empty-trace gate, the non-empty scoring, and the
        Behavioral construction can be exercised entirely OFFLINE from saved
        report JSON, with no live box call.
        """
        gate = self._empty_trace_reason(orig_report, mut_report)
        if gate is not None:
            return Unknown(gate)
        score = self.score_reports(orig_report, mut_report)
        return self._build_evidence(score, timeout=timeout)
