"""ProvenOracle — emits a Proof ONLY with a machine-re-checkable certificate.

This oracle exists to KILL the project's central overclaim.  The legacy
PROVENANCE layer (``lib/pe_shim/functionality_integrity/provenance.py``) reads
the ``proof_tier`` of the proven equivalence library and admits a pair as a
guaranteed PASS (confidence 1.0) on the strength of an Intel-SDM *argument* —
i.e. ~91% of the library rests on a human structural claim that was never
mechanically checked.  An SDM argument is not the same epistemic object as a
machine-checked proof, and treating it as ``false_admit == 0`` is exactly the
bug this redesign removes.

``ProvenOracle.produce`` therefore emits :class:`funcval.Proof` (false-admit
bound ``0.0``) ONLY when it can attach a certificate that some other process
can mechanically re-verify:

  * **TIER 1 — DECODE_IDENTICAL** (covers ~91% of the cleaned library, all the
    ``alt_modrm_d_bit_swap`` entries):  if BOTH byte sequences disassemble
    (capstone, x86-64) to exactly one instruction each and their normalized
    text (mnemonic + operands, whitespace-collapsed) is IDENTICAL, then the two
    encodings ARE the same instruction — e.g. ``01 c3`` and ``03 d8`` both
    disassemble to ``add ebx, eax``.  This is a structural proof and it is
    re-checkable: re-disassemble and re-compare.

  * **TIER 2 — Z3_UNSAT** (best-effort, for the idiom patterns that do NOT
    decode-identically):  build a Z3 bit-vector model of both operations'
    effect on the result register(s) + the defined EFLAGS and ask the solver to
    find ANY input where they differ.  UNSAT ⟹ proven equivalent for ALL
    inputs.  The SMT-LIB query is stored as the cert payload and re-checked by
    re-running Z3 and asserting ``unsat``.

Anything it cannot certify with one of those two re-checkable certs becomes
:class:`funcval.Unknown` (the composing validator then falls through to the
``LocalEquivOracle`` sampled bound).  The oracle NEVER emits a Proof backed by
an ``SDM_ARGUMENT`` cert — honesty over coverage.

``capstone`` and ``z3`` are imported LAZILY: ``lib/funcval`` has no hard
dependency on either.  If a cert library is absent at runtime, that cert path
degrades to ``Unknown`` rather than crashing.
"""
from __future__ import annotations

import json
import os
from importlib import resources
from pathlib import Path
from typing import Dict, Optional, Tuple

from ..evidence import Cert, Evidence, Proof, Scope, Unknown

#: Filename of the canonical cleaned 64-bit library bundled inside the wheel
#: under ``funcval/data/`` (6480 STRUCTURAL_PROVEN entries; the 100 false 32-bit
#: same_reg_self_op pairs are dropped).
LIBRARY_FILENAME = "equiv_library_proven_v3_cleaned.json"

#: Filename of the SOUND 32-bit (i386) verified subset bundled alongside it
#: (1476 entries: the non-REX subset of the 64-bit library, each re-verified
#: under UC_MODE_32 / CS_MODE_32; see ``equiv_32bit_verified_v1`` ``__meta__``).
#: Selected by :func:`resolve_library_path` when ``bits == 32`` so a 32-bit
#: caller never matches a 64-bit-only encoding.
LIBRARY_FILENAME_32BIT = "equiv_library_32bit_verified.json"

#: Environment variable that, when set, overrides the library location entirely.
#: (Applies to BOTH widths — a caller that overrides is taking full ownership of
#: which library is consulted, so the override wins regardless of ``bits``.)
LIBRARY_ENV_VAR = "FUNCVAL_LIBRARY_PATH"


def _default_repo_path(filename: str) -> Path:
    """Repo-relative fallback for an editable in-tree checkout where the artifact
    lives under ``artifacts/stoke_maps/``."""
    return (
        Path(__file__).resolve().parents[3]
        / "artifacts"
        / "stoke_maps"
        / filename
    )


# Repo-relative fallback path (LAST resort, used only for an editable in-tree
# checkout where the artifact lives at the repo root).  In the installed wheel
# the library is resolved from the bundled ``funcval/data/`` package data via
# :func:`resolve_library_path`; this constant is preserved for back-compat.
DEFAULT_LIBRARY_PATH = _default_repo_path(LIBRARY_FILENAME)


def resolve_library_path(bits: int = 64) -> Path:
    """Resolve the proven-equivalence library FOR THE GIVEN WIDTH, in priority
    order:

      1. ``$FUNCVAL_LIBRARY_PATH`` if the env var is set (caller override; wins
         for both widths).
      2. The library BUNDLED in the wheel under ``funcval/data/`` (the normal
         installed-package path), located via :mod:`importlib.resources` — the
         64-bit cleaned library for ``bits == 64`` and the sound 32-bit verified
         subset for ``bits == 32``.
      3. The repo-relative fallback under ``artifacts/stoke_maps/`` (editable
         in-tree checkout).

    Returns a :class:`pathlib.Path`.  The env override is returned verbatim even
    if it does not exist (so a caller's typo surfaces as a clear load error
    rather than being silently masked by the bundled copy); the bundled path is
    only used when it actually exists.
    """
    if bits not in (32, 64):
        raise ValueError(f"bits must be 32 or 64, got {bits!r}")
    filename = LIBRARY_FILENAME_32BIT if bits == 32 else LIBRARY_FILENAME

    env = os.environ.get(LIBRARY_ENV_VAR)
    if env:
        return Path(env)

    try:
        bundled = resources.files("funcval") / "data" / filename
        bundled_path = Path(str(bundled))
        if bundled_path.exists():
            return bundled_path
    except (ModuleNotFoundError, FileNotFoundError, TypeError):
        # importlib.resources could not locate the package data; fall through to
        # the repo-relative fallback rather than crashing.
        pass

    return _default_repo_path(filename)


def resolve_library_path_32bit() -> Path:
    """Convenience alias for ``resolve_library_path(bits=32)`` (mirrors the
    request's suggested resolver name)."""
    return resolve_library_path(bits=32)

# --- Architectural scope vocabulary ---------------------------------------
# Mirrors LocalEquivOracle's naming so scopes compose under set containment.

_GPR_NAMES_64: Tuple[str, ...] = (
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
)
_XMM_NAMES: Tuple[str, ...] = tuple(f"xmm{i}" for i in range(16))

#: Conservative SUPERSET live-out for a DECODE_IDENTICAL proof.  Because the two
#: byte strings decode to the *same* instruction, every architectural location
#: is trivially equal regardless of which location the instruction actually
#: touches; claiming the full GP+flags+xmm state is sound (it's the identity).
_FULL_STATE_LIVE_OUT = frozenset(_GPR_NAMES_64 + _XMM_NAMES + ("eflags",))

#: Defined arithmetic EFLAGS bits modelled by the Z3 certs (CF,PF,ZF,SF,OF).
#: AF is left out: it is "defined-as-undefined" for these idioms and masked in
#: the project baseline, so we neither claim nor compare it.
_Z3_FLAG_NAMES: Tuple[str, ...] = ("cf", "pf", "zf", "sf", "of")


# --- Library index --------------------------------------------------------


class _ProvenEntry:
    __slots__ = ("orig_hex", "var_hex", "pattern", "tier", "orig_asm", "var_asm")

    def __init__(self, orig_hex, var_hex, pattern, tier, orig_asm, var_asm):
        self.orig_hex = orig_hex
        self.var_hex = var_hex
        self.pattern = pattern
        self.tier = tier
        self.orig_asm = orig_asm
        self.var_asm = var_asm


def _load_index(path: Path) -> Dict[Tuple[str, str], _ProvenEntry]:
    raw = json.loads(Path(path).read_text())
    if isinstance(raw, dict) and "entries" in raw:
        items = raw["entries"]
    elif isinstance(raw, list):
        items = raw
    else:
        raise ValueError(f"unsupported library schema at {path}")
    index: Dict[Tuple[str, str], _ProvenEntry] = {}
    for ent in items:
        if not isinstance(ent, dict):
            continue
        try:
            orig = str(ent["original_hex"]).lower()
            var = str(ent["variant_hex"]).lower()
        except KeyError:
            continue
        e = _ProvenEntry(
            orig_hex=orig,
            var_hex=var,
            pattern=str(ent.get("proof_pattern") or ""),
            tier=str(ent.get("proof_tier") or ""),
            orig_asm=str(ent.get("original_asm") or ""),
            var_asm=str(ent.get("variant_asm") or ""),
        )
        index[(orig, var)] = e
        index.setdefault((var, orig), e)
    return index


# --- capstone helpers (lazy) ----------------------------------------------


def _import_capstone():
    """Return the capstone module, or None if unavailable."""
    try:
        import capstone  # noqa: WPS433  (lazy by design)

        return capstone
    except Exception:
        return None


def _cs_mode(cs_module, bits: int):
    """Map an architecture width to the capstone mode constant."""
    return cs_module.CS_MODE_32 if bits == 32 else cs_module.CS_MODE_64


def _disasm_single(cs_module, hex_str: str, bits: int = 64) -> Optional[str]:
    """Disassemble ``hex_str`` in the requested width (32 or 64); return the
    normalized text of the SOLE instruction, or None if it does not decode to
    exactly one instruction.

    Normalization: ``"<mnemonic> <op_str>"`` lowercased with all internal
    whitespace collapsed to single spaces and stripped.  Capstone is configured
    in its DEFAULT Intel syntax here, and we compare two encodings that were both
    decoded by THIS SAME configured decoder (SAME mode), so they normalize to
    identical text when (and only when) they decode to the same instruction.
    (This is a same-decoder consistency property, not a claim that the string is
    canonical across every disassembler or syntax flavour — AT&T input is never
    involved; the inputs are raw bytes.)
    """
    try:
        data = bytes.fromhex(hex_str)
    except ValueError:
        return None
    md = cs_module.Cs(cs_module.CS_ARCH_X86, _cs_mode(cs_module, bits))
    insns = list(md.disasm(data, 0x0))
    # Require: decodes cleanly AND consumes every byte AND is exactly one insn.
    if len(insns) != 1:
        return None
    insn = insns[0]
    if insn.size != len(data):
        return None
    text = f"{insn.mnemonic} {insn.op_str}".strip()
    return " ".join(text.split()).lower()


def _decode_mnem_ops(cs_module, hex_str: str, bits: int = 64):
    """Disassemble ``hex_str`` in the requested width and return
    ``(mnemonic, [op, ...])`` for the sole instruction, or None.  Operands are
    the comma-split, whitespace-stripped, lowercased ``op_str`` tokens (e.g.
    ``("test", ["edi", "eax"])``)."""
    try:
        data = bytes.fromhex(hex_str)
    except ValueError:
        return None
    md = cs_module.Cs(cs_module.CS_ARCH_X86, _cs_mode(cs_module, bits))
    insns = list(md.disasm(data, 0x0))
    if len(insns) != 1 or insns[0].size != len(data):
        return None
    insn = insns[0]
    ops = [o.strip().lower() for o in insn.op_str.split(",")] if insn.op_str else []
    return insn.mnemonic.lower(), ops


#: 32-bit register name -> its 64-bit parent, so the idiom scope token uses the
#: SAME full-width register name LocalEquivOracle compares (a proof over ``eax``
#: implies the full ``rax`` parent because the idioms write the whole register or
#: leave it unchanged — and the upper bits are equal in both encodings).
_E_TO_R = {
    "eax": "rax", "ecx": "rcx", "edx": "rdx", "ebx": "rbx",
    "esp": "rsp", "ebp": "rbp", "esi": "rsi", "edi": "rdi",
    "r8d": "r8", "r9d": "r9", "r10d": "r10", "r11d": "r11",
    "r12d": "r12", "r13d": "r13", "r14d": "r14", "r15d": "r15",
}


def _z3_idiom_dst_token(cs_module, orig_hex: str, bits: int = 64) -> str:
    """Map the idiom's destination operand to a CONCRETE register name so the
    proof scope set-intersects with the differential oracle's vocabulary at the
    SAME width.

    The xor/sub-to-zero and self-op idioms are ``op r, r``; the first operand is
    the destination register.  We decode it (in ``bits`` mode).  At ``bits == 64``
    a 32-bit operand is normalized to its 64-bit parent (the idiom writes the
    whole register or leaves it unchanged, and the upper bits agree).  At
    ``bits == 32`` the i386 register name (``eax`` ...) is used directly so it
    set-intersects LocalEquivOracle's 32-bit scope vocabulary.  If decoding fails
    we return ``"dst_reg"`` — a deliberately non-architectural placeholder that
    intersects nothing (a conservative scope, never an over-claim).
    """
    decoded = _decode_mnem_ops(cs_module, orig_hex, bits=bits)
    if decoded is None:
        return "dst_reg"
    _mn, ops = decoded
    if not ops:
        return "dst_reg"
    reg = ops[0].strip().lower()
    if bits == 32:
        return reg  # already a 32-bit name (eax, ...) matching the 32-bit scope
    return _E_TO_R.get(reg, reg)


# --- SIMD bitwise-alias structural cert (ISA_BITWISE_ALIAS) ----------------
#
# pxor/xorpd, pand/andpd, por/orpd, pandn/andnpd are EQUIVALENT by ISA
# DEFINITION: each pair is the IDENTICAL 128-bit bitwise operation, differing
# only in the (microarchitectural) SIMD bypass DOMAIN the SDM documents — NOT in
# the result bits.  That is a STRUCTURAL/DEFINITIONAL fact, not something Z3 can
# derive non-circularly: a Z3 model of "xor==xor" is vacuous (it would 'prove'
# pxor==por just as readily, since both sides are whatever expression you write
# twice).  So we certify it structurally: decode BOTH encodings (capstone,
# CS_MODE_64), confirm the (mnemonic_a, mnemonic_b) pair is in the whitelist
# below AND both operate on the SAME ordered operands.  Re-check re-decodes and
# re-runs exactly this whitelist + operand-identity test.

#: Whitelisted aliased mnemonic pairs (unordered): each side denotes the SAME
#: 128-bit bitwise op.  Stored as frozensets so order does not matter.
_SIMD_ALIAS_WHITELIST = frozenset(
    {
        frozenset({"pxor", "xorpd"}),
        frozenset({"pxor", "xorps"}),
        frozenset({"pand", "andpd"}),
        frozenset({"pand", "andps"}),
        frozenset({"por", "orpd"}),
        frozenset({"por", "orps"}),
        frozenset({"pandn", "andnpd"}),
        frozenset({"pandn", "andnps"}),
    }
)


def _simd_alias_match(cs_module, orig_hex: str, var_hex: str, bits: int = 64) -> Optional[dict]:
    """If ``(orig, var)`` is a whitelisted SIMD bitwise alias on IDENTICAL
    operands, return a small dict describing the match (the cert payload);
    else None.

    The match requires, for BOTH single-instruction decodes (in ``bits`` mode):
      * the (mnemonic_orig, mnemonic_var) unordered pair is in
        :data:`_SIMD_ALIAS_WHITELIST` (so a non-alias like pxor/por is rejected),
      * the two mnemonics are genuinely DIFFERENT (an identity pair is not an
        "alias" proof; it would already be DECODE_IDENTICAL), and
      * the operand lists are IDENTICAL and non-empty (same xmm registers in the
        same order — a different-operand pair is NOT the same operation).
    """
    a = _decode_mnem_ops(cs_module, orig_hex, bits=bits)
    b = _decode_mnem_ops(cs_module, var_hex, bits=bits)
    if a is None or b is None:
        return None
    (mn_a, ops_a), (mn_b, ops_b) = a, b
    if mn_a == mn_b:
        return None  # identical mnemonic is DECODE_IDENTICAL territory, not alias
    if frozenset({mn_a, mn_b}) not in _SIMD_ALIAS_WHITELIST:
        return None
    if not ops_a or ops_a != ops_b:
        return None  # must operate on the SAME ordered operands
    return {
        "kind": "ISA_BITWISE_ALIAS",
        "orig_hex": orig_hex,
        "var_hex": var_hex,
        "mnemonics": sorted({mn_a, mn_b}),
        "operands": ops_a,
    }


def _is_commutative_test_reorder(cs_module, orig_hex: str, var_hex: str, bits: int = 64) -> bool:
    """True iff both encodings are a single ``test`` of the SAME two register
    operands in SWAPPED order (e.g. ``test edi, eax`` vs ``test eax, edi``).

    This is the only non-decode-identical shape present in the cleaned library's
    ``alt_modrm_d_bit_swap`` set; gating on it keeps the TEST-commutativity cert
    sound (we never apply it to a non-commutative reorder)."""
    a = _decode_mnem_ops(cs_module, orig_hex, bits=bits)
    b = _decode_mnem_ops(cs_module, var_hex, bits=bits)
    if a is None or b is None:
        return False
    (mn_a, ops_a), (mn_b, ops_b) = a, b
    if mn_a != "test" or mn_b != "test":
        return False
    if len(ops_a) != 2 or len(ops_b) != 2:
        return False
    # Same two operands, swapped order (and genuinely a swap, not identical).
    return ops_a == ops_b[::-1] and ops_a != ops_b


# --- Z3 idiom models (lazy) -----------------------------------------------


def _import_z3():
    try:
        import z3  # noqa: WPS433

        return z3
    except Exception:
        return None


def _z3_flag_exprs(z3, value, width: int = 64):
    """Return a dict of the five defined EFLAGS as 1-bit BitVecs derived from a
    ``width``-bit result ``value``, matching the semantics of a logic/zero op
    (and the project's masked baseline):

      ZF = (value == 0)
      SF = msb(value)
      PF = even parity of the low 8 bits
      CF = 0   (logic ops clear carry)
      OF = 0   (logic ops clear overflow)

    These are correct for XOR/SUB-to-zero, AND, OR, and TEST on (r, r): for the
    self-ops the result feeding the flags is ``r`` (AND r,r == OR r,r == r and
    TEST r,r computes r&r==r), and for the zero idioms it is ``0``.  We model the
    flags as a function of the relevant value and let Z3 prove the two encodings'
    flag vectors coincide for ALL ``r``.  ``width`` selects 32-bit vs 64-bit
    operand size (MSB position and the zero constant track it).
    """
    one = z3.BitVecVal(1, 1)
    zero = z3.BitVecVal(0, 1)
    zf = z3.If(value == z3.BitVecVal(0, width), one, zero)
    sf = z3.Extract(width - 1, width - 1, value)
    # PF: parity of the low byte (1 if even number of set bits).
    low8 = z3.Extract(7, 0, value)
    bits = [z3.Extract(i, i, low8) for i in range(8)]
    xor_acc = bits[0]
    for b in bits[1:]:
        xor_acc = xor_acc ^ b
    pf = z3.If(xor_acc == z3.BitVecVal(0, 1), one, zero)  # even parity -> PF=1
    cf = zero
    of = zero
    return {"cf": cf, "pf": pf, "zf": zf, "sf": sf, "of": of}


def _z3_prove_zero_idiom(z3, width: int = 64) -> Optional[str]:
    """xor r,r  ==  sub r,r.  Both write 0 to the destination and set
    ZF=1,SF=0,OF=0,CF=0,PF=1 (AF masked).  Returns the SMT-LIB query string iff
    the negation is UNSAT, else None.  ``width`` is the operand width (32/64).
    """
    r = z3.BitVec("r", width)
    res_xor = r ^ r           # == 0
    res_sub = r - r           # == 0
    f_xor = _z3_flag_exprs(z3, res_xor, width)
    f_sub = _z3_flag_exprs(z3, res_sub, width)
    s = z3.Solver()
    diffs = [res_xor != res_sub]
    for name in _Z3_FLAG_NAMES:
        diffs.append(f_xor[name] != f_sub[name])
    s.add(z3.Or(*diffs))
    return s.sexpr() if s.check() == z3.unsat else None


def _z3_prove_self_op(z3, width: int = 64) -> Optional[str]:
    """test r,r  ==  and r,r  ==  or r,r  on (r, r).

    test does not write the register; and/or write back ``r & r == r`` /
    ``r | r == r`` — i.e. the register is UNCHANGED in all three cases.  All
    three set ZF/SF/PF from ``r`` and clear CF/OF (AF masked).  We prove that
    the (register-after, flag-vector) pair is identical for test vs and/or.
    ``width`` is the operand width (32/64).
    """
    r = z3.BitVec("r", width)
    reg_test = r              # test leaves r untouched
    reg_and = r & r           # == r
    reg_or = r | r            # == r
    f_test = _z3_flag_exprs(z3, r, width)
    f_and = _z3_flag_exprs(z3, reg_and, width)
    f_or = _z3_flag_exprs(z3, reg_or, width)
    s = z3.Solver()
    diffs = [reg_test != reg_and, reg_test != reg_or]
    for name in _Z3_FLAG_NAMES:
        diffs.append(f_test[name] != f_and[name])
        diffs.append(f_test[name] != f_or[name])
    s.add(z3.Or(*diffs))
    return s.sexpr() if s.check() == z3.unsat else None


def _z3_prove_test_commute(z3, width: int = 64) -> Optional[str]:
    """test a,b  ==  test b,a  (TEST is commutative).

    The ~592 ``alt_modrm_d_bit_swap`` entries that are NOT decode-identical are
    all ``TEST`` pairs whose d-bit swap REORDERS the two operands (e.g.
    ``test edi, eax`` vs ``test eax, edi``).  TEST writes no register; it only
    sets flags from ``a & b``, which is symmetric in a,b.  So the two encodings
    are equivalent for ALL inputs.  We prove the flag vector of ``a & b`` equals
    that of ``b & a`` (register state is untouched by both, trivially equal).
    ``width`` is the operand width (32/64).
    """
    a = z3.BitVec("a", width)
    b = z3.BitVec("b", width)
    f_ab = _z3_flag_exprs(z3, a & b, width)
    f_ba = _z3_flag_exprs(z3, b & a, width)
    s = z3.Solver()
    diffs = [f_ab[name] != f_ba[name] for name in _Z3_FLAG_NAMES]
    s.add(z3.Or(*diffs))
    return s.sexpr() if s.check() == z3.unsat else None


# NOTE: there is deliberately NO ``_z3_prove_simd_alias``.  An SMT model of the
# SIMD bitwise aliases is necessarily VACUOUS — both sides of e.g. pxor==xorpd are
# the SAME 128-bit XOR by ISA definition, so any honest Z3 query reduces to
# ``x != x`` (trivially UNSAT regardless of which two mnemonics you picked, hence
# worthless: it would 'prove' pxor==por too).  The equivalence is STRUCTURAL, not
# derivable, so it is certified by :func:`_simd_alias_match` with an
# ``ISA_BITWISE_ALIAS`` cert instead (see :meth:`ProvenOracle.produce`).


#: Map proof_pattern -> the Z3 model builder.  A pattern absent here that is not
#: decode-identical defers to Unknown.  ``simd_bitwise_alias`` is intentionally
#: NOT here — it is handled by the structural ISA_BITWISE_ALIAS path, never Z3.
_Z3_PATTERN_MODELS = {
    "zero_idiom_xor_sub": _z3_prove_zero_idiom,
    "same_reg_self_op": _z3_prove_self_op,
}


# --- Re-checking certs -----------------------------------------------------


def recheck_cert(cert: Cert) -> bool:
    """Mechanically re-verify a cert produced by :class:`ProvenOracle`.

    * ``DECODE_IDENTICAL``: re-disassemble the two stored hex byte strings and
      assert their normalized instruction text is identical.
    * ``ISA_BITWISE_ALIAS``: re-decode the two stored hex byte strings and assert
      the (mnemonic, mnemonic) pair is in the SIMD alias whitelist AND both
      operate on the same ordered operands.  (This is a STRUCTURAL re-check of a
      definitional ISA fact, NOT a derived Z3 proof — see ``_simd_alias_match``.)
    * ``Z3_UNSAT``: re-run the stored SMT-LIB query and assert ``unsat``.

    Returns False (never raises) if the required library is unavailable or the
    re-check does not hold — a cert that cannot be re-verified must not pass.
    """
    if cert.cert_kind == "DECODE_IDENTICAL":
        cs = _import_capstone()
        if cs is None:
            return False
        try:
            payload = json.loads(cert.payload)
            bits = int(payload.get("bits", 64))
            t_orig = _disasm_single(cs, payload["orig_hex"], bits=bits)
            t_var = _disasm_single(cs, payload["var_hex"], bits=bits)
        except Exception:
            return False
        return t_orig is not None and t_orig == t_var
    if cert.cert_kind == "ISA_BITWISE_ALIAS":
        cs = _import_capstone()
        if cs is None:
            return False
        try:
            payload = json.loads(cert.payload)
            bits = int(payload.get("bits", 64))
            match = _simd_alias_match(
                cs, payload["orig_hex"], payload["var_hex"], bits=bits
            )
        except Exception:
            return False
        # Re-decode must reproduce a whitelist + identical-operand match AND the
        # stored mnemonics/operands must match what we re-derived (no tampering).
        if match is None:
            return False
        return (
            match["mnemonics"] == payload.get("mnemonics")
            and match["operands"] == payload.get("operands")
        )
    if cert.cert_kind == "Z3_UNSAT":
        z3 = _import_z3()
        if z3 is None:
            return False
        try:
            solver = z3.Solver()
            solver.from_string(cert.payload)
            return solver.check() == z3.unsat
        except Exception:
            return False
    # SDM_ARGUMENT / ALIVE2 / unknown kinds: this oracle never produces them and
    # cannot re-check them here.
    return False


# --- The oracle ------------------------------------------------------------


class ProvenOracle:
    """Emits a re-checkable :class:`funcval.Proof` for proven-library pairs, or
    :class:`funcval.Unknown` for everything it cannot certify."""

    oracle_version = "funcval/proven-v1"

    def __init__(
        self, library_path: Optional[Path] = None, *, bits: int = 64
    ) -> None:
        if bits not in (32, 64):
            raise ValueError(f"bits must be 32 or 64, got {bits!r}")
        self._bits = bits
        self._library_path = (
            Path(library_path) if library_path else resolve_library_path(bits=bits)
        )
        self._index = _load_index(self._library_path)

    @property
    def bits(self) -> int:
        return self._bits

    @property
    def library_path(self) -> Path:
        return self._library_path

    @property
    def size(self) -> int:
        return len(self._index)

    def lookup(self, orig_hex: str, var_hex: str) -> Optional[_ProvenEntry]:
        return self._index.get((orig_hex.lower(), var_hex.lower()))

    def produce(self, orig_hex: str, var_hex: str) -> Evidence:
        orig = (orig_hex or "").strip().lower()
        var = (var_hex or "").strip().lower()
        entry = self._index.get((orig, var))
        if entry is None:
            return Unknown("not in proven library")

        bits = self._bits

        # --- TIER 1: DECODE_IDENTICAL ------------------------------------
        cs = _import_capstone()
        if cs is not None:
            t_orig = _disasm_single(cs, orig, bits=bits)
            t_var = _disasm_single(cs, var, bits=bits)
            if t_orig is not None and t_orig == t_var:
                payload = json.dumps(
                    {"orig_hex": orig, "var_hex": var, "disasm": t_orig, "bits": bits},
                    sort_keys=True,
                )
                cert = Cert(
                    cert_kind="DECODE_IDENTICAL",
                    payload=payload,
                    recheckable=True,
                )
                scope = Scope(
                    live_out=_FULL_STATE_LIVE_OUT,
                    input_dist=None,
                    notes="two encodings of one instruction",
                )
                return Proof(cert=cert, scope=scope)

        # --- TIER 2a: Z3_UNSAT for commutative-TEST operand reorders ------
        # The non-decode-identical alt_modrm entries are all `test` pairs whose
        # d-bit swap REORDERS the two register operands (test a,b vs test b,a).
        # TEST is commutative and writes no register, so it is Z3-provable.
        if cs is not None and _is_commutative_test_reorder(cs, orig, var, bits=bits):
            z3 = _import_z3()
            if z3 is None:
                return Unknown(
                    "z3 unavailable; cannot certify commutative-test reorder; "
                    "defer to local_equiv"
                )
            smt2 = _z3_prove_test_commute(z3, width=bits)
            if smt2 is None:
                return Unknown(
                    "z3 could not prove commutative-test reorder; defer to local_equiv"
                )
            cert = Cert(cert_kind="Z3_UNSAT", payload=smt2, recheckable=True)
            scope = Scope(
                live_out=frozenset(_Z3_FLAG_NAMES),
                input_dist=None,
                notes="TEST is commutative: test a,b == test b,a (flags only; no reg write)",
            )
            return Proof(cert=cert, scope=scope)

        # --- TIER 2c: ISA_BITWISE_ALIAS (structural SIMD alias) ----------
        # The SIMD bitwise aliases (pxor/xorpd, pand/andpd, por/orpd,
        # pandn/andnpd) are equivalent by ISA DEFINITION, not by a derivable
        # proof.  Certify them STRUCTURALLY (decode + whitelist + operand
        # identity) — never with a vacuous Z3 query.  Gated on a successful match
        # so a NON-alias pair (e.g. pxor vs por) falls through to Unknown.
        if cs is not None and entry.pattern == "simd_bitwise_alias":
            match = _simd_alias_match(cs, orig, var, bits=bits)
            if match is None:
                return Unknown(
                    "simd_bitwise_alias entry did not pass the structural "
                    "whitelist+operand-identity check; defer to local_equiv"
                )
            payload_dict = dict(match)
            payload_dict["bits"] = bits
            cert = Cert(
                cert_kind="ISA_BITWISE_ALIAS",
                payload=json.dumps(payload_dict, sort_keys=True),
                recheckable=True,
            )
            scope = Scope(
                live_out=frozenset(_XMM_NAMES),
                input_dist=None,
                notes=(
                    "SIMD bitwise alias (ISA-definitional): both encodings are the "
                    "identical 128-bit bitwise op on the same xmm operands; "
                    "structurally re-checkable, NOT a derived Z3 proof"
                ),
            )
            return Proof(cert=cert, scope=scope)

        # --- TIER 2b: Z3_UNSAT (best-effort idioms) ----------------------
        builder = _Z3_PATTERN_MODELS.get(entry.pattern)
        if builder is None:
            return Unknown(
                f"no re-checkable cert for pattern {entry.pattern!r}; defer to local_equiv"
            )
        z3 = _import_z3()
        if z3 is None:
            return Unknown(
                f"z3 unavailable; cannot certify pattern {entry.pattern!r}; defer to local_equiv"
            )
        try:
            smt2 = builder(z3, width=bits)
        except Exception as exc:  # pragma: no cover - defensive
            return Unknown(
                f"z3 model error for pattern {entry.pattern!r} ({exc}); defer to local_equiv"
            )
        if smt2 is None:
            return Unknown(
                f"z3 could not prove pattern {entry.pattern!r}; defer to local_equiv"
            )

        # These idioms (xor/sub-to-zero, self-op test/and/or) operate on a single
        # register r,r and the five defined arith flags.  The library entry does
        # not name WHICH concrete register, and the Z3 model is parametric in r,
        # so the honest scope is "the (single) destination register operand of
        # this instruction, whatever it is" + the flags.  We decode the operand
        # to a CONCRETE register name (e.g. "rax"/"eax") so the scope vocabulary
        # set-intersects with LocalEquivOracle's concrete names; if decoding the
        # operand fails we fall back to the explicit "dst_reg:<n>" placeholder
        # (documented as a non-architectural token that intersects nothing — a
        # conservative scope, never an over-claim).
        dst_token = (
            _z3_idiom_dst_token(cs, orig, bits=bits) if cs is not None else "dst_reg"
        )
        live_out = frozenset((dst_token,) + _Z3_FLAG_NAMES)
        notes = (
            f"Z3 bit-vector proof for {entry.pattern}: identical dst reg "
            f"({dst_token}) + CF/PF/ZF/SF/OF"
        )
        cert = Cert(cert_kind="Z3_UNSAT", payload=smt2, recheckable=True)
        scope = Scope(live_out=live_out, input_dist=None, notes=notes)
        return Proof(cert=cert, scope=scope)


__all__ = [
    "ProvenOracle",
    "recheck_cert",
    "resolve_library_path",
    "resolve_library_path_32bit",
    "DEFAULT_LIBRARY_PATH",
    "LIBRARY_FILENAME",
    "LIBRARY_FILENAME_32BIT",
    "LIBRARY_ENV_VAR",
]
