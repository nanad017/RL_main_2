"""Algorithmic semantic-preserving x86-64 mutation engine.

Vendored from ``lib/pe_shim/text_mutate.py``. Three length-preserving passes
operate IN PLACE on a ``.text`` byte buffer:

  1. PADDING REPLACEMENT  — inter-function alignment padding (0xCC / 0x90 runs)
     is refilled with equivalent multi-byte NOP forms.
  2. EQUIVALENCE SUBSTITUTION — same-length x86-64 instruction equivalences are
     applied at 50% probability per occurrence. This is the ``rewrites`` layer:
     the resolved set of (orig, var) pairs is applied here (DEFAULT_REWRITES by
     default, or a caller-supplied / bundled set instead).
  3. IMPORTANT-BYTE INJECTION — a fraction of padding runs are refilled with
     high-importance code-like bytes (call stubs, prologue bytes, etc).

All edits are length-equal, so the caller patches the bytes back into the PE
without rebuilding. A hard ``max_mutations`` counter (the public ``n``) bounds
total edits with a deterministic pass order (1 -> 2 -> 3). The optional CNN/AV/
param strategies, distribution matcher and metrics machinery from the original
have been dropped to keep this lean.

SOUNDNESS: passes 1 and 3 only ever touch 0xCC / 0x90 padding runs and are
pure-Python byte work — always safe. Pass 2 (equivalence substitution) used to
be a naive ``bytes.find`` scan, which would corrupt operand/immediate bytes that
happen to spell a pattern. It is now INSTRUCTION-ALIGNED: candidate sites are
the start offsets of REAL decoded instructions whose encoding equals the
pattern. This needs capstone (an optional dep). When capstone is absent pass 2
is SKIPPED entirely (with a one-time warning) so the safe algorithmic passes
still run with zero dependencies.
"""
from __future__ import annotations

import hashlib
import random
import warnings
from typing import Iterable, List, Optional, Sequence, Tuple

from .pe import _aligned_sites_in_buf

# ── Well-known same-length x86_64 instruction equivalences ──────────────────
# Each entry: (pattern_bytes, replacement_bytes, description). MUST be same
# length (in-place substitution, no size change). This becomes DEFAULT_REWRITES.
#
# NOTE: several entries are bidirectional (e.g. 85c0->09c0 AND 09c0->85c0).
# When applied as a single pass that is fine — each occurrence is visited once
# in table order and edited with 50% probability; the counter caps total edits.
EQUIV_TABLE: List[Tuple[bytes, bytes, str]] = [
    # ── test reg, reg  ↔  or reg, reg (same flags, same size, 2 bytes) ──
    (b"\x85\xc0", b"\x09\xc0", "test eax,eax -> or eax,eax"),
    (b"\x09\xc0", b"\x85\xc0", "or eax,eax -> test eax,eax"),
    (b"\x85\xc9", b"\x09\xc9", "test ecx,ecx -> or ecx,ecx"),
    (b"\x09\xc9", b"\x85\xc9", "or ecx,ecx -> test ecx,ecx"),
    (b"\x85\xd2", b"\x09\xd2", "test edx,edx -> or edx,edx"),
    (b"\x09\xd2", b"\x85\xd2", "or edx,edx -> test edx,edx"),
    (b"\x85\xdb", b"\x09\xdb", "test ebx,ebx -> or ebx,ebx"),
    (b"\x85\xf6", b"\x09\xf6", "test esi,esi -> or esi,esi"),
    (b"\x85\xff", b"\x09\xff", "test edi,edi -> or edi,edi"),
    # ── xor reg, reg — two encodings (opcode 31 vs 33, mod=11, 2 bytes) ──
    (b"\x31\xc0", b"\x33\xc0", "xor eax,eax enc1->enc2"),
    (b"\x33\xc0", b"\x31\xc0", "xor eax,eax enc2->enc1"),
    (b"\x31\xc9", b"\x33\xc9", "xor ecx,ecx enc1->enc2"),
    (b"\x33\xc9", b"\x31\xc9", "xor ecx,ecx enc2->enc1"),
    (b"\x31\xd2", b"\x33\xd2", "xor edx,edx enc1->enc2"),
    (b"\x33\xd2", b"\x31\xd2", "xor edx,edx enc2->enc1"),
    (b"\x31\xdb", b"\x33\xdb", "xor ebx,ebx enc1->enc2"),
    (b"\x33\xdb", b"\x31\xdb", "xor ebx,ebx enc2->enc1"),
    (b"\x31\xf6", b"\x33\xf6", "xor esi,esi enc1->enc2"),
    (b"\x31\xff", b"\x33\xff", "xor edi,edi enc1->enc2"),
    # ── sub reg, reg  ↔  xor reg, reg (both zero reg, 2 bytes) ──
    (b"\x29\xc0", b"\x31\xc0", "sub eax,eax -> xor eax,eax"),
    (b"\x29\xc9", b"\x31\xc9", "sub ecx,ecx -> xor ecx,ecx"),
    (b"\x29\xd2", b"\x31\xd2", "sub edx,edx -> xor edx,edx"),
    (b"\x29\xdb", b"\x31\xdb", "sub ebx,ebx -> xor ebx,ebx"),
    # ── mov r32, r32 — two encodings (opcode 89 vs 8B, 2 bytes) ──
    (b"\x89\xc1", b"\x8b\xc8", "mov ecx,eax (89)->mov ecx,eax (8B)"),
    (b"\x8b\xc8", b"\x89\xc1", "mov ecx,eax (8B)->mov ecx,eax (89)"),
    (b"\x89\xc2", b"\x8b\xd0", "mov edx,eax (89)->mov edx,eax (8B)"),
    (b"\x8b\xd0", b"\x89\xc2", "mov edx,eax (8B)->mov edx,eax (89)"),
    (b"\x89\xc3", b"\x8b\xd8", "mov ebx,eax (89)->mov ebx,eax (8B)"),
    (b"\x89\xd1", b"\x8b\xca", "mov ecx,edx (89)->mov ecx,edx (8B)"),
    (b"\x89\xd0", b"\x8b\xc2", "mov eax,edx (89)->mov eax,edx (8B)"),
    # ── add/or/and/xor/cmp r32,r32 — two encodings (OP vs OP+2, 2 bytes) ──
    (b"\x01\xc0", b"\x03\xc0", "add eax,eax enc1->enc2"),
    (b"\x03\xc0", b"\x01\xc0", "add eax,eax enc2->enc1"),
    (b"\x01\xc8", b"\x03\xc1", "add ecx,eax -> add ecx,eax alt"),
    (b"\x21\xc0", b"\x23\xc0", "and eax,eax enc1->enc2"),
    (b"\x23\xc0", b"\x21\xc0", "and eax,eax enc2->enc1"),
    (b"\x39\xc0", b"\x3b\xc0", "cmp eax,eax enc1->enc2"),
    (b"\x3b\xc0", b"\x39\xc0", "cmp eax,eax enc2->enc1"),
    # ── cmp reg, 0 ↔ test reg, reg (3->3 bytes with nop pad) ──
    (b"\x83\xf8\x00", b"\x85\xc0\x90", "cmp eax,0 -> test eax,eax+nop"),
    (b"\x83\xf9\x00", b"\x85\xc9\x90", "cmp ecx,0 -> test ecx,ecx+nop"),
    (b"\x83\xfa\x00", b"\x85\xd2\x90", "cmp edx,0 -> test edx,edx+nop"),
    (b"\x83\xfb\x00", b"\x85\xdb\x90", "cmp ebx,0 -> test ebx,ebx+nop"),
    # ── mov reg, 0 (5-byte B8+) → xor + 3-byte nop ──
    (b"\xb8\x00\x00\x00\x00", b"\x31\xc0\x0f\x1f\x00", "mov eax,0 -> xor+3nop"),
    (b"\xb9\x00\x00\x00\x00", b"\x31\xc9\x0f\x1f\x00", "mov ecx,0 -> xor+3nop"),
    (b"\xba\x00\x00\x00\x00", b"\x31\xd2\x0f\x1f\x00", "mov edx,0 -> xor+3nop"),
    (b"\xbb\x00\x00\x00\x00", b"\x31\xdb\x0f\x1f\x00", "mov ebx,0 -> xor+3nop"),
    # ── REX.W variants (64-bit, 3 bytes with REX prefix 48) ──
    (b"\x48\x85\xc0", b"\x48\x09\xc0", "test rax,rax -> or rax,rax"),
    (b"\x48\x09\xc0", b"\x48\x85\xc0", "or rax,rax -> test rax,rax"),
    (b"\x48\x85\xc9", b"\x48\x09\xc9", "test rcx,rcx -> or rcx,rcx"),
    (b"\x48\x85\xd2", b"\x48\x09\xd2", "test rdx,rdx -> or rdx,rdx"),
    (b"\x48\x31\xc0", b"\x48\x33\xc0", "xor rax,rax enc1->enc2"),
    (b"\x48\x33\xc0", b"\x48\x31\xc0", "xor rax,rax enc2->enc1"),
    (b"\x48\x31\xc9", b"\x48\x33\xc9", "xor rcx,rcx enc1->enc2"),
    (b"\x48\x31\xd2", b"\x48\x33\xd2", "xor rdx,rdx enc1->enc2"),
    (b"\x48\x89\xc1", b"\x48\x8b\xc8", "mov rcx,rax (89)->mov rcx,rax (8B)"),
    (b"\x48\x89\xc2", b"\x48\x8b\xd0", "mov rdx,rax (89)->mov rdx,rax (8B)"),
    (b"\x48\x89\xe5", b"\x48\x8b\xec", "mov rbp,rsp (89)->mov rbp,rsp (8B)"),
    (b"\x48\x8b\xec", b"\x48\x89\xe5", "mov rbp,rsp (8B)->mov rbp,rsp (89)"),
]

# The built-in default rewrite table (alias kept for the public API).
DEFAULT_REWRITES: List[Tuple[bytes, bytes, str]] = EQUIV_TABLE

# Multi-byte NOP forms (all are architectural NOPs on x86_64).
MULTI_NOPS = {
    1: [b"\x90"],
    2: [b"\x66\x90"],
    3: [b"\x0f\x1f\x00"],
    4: [b"\x0f\x1f\x40\x00"],
    5: [b"\x0f\x1f\x44\x00\x00"],
    6: [b"\x66\x0f\x1f\x44\x00\x00"],
    7: [b"\x0f\x1f\x80\x00\x00\x00\x00"],
    8: [b"\x0f\x1f\x84\x00\x00\x00\x00\x00"],
    9: [b"\x66\x0f\x1f\x84\x00\x00\x00\x00\x00"],
}

# High-importance code-like bytes injected into padding runs. The code never
# executes, so byte content is free; injecting these shifts the histogram bins
# byte-distribution detectors weigh most heavily.
IMPORTANT_BYTES = bytes([
    0xE8, 0x00, 0x00, 0x00, 0x00,        # call +0 (looks like a call stub)
    0xFF, 0x15, 0x00, 0x00, 0x00, 0x00,  # call [rip+0] (IAT-style)
    0x7B, 0x7D, 0x5F, 0x20,              # braces, underscore, space
    0x48, 0x89, 0xE5,                    # mov rbp, rsp (common prologue)
    0x55,                                # push rbp
    0xC3,                                # ret
])


# Module-level latch so the "capstone missing -> pass 2 skipped" warning is
# emitted at most once per process, no matter how many times mutate_text runs.
_WARNED_NO_CAPSTONE = False


def _warn_pass2_skipped() -> None:
    global _WARNED_NO_CAPSTONE
    if not _WARNED_NO_CAPSTONE:
        _WARNED_NO_CAPSTONE = True
        warnings.warn(
            "capstone is not installed; the instruction-aligned equivalence "
            "substitution pass (pass 2) is SKIPPED. The safe algorithmic passes "
            "(padding NOP diversification + important-byte injection) still run. "
            'Install with: pip install "stoke-actions[disasm]"',
            RuntimeWarning,
            stacklevel=2,
        )


def _find_padding_runs(data, min_len: int = 2) -> List[Tuple[int, int, int]]:
    """Find runs of 0xCC or 0x90 bytes >= ``min_len`` long.

    Returns a list of ``(offset, length, byte_value)``.
    """
    runs: List[Tuple[int, int, int]] = []
    i = 0
    n = len(data)
    while i < n:
        if data[i] in (0xCC, 0x90):
            val = data[i]
            j = i + 1
            while j < n and data[j] == val:
                j += 1
            if j - i >= min_len:
                runs.append((i, j - i, val))
            i = j
        else:
            i += 1
    return runs


def _normalize_rewrites(
    rewrites: Sequence,
) -> List[Tuple[bytes, bytes]]:
    """Coerce a rewrite set into length-equal (orig, var) byte pairs.

    Accepts 2-tuples ``(orig, var)`` or 3-tuples ``(orig, var, desc)``. Pairs
    whose two sides differ in length, or with an empty original, are dropped.
    """
    pairs: List[Tuple[bytes, bytes]] = []
    for entry in rewrites:
        orig = entry[0]
        var = entry[1]
        if not isinstance(orig, (bytes, bytearray)):
            orig = bytes(orig)
        if not isinstance(var, (bytes, bytearray)):
            var = bytes(var)
        orig = bytes(orig)
        var = bytes(var)
        if not orig or len(orig) != len(var):
            continue
        pairs.append((orig, var))
    return pairs


def mutate_text(content,
                rewrites: Optional[Sequence] = None,
                seed: Optional[int] = None,
                max_mutations: int = 8,
                cs_mode: Optional[int] = None) -> bytes:
    """Apply the three length-preserving passes to a ``.text`` byte buffer.

    Args:
        content: the executable-section bytes (``bytes`` / ``bytearray``).
        rewrites: the resolved substitution set for pass 2. ``None`` uses
            :data:`DEFAULT_REWRITES`. A caller-supplied set REPLACES the default
            (it does not layer on top) so callers fully control pass 2.
        seed: deterministic RNG seed. ``None`` derives a seed from the content
            hash. ``0`` is honoured as a real seed (not treated as "no seed").
        max_mutations: hard cap on total edits across all passes. Passes run in
            a fixed order (1 padding -> 2 substitution -> 3 important-byte) so
            the output is deterministic for a given seed.
        cs_mode: the capstone ``CS_MODE_*`` to disassemble ``content`` with for
            the instruction-aligned pass 2. ``None`` defaults to
            ``CS_MODE_64`` (resolved lazily). If capstone is not importable,
            pass 2 is SKIPPED (a one-time warning is emitted) and only the safe
            algorithmic passes 1 and 3 run.

    Returns the mutated buffer (same length as ``content``).
    """
    buf = bytearray(content)
    if not buf:
        return bytes(buf)

    if seed is not None:
        rng_seed = seed
    else:
        rng_seed = int.from_bytes(
            hashlib.sha256(bytes(buf[:256])).digest()[:4], "little")
    rng = random.Random(rng_seed)

    if max_mutations <= 0:
        return bytes(buf)

    resolved = DEFAULT_REWRITES if rewrites is None else rewrites
    pairs = _normalize_rewrites(resolved)

    mutations = 0

    # ── Pass 1: padding NOP diversification ──────────────────────────────
    runs = _find_padding_runs(buf, min_len=2)
    for off, length, _val in runs:
        if mutations >= max_mutations:
            break
        pos = 0
        while pos < length and mutations < max_mutations:
            remaining = length - pos
            nop_len = min(remaining,
                          rng.choice(list(range(1, min(10, remaining + 1)))))
            nop_choices = MULTI_NOPS.get(nop_len)
            if nop_choices:
                nop = rng.choice(nop_choices)
                buf[off + pos:off + pos + nop_len] = nop
                mutations += 1
            pos += nop_len

    # ── Pass 2: equivalence substitution (the `rewrites` layer) ──────────
    # INSTRUCTION-ALIGNED: only rewrite where a decoded instruction's bytes
    # exactly equal the pattern. Needs capstone; if it is missing we skip the
    # entire pass (warn once) so passes 1 and 3 still run dependency-free. The
    # warning is tied to capstone AVAILABILITY (pass 2 was requested) — not to
    # whether the mutation budget happened to survive pass 1.
    if pairs:
        try:
            import capstone  # lazy presence check for the whole pass
        except ImportError:
            _warn_pass2_skipped()
        else:
            mode = capstone.CS_MODE_64 if cs_mode is None else cs_mode
            for orig, var in pairs:
                if mutations >= max_mutations:
                    break
                plen = len(orig)
                # Recompute sites against the CURRENT buffer: an earlier pair
                # may have changed bytes (and instruction boundaries) here.
                sites = _aligned_sites_in_buf(bytes(buf), orig, mode)
                for p in sites:
                    if mutations >= max_mutations:
                        break
                    if rng.random() < 0.5:  # 50% chance per aligned site
                        buf[p:p + plen] = var
                        mutations += 1

    # ── Pass 3: high-importance byte injection into padding ──────────────
    # Re-scan: pass 1 may have altered padding bytes (NOPs are still 0x90).
    runs = _find_padding_runs(buf, min_len=2)
    for off, length, _val in runs:
        if mutations >= max_mutations:
            break
        if rng.random() < 0.4:  # 40% of padding runs get high-importance fill
            for j in range(length):
                if mutations >= max_mutations:
                    break
                buf[off + j] = IMPORTANT_BYTES[
                    rng.randint(0, len(IMPORTANT_BYTES) - 1)]
                mutations += 1

    return bytes(buf)


__all__ = [
    "EQUIV_TABLE",
    "DEFAULT_REWRITES",
    "MULTI_NOPS",
    "IMPORTANT_BYTES",
    "_find_padding_runs",
    "mutate_text",
]
