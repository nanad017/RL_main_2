"""Command-line interface for stoke_actions.

Usage:
    python -m stoke_actions mutate <in.exe> <out.exe> -n 8 [--seed S] [--rewrites NAME]
    python -m stoke_actions libraries
"""
from __future__ import annotations

import argparse
import sys
from typing import List, Optional

from . import __version__, list_libraries, mutate


def _cmd_mutate(args: argparse.Namespace) -> int:
    with open(args.infile, "rb") as fh:
        pe_bytes = fh.read()
    out = mutate(pe_bytes, n=args.n, rewrites=args.rewrites, seed=args.seed)
    with open(args.outfile, "wb") as fh:
        fh.write(out)
    changed = out != pe_bytes
    sys.stderr.write(
        "wrote %s (%d bytes, in=%d, changed=%s)\n"
        % (args.outfile, len(out), len(pe_bytes), changed)
    )
    return 0


def _cmd_libraries(_args: argparse.Namespace) -> int:
    rows = list_libraries()
    if not rows:
        sys.stderr.write("no bundled libraries found\n")
        return 1
    name_w = max(len(n) for n, _, _ in rows)
    for name, n_pairs, size in rows:
        sys.stdout.write(
            "%-*s  %6d pairs  %9d bytes\n" % (name_w, name, n_pairs, size)
        )
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="stoke-actions",
        description="Semantic-preserving x86-64 PE .text mutation.",
    )
    p.add_argument("--version", action="version",
                   version="stoke_actions %s" % __version__)
    sub = p.add_subparsers(dest="command")

    m = sub.add_parser("mutate", help="mutate a PE's .text section")
    m.add_argument("infile", help="input PE path")
    m.add_argument("outfile", help="output PE path")
    m.add_argument("-n", type=int, default=8,
                   help="max mutations (default 8)")
    m.add_argument("--seed", type=int, default=None,
                   help="deterministic seed")
    m.add_argument("--rewrites", default=None,
                   help="bundled library name or JSON path "
                        "(default: built-in table)")
    m.set_defaults(func=_cmd_mutate)

    libs = sub.add_parser("libraries", help="list bundled equivalence libraries")
    libs.set_defaults(func=_cmd_libraries)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
