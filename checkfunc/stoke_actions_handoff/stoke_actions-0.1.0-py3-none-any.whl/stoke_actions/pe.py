"""Pure-Python PE .text locator + INSTRUCTION-ALIGNED in-place patch helpers.

This module locates the executable (``.text``) section of a Windows PE file
using only the standard-library :mod:`struct` module — LIEF is OPTIONAL and is
NEVER required at runtime. Because every mutation produced by this package is
length-equal, we patch bytes in place and return the buffer: the PE never needs
to be rebuilt (headers, the section table and every other section keep their
original offsets).

Soundness: x86-64 is a variable-length ISA, so a short pattern such as
``85 C0`` (``test eax,eax``) also occurs as operand/immediate/displacement bytes
INSIDE longer instructions and as embedded data. A blind whole-section
``bytes.replace`` would corrupt those non-instruction occurrences and break the
semantic-preserving guarantee. The rewrite path therefore decodes ``.text`` with
capstone and only rewrites at REAL decoded-instruction boundaries (``aligned``,
the default). ``aligned=False`` restores the old naive byte-replace behaviour —
it is UNSAFE and provided only for dependency-free / diagnostic use.

capstone is an OPTIONAL dependency (``pip install "stoke-actions[disasm]"``):
it is imported lazily, only inside the functions that need it, so the rest of
the package (and the algorithmic ``mutate()`` passes) run with zero deps.

Public:
    find_text_bounds(pe_bytes)                       -> Optional[(start, end)]
    splice(pe_bytes, start, end, new)                -> bytes
    detect_cs_mode(pe_bytes)                          -> int (capstone CS_MODE_*)
    find_rewrite_sites(pe_bytes, orig, *, aligned)    -> List[int]
    apply_rewrite(pe_bytes, orig, var, *, count, aligned)  -> bytes
    apply_rewrites(pe_bytes, pairs, *, count, aligned)     -> bytes
"""
from __future__ import annotations

import struct
from typing import Iterable, List, Optional, Tuple

# IMAGE_SCN_MEM_EXECUTE in the section Characteristics field.
IMAGE_SCN_MEM_EXECUTE = 0x20000000

# Skip absurd section sizes that obviously do not fit the buffer rather than
# trusting the on-disk header blindly.
_MAX_REASONABLE_SECTION = 1 << 30  # 1 GiB


def find_text_bounds(pe_bytes: bytes) -> Optional[Tuple[int, int]]:
    """Return ``(file_offset, end_offset)`` of the executable section.

    The section named ``.text`` is preferred; otherwise the first section with
    ``IMAGE_SCN_MEM_EXECUTE`` set in its Characteristics is used. ``end_offset``
    is exclusive and clamped to ``len(pe_bytes)``.

    Returns ``None`` if the buffer is not a parseable PE or no executable
    section with a non-zero raw range is found. This is magic-agnostic: it works
    for both PE32 and PE32+ because the section table offset is derived from
    ``SizeOfOptionalHeader`` rather than the optional-header magic.
    """
    n = len(pe_bytes)
    # DOS header: "MZ" magic + e_lfanew at 0x3C.
    if n < 0x40 or pe_bytes[0:2] != b"MZ":
        return None
    (e_lfanew,) = struct.unpack_from("<I", pe_bytes, 0x3C)
    # Need PE sig (4) + COFF header (20) = 24 bytes from e_lfanew.
    if e_lfanew <= 0 or e_lfanew + 24 > n:
        return None
    if pe_bytes[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
        return None

    coff = e_lfanew + 4
    # COFF header layout (relative to `coff`):
    #   +0  Machine (2)
    #   +2  NumberOfSections (2)
    #   +4  TimeDateStamp (4)
    #   +8  PointerToSymbolTable (4)
    #   +12 NumberOfSymbols (4)
    #   +16 SizeOfOptionalHeader (2)
    #   +18 Characteristics (2)
    (num_sections,) = struct.unpack_from("<H", pe_bytes, coff + 2)
    (size_opt_hdr,) = struct.unpack_from("<H", pe_bytes, coff + 16)
    if num_sections == 0:
        return None

    # Section table starts immediately after the optional header.
    sect_table = coff + 20 + size_opt_hdr
    entry_size = 40

    exec_fallback: Optional[Tuple[int, int]] = None
    for i in range(num_sections):
        ent = sect_table + i * entry_size
        if ent + entry_size > n:
            break
        name = pe_bytes[ent:ent + 8]
        # Section entry layout (relative to `ent`):
        #   +8  VirtualSize (4)
        #   +12 VirtualAddress (4)
        #   +16 SizeOfRawData (4)
        #   +20 PointerToRawData (4)
        #   +36 Characteristics (4)  (last 4 bytes of the 40-byte entry)
        (size_raw,) = struct.unpack_from("<I", pe_bytes, ent + 16)
        (ptr_raw,) = struct.unpack_from("<I", pe_bytes, ent + 20)
        (characteristics,) = struct.unpack_from("<I", pe_bytes, ent + 36)

        if ptr_raw <= 0 or size_raw <= 0 or size_raw > _MAX_REASONABLE_SECTION:
            continue
        if ptr_raw >= n:
            continue
        end = min(ptr_raw + size_raw, n)
        if end <= ptr_raw:
            continue

        if name.rstrip(b"\x00") == b".text":
            return ptr_raw, end
        if exec_fallback is None and (characteristics & IMAGE_SCN_MEM_EXECUTE):
            exec_fallback = (ptr_raw, end)

    return exec_fallback


def splice(pe_bytes: bytes, start: int, end: int, new_section: bytes) -> bytes:
    """Replace ``pe_bytes[start:end]`` with ``new_section`` (must be same len)."""
    if len(new_section) != (end - start):
        raise ValueError(
            "splice requires a length-preserving replacement "
            "(got %d, expected %d)" % (len(new_section), end - start)
        )
    return pe_bytes[:start] + new_section + pe_bytes[end:]


def detect_cs_mode(pe_bytes: bytes) -> int:
    """Return the capstone ``CS_MODE_*`` matching the PE's COFF Machine word.

    Reads the Machine word at ``e_lfanew + 4 + 0`` (the first field of the COFF
    header, immediately after the ``PE\\0\\0`` signature):

      * ``0x8664`` (IMAGE_FILE_MACHINE_AMD64) -> ``capstone.CS_MODE_64``
      * ``0x014C`` (IMAGE_FILE_MACHINE_I386)  -> ``capstone.CS_MODE_32``
      * anything else / unparseable buffer    -> ``capstone.CS_MODE_64`` default

    capstone is imported lazily so the rest of the package needs no deps.
    """
    import capstone  # lazy: only needed on the disasm path
    n = len(pe_bytes)
    if n >= 0x40 and pe_bytes[0:2] == b"MZ":
        (e_lfanew,) = struct.unpack_from("<I", pe_bytes, 0x3C)
        if 0 < e_lfanew and e_lfanew + 6 <= n and \
                pe_bytes[e_lfanew:e_lfanew + 4] == b"PE\x00\x00":
            (machine,) = struct.unpack_from("<H", pe_bytes, e_lfanew + 4)
            if machine == 0x014C:
                return capstone.CS_MODE_32
            if machine == 0x8664:
                return capstone.CS_MODE_64
    return capstone.CS_MODE_64


def _aligned_sites_in_buf(buf: bytes, orig: bytes, mode: int,
                          base: int = 0) -> List[int]:
    """Linear-disassemble ``buf`` and return ABSOLUTE offsets of instructions
    whose encoded ``.bytes`` exactly equal ``orig``.

    A single clean linear sweep is used (no ``skipdata`` — fabricated
    pseudo-instructions could hand back a false boundary and reintroduce the
    very unsoundness we are removing). ``base`` is added to every returned
    offset so callers can map section-relative addresses to file offsets.
    capstone is imported lazily; the caller is responsible for the friendly
    "install capstone" error message.
    """
    import capstone  # lazy
    md = capstone.Cs(capstone.CS_ARCH_X86, mode)
    sites: List[int] = []
    for insn in md.disasm(buf, base):
        if bytes(insn.bytes) == orig:
            sites.append(insn.address)
    return sites


def find_rewrite_sites(pe_bytes: bytes, orig: bytes, *,
                       aligned: bool = True) -> List[int]:
    """Return ABSOLUTE file offsets where ``orig`` may be safely rewritten.

    When ``aligned`` is True (default, SOUND): ``.text`` is decoded with
    capstone using the PE's detected mode and only positions where a decoded
    instruction's encoded bytes exactly equal ``orig`` are returned. This
    requires capstone; if it is missing an :class:`ImportError` is raised with
    install guidance.

    When ``aligned`` is False (UNSAFE): every naive byte-match offset within the
    executable section is returned, including operand/immediate/displacement
    bytes and embedded data. Provided only for dependency-free / diagnostic use.

    If the buffer is not a parseable PE (``find_text_bounds`` is ``None``):
      * aligned   -> the whole buffer is linear-disassembled with the default
                     ``CS_MODE_64`` and matched at instruction boundaries.
      * unaligned -> naive whole-buffer matches.
    """
    if not orig:
        return []

    bounds = find_text_bounds(pe_bytes)

    if not aligned:
        # UNSAFE naive byte-match path — no capstone needed.
        if bounds is None:
            region, base = pe_bytes, 0
        else:
            start, end = bounds
            region, base = pe_bytes[start:end], start
        sites: List[int] = []
        idx = 0
        plen = len(orig)
        while True:
            p = region.find(orig, idx)
            if p == -1:
                break
            sites.append(base + p)
            idx = p + plen  # non-overlapping, like the old replace()
        return sites

    # aligned=True — requires capstone.
    try:
        import capstone  # noqa: F401  (presence check before disasm helpers)
    except ImportError as exc:  # pragma: no cover - exercised via monkeypatch
        raise ImportError(
            "instruction-aligned rewrites need capstone: "
            "pip install capstone (or pass aligned=False)"
        ) from exc

    if bounds is None:
        # Non-PE buffer: whole-buffer linear disasm with the default mode.
        return _aligned_sites_in_buf(pe_bytes, orig, capstone.CS_MODE_64, base=0)

    start, end = bounds
    mode = detect_cs_mode(pe_bytes)
    return _aligned_sites_in_buf(pe_bytes[start:end], orig, mode, base=start)


def apply_rewrite(pe_bytes: bytes, orig: bytes, var: bytes, *,
                  count: Optional[int] = None, aligned: bool = True) -> bytes:
    """Replace ``orig`` with ``var`` at SOUND rewrite sites in the exec section.

    Requires ``len(orig) == len(var)`` (size-preserving); empty ``orig`` returns
    the buffer unchanged. Sites are located via :func:`find_rewrite_sites`
    (instruction-aligned by default — see its docstring for the ``aligned`` /
    non-PE semantics). If ``count`` is given, only the first ``count`` sites (in
    ascending offset order) are patched.

    The length and emptiness guards run BEFORE any capstone touch, so callers
    relying on the ``ValueError`` contract work with zero deps.
    """
    if not orig:
        return pe_bytes
    if len(orig) != len(var):
        raise ValueError("apply_rewrite requires len(orig) == len(var)")

    sites = find_rewrite_sites(pe_bytes, orig, aligned=aligned)
    if count is not None:
        sites = sites[:count]
    if not sites:
        return pe_bytes

    # Patch absolute offsets directly. Sites are non-overlapping instruction
    # starts (or non-overlapping naive matches), so order is irrelevant.
    buf = bytearray(pe_bytes)
    plen = len(orig)
    for off in sites:
        buf[off:off + plen] = var
    return bytes(buf)


def apply_rewrites(pe_bytes: bytes,
                   pairs: Iterable[Tuple[bytes, bytes]], *,
                   count: Optional[int] = None,
                   aligned: bool = True) -> bytes:
    """Apply many ``(orig, var)`` rewrites sequentially, threading the buffer.

    ``count`` (if given) caps replacements PER pair; ``aligned`` is forwarded to
    each :func:`apply_rewrite`.
    """
    out = pe_bytes
    for orig, var in pairs:
        out = apply_rewrite(out, orig, var, count=count, aligned=aligned)
    return out


__all__ = [
    "IMAGE_SCN_MEM_EXECUTE",
    "find_text_bounds",
    "splice",
    "detect_cs_mode",
    "find_rewrite_sites",
    "apply_rewrite",
    "apply_rewrites",
]
