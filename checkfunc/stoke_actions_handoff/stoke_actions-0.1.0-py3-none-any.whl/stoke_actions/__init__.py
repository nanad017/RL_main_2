"""stoke_actions — semantic-preserving x86-64 PE .text mutation API.

A general-purpose mutation engine that applies SEMANTIC-PRESERVING x86-64
mutations to a Windows PE binary's executable (``.text``) section. Every
mutation is length-equal, so the PE never needs rebuilding — bytes are patched
in place and the full PE buffer is returned. LIEF is OPTIONAL (a pure-Python
struct parser locates ``.text``); if the buffer is not a valid PE the engine
falls back to operating on the whole buffer.

The data-driven / library rewrite path (and ``aligned=True``, the default) is
INSTRUCTION-BOUNDARY-AWARE for soundness: it only edits at REAL decoded x86-64
instruction starts. That path needs capstone (an optional dep:
``pip install "stoke-actions[disasm]"``). The pure-Python algorithmic passes of
:func:`mutate` (padding NOP diversification + important-byte injection) and
``aligned=False`` need no capstone.

Public API:
    mutate(pe_bytes, n=8, rewrites=None, seed=None) -> bytes
    apply_rewrite(pe_bytes, orig, var, *, count=None, aligned=True) -> bytes
    apply_rewrites(pe_bytes, pairs, *, count=None, aligned=True) -> bytes
    find_rewrite_sites(pe_bytes, orig, *, aligned=True) -> list[int]
    load_library(name_or_path) -> list[(orig, var)]
    list_libraries() -> list[(name, n_pairs, size_bytes)]
    DEFAULT_REWRITES  — list[(orig, var, description)]
    find_text_bounds(pe_bytes) -> Optional[(start, end)]
    detect_cs_mode(pe_bytes) -> int (capstone CS_MODE_*)
"""
from __future__ import annotations

from typing import List, Optional, Sequence, Tuple, Union

from .engine import (
    DEFAULT_REWRITES,
    EQUIV_TABLE,
    IMPORTANT_BYTES,
    MULTI_NOPS,
    mutate_text,
)
from .pe import (
    apply_rewrite,
    apply_rewrites,
    detect_cs_mode,
    find_rewrite_sites,
    find_text_bounds,
    splice,
)
from .rewrites import list_libraries, load_library, resolve_rewrites

__version__ = "0.1.0"


def mutate(pe_bytes: bytes,
           n: int = 8,
           rewrites: Optional[Union[str, Sequence]] = None,
           seed: Optional[int] = None) -> bytes:
    """Apply up to ``n`` semantic-preserving mutations to the ``.text`` section.

    Args:
        pe_bytes: the full PE file as bytes.
        n: maximum number of mutations to apply (hard cap).
        rewrites: extra/alternate substitution set layered into pass 2.
            * ``None``      -> use :data:`DEFAULT_REWRITES` (built-in ~57 pairs).
            * ``str`` name  -> a bundled library from :func:`list_libraries`
                               (e.g. ``"proven_v3_cleaned"``).
            * ``str`` path  -> path to a JSON library file.
            * ``list``      -> list of ``(orig_bytes, var_bytes)`` tuples.
            A caller-supplied set REPLACES the default for pass 2.
        seed: deterministic seed. Same ``seed`` + input always yields the same
            output. ``None`` derives a seed from the content hash.

    Returns the full PE bytes, identical length to the input (size-preserving).
    If the buffer is not a valid PE the whole buffer is mutated as a fallback.
    """
    resolved = resolve_rewrites(rewrites)

    # Detect the disassembly mode for the instruction-aligned pass 2. capstone
    # is optional: if it is absent, detect_cs_mode raises ImportError, and we
    # pass cs_mode=None — mutate_text then skips pass 2 (with a one-time
    # warning) while still running the dependency-free algorithmic passes.
    try:
        cs_mode = detect_cs_mode(pe_bytes)
    except ImportError:
        cs_mode = None

    bounds = find_text_bounds(pe_bytes)
    if bounds is None:
        # Not a parseable PE — mutate the whole buffer as a fallback.
        mutated = mutate_text(pe_bytes, rewrites=resolved, seed=seed,
                              max_mutations=n, cs_mode=cs_mode)
        return mutated

    start, end = bounds
    section = pe_bytes[start:end]
    new_section = mutate_text(section, rewrites=resolved, seed=seed,
                              max_mutations=n, cs_mode=cs_mode)
    if len(new_section) != len(section):
        # Defensive: every pass is length-equal, so this must not happen.
        return pe_bytes
    return splice(pe_bytes, start, end, new_section)


__all__ = [
    "__version__",
    "mutate",
    "apply_rewrite",
    "apply_rewrites",
    "find_rewrite_sites",
    "detect_cs_mode",
    "load_library",
    "list_libraries",
    "find_text_bounds",
    "DEFAULT_REWRITES",
    "EQUIV_TABLE",
    "MULTI_NOPS",
    "IMPORTANT_BYTES",
]
