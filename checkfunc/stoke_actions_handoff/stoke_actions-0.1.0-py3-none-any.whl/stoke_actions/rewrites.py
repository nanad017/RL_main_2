"""Bundled equivalence-library loading and resolution.

The package ships a ``data/`` directory of STOKE-mined equivalence libraries as
JSON. This module parses those tables into length-equal ``(orig, var)`` byte
pairs and resolves the public ``rewrites=`` argument.

Supported on-disk schemas (auto-detected):
  * dict wrapper:  ``{"__meta__": {...}, "entries": [ {...}, ... ]}``
  * bare list:     ``[ {...}, ... ]``
Each entry dict carries the pair as either ``original_hex``/``variant_hex`` or
``before``/``after`` (hex strings). Pairs whose two sides differ in length, are
empty, fail to hex-decode, or exceed ``MAX_PATTERN_LEN`` (whole-binary entries)
are skipped — this package is strictly size-preserving.
"""
from __future__ import annotations

import json
import os
from typing import List, Optional, Tuple, Union

# Skip whole-ELF / whole-binary entries; pass 2 only ever splices short
# instruction sequences.
MAX_PATTERN_LEN = 256

_LIB_PREFIX = "equiv_library_"
_LIB_SUFFIX = ".json"


def _data_dir() -> str:
    """Absolute path to the bundled ``data/`` directory (editable + wheel)."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")


def _friendly_name(filename: str) -> str:
    """``equiv_library_proven_v3_cleaned.json`` -> ``proven_v3_cleaned``."""
    base = os.path.basename(filename)
    if base.endswith(_LIB_SUFFIX):
        base = base[: -len(_LIB_SUFFIX)]
    if base.startswith(_LIB_PREFIX):
        base = base[len(_LIB_PREFIX):]
    return base


def _resolve_path(name_or_path: str) -> Optional[str]:
    """Resolve a friendly name OR a filesystem path to a JSON file path."""
    # Direct path (absolute or relative) to an existing file.
    if os.path.isfile(name_or_path):
        return name_or_path
    data_dir = _data_dir()
    # Friendly name -> data/equiv_library_<name>.json
    candidates = [
        os.path.join(data_dir, _LIB_PREFIX + name_or_path + _LIB_SUFFIX),
        os.path.join(data_dir, name_or_path + _LIB_SUFFIX),
        os.path.join(data_dir, name_or_path),
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
    return None


def _iter_entries(raw):
    """Yield entry dicts from either the dict-wrapper or bare-list schema."""
    if isinstance(raw, dict):
        entries = raw.get("entries")
        if isinstance(entries, list):
            for e in entries:
                if isinstance(e, dict):
                    yield e
        return
    if isinstance(raw, list):
        for e in raw:
            if isinstance(e, dict):
                yield e


def _pairs_from_raw(raw) -> List[Tuple[bytes, bytes]]:
    pairs: List[Tuple[bytes, bytes]] = []
    for entry in _iter_entries(raw):
        bh = entry.get("original_hex")
        if bh is None:
            bh = entry.get("before")
        ah = entry.get("variant_hex")
        if ah is None:
            ah = entry.get("after")
        if not isinstance(bh, str) or not isinstance(ah, str):
            continue
        try:
            b = bytes.fromhex(bh)
            a = bytes.fromhex(ah)
        except ValueError:
            continue
        if not b or len(b) != len(a) or len(b) > MAX_PATTERN_LEN:
            continue
        pairs.append((b, a))
    return pairs


def load_library(name_or_path: str) -> List[Tuple[bytes, bytes]]:
    """Load a bundled library (by friendly name) or a JSON file (by path).

    Returns a list of length-equal ``(orig_bytes, var_bytes)`` pairs. Raises
    :class:`FileNotFoundError` if the name/path cannot be resolved.
    """
    path = _resolve_path(name_or_path)
    if path is None:
        avail = ", ".join(n for n, _, _ in list_libraries()) or "(none)"
        raise FileNotFoundError(
            "no equivalence library %r found; bundled: %s"
            % (name_or_path, avail)
        )
    with open(path, "r") as fh:
        raw = json.load(fh)
    return _pairs_from_raw(raw)


def list_libraries() -> List[Tuple[str, int, int]]:
    """List bundled libraries as ``(friendly_name, n_pairs, size_bytes)``.

    ``n_pairs`` is the count of usable length-equal pairs; ``size_bytes`` is the
    on-disk file size. Sorted by friendly name.
    """
    data_dir = _data_dir()
    out: List[Tuple[str, int, int]] = []
    if not os.path.isdir(data_dir):
        return out
    for fn in sorted(os.listdir(data_dir)):
        if not fn.endswith(_LIB_SUFFIX):
            continue
        path = os.path.join(data_dir, fn)
        if not os.path.isfile(path):
            continue
        try:
            size = os.path.getsize(path)
            with open(path, "r") as fh:
                raw = json.load(fh)
            n_pairs = len(_pairs_from_raw(raw))
        except (OSError, ValueError):
            continue
        out.append((_friendly_name(fn), n_pairs, size))
    return out


def resolve_rewrites(
    rewrites: Optional[Union[str, list, tuple]],
) -> Optional[List[Tuple[bytes, bytes]]]:
    """Resolve the public ``rewrites=`` argument into (orig, var) pairs or None.

    * ``None``           -> ``None`` (engine uses DEFAULT_REWRITES).
    * ``str``            -> bundled library name or JSON path -> pairs.
    * list/tuple         -> normalized list of (orig, var) byte pairs.
    """
    if rewrites is None:
        return None
    if isinstance(rewrites, str):
        return load_library(rewrites)
    pairs: List[Tuple[bytes, bytes]] = []
    for entry in rewrites:
        orig = bytes(entry[0])
        var = bytes(entry[1])
        pairs.append((orig, var))
    return pairs


__all__ = [
    "MAX_PATTERN_LEN",
    "load_library",
    "list_libraries",
    "resolve_rewrites",
]
